
		Project Tempest v0.91 (17 January 2004)
		---------------------------------------



1. System Requirements
----------------------

1GHz+ processor
128MB RAM
DirectX 9.0 or higher
Windows 9x/ME/2000/XP (only tested on XP)

A faster processor is seriously recommended !
For sound emulation, you probably need a 2+ GHz processor.



2. How to use this emulator
---------------------------

To load a ROM image or a homebrewn demo/game, use File/Open ROM...
The emulator will automatically recognize the type of the file.

To start the emulation, press F2 or Start from emulation menu.

To stop the emulation, press F3 or Stop from emulation menu.


3. Settings
-----------

Eeprom Path:		This is where your game saves will go

Show FPS:		This enables frames per second counter. Use F11 while a game
			is running to enable/disable this.

Bilinear filtering:	Enabling this will cause the graphics to be more blurred

Limit frame rate:	Limits the speed to 60 fps. This must be enabled to run the games
			at correct speed.

Fullscreen mode:	When enabled, switches automatically to fullscreen mode when running games.

Press ESC to switch between windowed-mode and fullscreen-mode.


4. Controls
-----------

Keyboard and DirectInput-compatible game controllers are supported.
Use Settings/Controllers to configure controllers



5. Credits
----------

Emulator programming by Ville Linde

Website and support by The Fox (emuunlim@emuunlim.com)
Website design by Malc Jennings

Thanks to David Raingeard for bits and pieces about the CD emulation :)


6. Contact Information
----------------------

Website:  http://pt.emuunlim.com
E-Mail:	  ptemu@emuunlim.com

