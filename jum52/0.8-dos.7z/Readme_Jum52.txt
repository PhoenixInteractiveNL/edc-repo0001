Jum's A5200 Emulator, Platform Independant, Version 0.8 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

10 April 2003

Jum52 is an Atari 5200 emulator for Windows, MSDOS, QNX, BeOS, Mac and PS2.

This is the MSDOS "build" of the emulator.

The 6502 CPU emulator source is heavily based on a distribution
by Neil Bradley. The POKEY sound emulator is from Ron Fries.
Initial conversion to cross-platform thanks to Richard Bannister.
The rest is by me :)


Obligatory Copyright Notice:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Jum's A5200 Emulator is copyright 1999-2003 by James Higgs.
POKEY Sound is copyright 1996 by Ron Fries.

Jum's A5200 Emulator is free as long as it is not used in a commercial
manner and not altered in any way. The contents of this archive should
not be added to or changed in any way. 

I maintain the right to forbid the use of the emulator at
any time. I am not responsible for any damage caused by the use
of this program. This program is distributed "as-is". I make no
guarantees as to it's accuracy, performance, or compatibility with
the user's hardware.

Jum's A5200 Emulator ("Jum52") is not to be included in CD collections
of any sort.


******************************************************************
	DO NOT ASK ME FOR ROM OR CARTRIDGE IMAGES !!!
******************************************************************

Emulated hardware:
~~~~~~~~~~~~~~~~~~
Just about all of it.

Still a few tiny display timing problems.

What's New:
~~~~~~~~~~~

12 April 2003 (v0.8)
	Improved cycle counting (ANTIC DMA stolen cycles)
	Use 136 cycles per line for both NTSC and PAL (6502.c)
	Changed keys. (See below)
	Fixed collision detection.
		- KABOOM!, H.E.R.O. and RIVER RAID are playable.	

(refer also to changes.txt)

Compatibility:
~~~~~~~~~~~~~~

Most carts will run. Some games still give problems:

Decathlon
Mr. Do's Castle
Quest for Quintana Roo
Rescue on Fractalus

Keys:
~~~~~
F1	5200 Start button
F2	5200 Pause button
F3	Reset (reboot emulator)
F4	Go to monitor/debugger
F5	5200 * button
F6	5200 # button
F8	Switch between Keyboard/Joystick/Mouse control
F9	Save state
F10	Load state
F11	Toggle fps display on/off
F12	Dump screen to PCX file

ESC	Quit / Go back one level. (ie: does what you expect)
Pause   5200 Pause button
P	Emulator pause

Player 1:
~~~~~~~~~
Arrow Keys	Up/Down/Left/Right
Right Ctrl	Fire
Backslash	Trigger ("fire 2")
Space           Side button ("fire 3")
0-9, F5, F6     Keypad buttons (also "-" (*) and "+" (#) )

Player 2:
~~~~~~~~~
W/S/A/D		P2 Up/Down/Left/Right
Left Ctrl	P2 Fire
Left Shift	P2 Fire 2
Space		Side Button ("fire 3")
/               P2 Start
*		P2 Pause
Del		P2 * button
Enter		P2 # button

Note: Keys may differ slightly between platforms or versions.


Debugger Keys
~~~~~~~~~~~~~

No debugger in the MSDOS version.
In the Windows version, press 'H' while in the debug mode to get help.


Joystick:
~~~~~~~~~

[NOT IMPLEMENTED IN THE CROSS-PLATFORM VERSION]

Not implemented in the MSDOS version of Jum52.


Mouse:
~~~~~~

[NOT IMPLEMENTED IN THE CROSS-PLATFORM VERSION]

Not implemented in the MSDOS version of Jum52.

The mouse does not require calibrating :)
Use the mouse for Missile Command and maybe other trackball
games.


Getting started:
~~~~~~~~~~~~~~~~

You will need:
Jum's A5200 Emulator executable JUM52.EXE
A5200 bios rom, renamed to "5200.BIN", in the same directory.
Some 16k or 32k 5200 cartridge images

******************************************************************
	DO NOT ASK ME FOR ROM OR CARTRIDGE IMAGES !!!
******************************************************************


Drag and drop a ROM image (.bin) onto jum52.exe, OR
Type 'jum52 <filename>' at the command prompt.


Command-line switches:
~~~~~~~~~~~~~~~~~~~~~~

'PAL' or 'P'	Use PAL mode (50Hz). (See jum52pal.bat).



FAQ:
~~~~

1. Q: It doesn't run on my Mac.
   A: Get the Mac version from www.bannister.org

2. Q: It's crap. There's no blah blah yadda yadda ...
   A: It's free. Waddaya expect?

3. Q: It's so sssslllllooooowwwwwwwww...........
   A: Not really. You just have a crap PC.

4. Q: I have trouble getting the joystick to work.
   A: It's not implemented in this version. Get the Windows version. 
   A: Joystick is not completely emulated.

5. Q: I don't hear any sound.
   A: Cut down on the heavy metal.
   A: Turn up the volume REALLY loud.
   A: You have a crap sound card.

6. Q: Game "X" doesn't work.
   A: It may be a corrupt/bad ROM image (there are many).
   A: Jum52 just doesn't handle that game (yet).

7. Q: Where can I get ROMZ? (plead/whine/grovel/demand)
   A: Learn to use a search engine, or something.



Troubleshooting and Comments:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Email:  james7780@yahoo.com

1. RTFM ("Getting started" above)
2. Intelligent questions are welcome.
3. Constructive comments are appreciated (especially comments on
   how the emulator differs from the real thing).


Future Features:
~~~~~~~~~~~~~~~~

1. Better.
3. Better controller support.
4. Whatever you can suggest? 


Credits:
~~~~~~~~
Thanks to:
Dan Boris (author of VSS and V7800) for infos.
Ron Fries (for POKEY emu).
Neil Bradley for 6502 emu.
Sherwood for helpful comments and other stuff.
Christpher Durante for useful input.
Richard Bannister for cross-platform conversion and Mac version
Other people who contributed or complained. 
