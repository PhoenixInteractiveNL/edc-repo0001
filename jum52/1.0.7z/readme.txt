Jum's A5200 Emulator V1.0, Windows/SDL driver 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

6 April 2004


Here's the WIP version of Jum52 V1.0.

New:
1. Uses platform independant codebase
2. Voice emulation (on by default)
3. Uses config file 'jum52.cfg' to override built-in defaults


It's missing some stuff from Jum52_Win32 V0.8 (joystick and mouse modes etc) that I still have to put back in.

Audio output is via SDL and seems quite scratchy.

Runs "Blaster" well.

"Burgertime" doesn't start, but that may be due to a bug in the game's keypad handling code.

Have fun!

- James

