You will need the Atari 5200 bios rom, "5200.BIN", in this directory.

Find it on the internet (Search for "5200.BIN").
