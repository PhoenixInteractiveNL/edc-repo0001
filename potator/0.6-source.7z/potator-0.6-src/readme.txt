Potator 0.60
------------

* Source code cleanup
* Potator is now open source

Keys:

F1: start/pause
F2: select
Direction keys to move
x: button A
c: button B


Special thanks to Peter Trauner and Death adder for their help

contact: david.raingeard@laposte.net
