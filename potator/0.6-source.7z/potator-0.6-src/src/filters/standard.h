////////////////////////////////////////////////////////////////////////////////
// VERY SLOW !!!!
////////////////////////////////////////////////////////////////////////////////
//
//
//
//
//
//
//
////////////////////////////////////////////////////////////////////////////////
void supervision_rotate_backbuffer(int16 *backbuffer)
{
	static int16	temp[160*160];
	memcpy(temp,backbuffer,160*160*2);

	for (int line=0;line<160;line++)
		for (int column=0;column<160;column++)
			backbuffer[line+((223-column)<<7)+((223-column)<<4)]=temp[column+(line<<7)+(line<<6)+(line<<5)];
}
////////////////////////////////////////////////////////////////////////////////
//
////////////////////////////////////////////////////////////////////////////////
//
//
//
//
//
//
//
////////////////////////////////////////////////////////////////////////////////
void supervision_emulate_standard(void)
{
	#include "filter_partA.h"
	if (app_rotated)
	{
		surface=new Surface(160,160,format);
		#include "filter_partB.h"
		surfacePitch>>=1;
		console.open(app_window_title,160,160,format);
		while (1)
		{
				#include "filter_partC.h"
				console.open(app_window_title,160,160,format);
				#include "filter_partD.h"
				supervision_rotate_backbuffer(backbuffer);
				int32 *vs = (int32 *)surface->lock();
				memcpy(vs,backbuffer,160*160*2);				
				surface->unlock();
				surface->copy(console);
				console.update();
			}
		}
		#include "filter_partE.h"
	}
	else
	{
		surface=new Surface(160,160,format);
		#include "filter_partB.h"
		console.open(app_window_title,160,160,format);
		while (1)
		{
				#include "filter_partC.h"
				console.open(app_window_title,160,160,format);
				#include "filter_partD.h"
				int32 *vs = (int32 *)surface->lock();
				memcpy(vs,backbuffer,160*160*2);
				surface->unlock();
				surface->copy(console);
				console.update();
			}
		}
		#include "filter_partE.h"
	}
}
