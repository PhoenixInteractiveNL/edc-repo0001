			nTime=timeGetTime()-nNormalLast;					  // calcule le temps �coul� depuis le dernier affichage
																  // nTime est en mili-secondes.
			// d�termine le nombre de trames � passer + 1
			nCount=(nTime*600 - nNormalFrac) /10000; 	

			// si le nombre de trames � passer + 1 est nul ou n�gatif,
			// ne rien faire pendant 2 ms
			if (nCount<=0) 
			{ 
				Sleep(2); 
			} // No need to do anything for a bit
			else
			{
				nNormalFrac+=nCount*10000;				// 
				nNormalLast+=nNormalFrac/600;				// add the duration of nNormalFrac frames
				nNormalFrac%=600;							// 

				// Pas plus de 9 (10-1) trames non affich�es 
				if (nCount>10) 
				  nCount=10; 

				int supervision_key_esc=0;

				while ( SDL_PollEvent(&app_input_event) )
				{
					if ( app_input_event.type == SDL_QUIT )
					{
						supervision_key_esc = 1;
					}
				}
				if (!supervision_update_input())
					supervision_key_esc = 1;
				
				if (supervision_key_esc)
				{
					supervision_turnSound(false);
					console.close();
					if (supervision_rom_path)
						strcpy(old_rom_path,supervision_rom_path);
					gui_open();

					if ((supervision_rom_path!=NULL)||(app_terminate))
					{
						supervision_done();
						break;
					}
					if (gui_command)
					{
						supervision_set_colour_scheme(supervision_colourScheme);
						if (gui_command==GUI_COMMAND_RESET)
							supervision_reset();
						// if (gui_command==GUI_COMMAND_SCHEME_CHANGE)
						//	supervision_set_colour_scheme(supervision_colourScheme);
						if (gui_command==GUI_COMMAND_FILTER_CHANGE)
						{
							// supervision_saveState("oswan.wss");
							supervision_rom_path=old_rom_path;
							delete surface;
							return;
						}
					}
					console.option("DirectX");
					if (app_fullscreen) 
						console.option("fullscreen output"); 
					else 
						console.option("windowed output");
					console.option("fixed window");
					console.option("center window");
