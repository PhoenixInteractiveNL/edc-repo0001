////////////////////////////////////////////////////////////////////////////////
//
////////////////////////////////////////////////////////////////////////////////
//
//
//
//
//
//
//
////////////////////////////////////////////////////////////////////////////////
void supervision_emulate_Super2xSaI(void)
{
	#include "filter_partA.h"
	if (app_rotated)
	{
		surface=new Surface(160*2,160*2,format);
		#include "filter_partB.h"
		console.open(app_window_title,160*2,160*2,format);
		while (1)
		{
				#include "filter_partC.h"
				console.open(app_window_title,160*2,160*2,format);
				#include "filter_partD.h"
				supervision_rotate_backbuffer(backbuffer);
				int16 *vs = (int16 *)surface->lock();
				Super2xSaI ((u8*)backbuffer,160*2, NULL,(u8*)vs, surfacePitch<<1,160,160);
				surface->unlock();
				surface->copy(console);
				console.update();
			}
		}
		#include "filter_partE.h"
	}
	else
	{
		surface=new Surface(160*2,160*2,format);
		#include "filter_partB.h"
		console.open(app_window_title,160*2,160*2,format);
		while (1)
		{
				#include "filter_partC.h"
				console.open(app_window_title,160*2,160*2,format);
				#include "filter_partD.h"
				int16 *vs = (int16 *)surface->lock();
				Super2xSaI ((u8*)backbuffer,160*2, NULL,(u8*)vs, surfacePitch<<1,160,160);
				surface->unlock();
				surface->copy(console);
				console.update();
			}
		}
		#include "filter_partE.h"
	}
}
