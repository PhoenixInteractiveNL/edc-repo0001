
				}


				for (i=0;i<nCount-1;i++) 
					supervision_exec(backbuffer,1);

				supervision_exec(backbuffer,1);
				totalFrames++;

