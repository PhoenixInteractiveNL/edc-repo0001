////////////////////////////////////////////////////////////////////////////////
//
////////////////////////////////////////////////////////////////////////////////
//
//
//
//
//
//
//
////////////////////////////////////////////////////////////////////////////////
void supervision_emulate_special(void)
{
	#include "filter_partA.h"
	if (app_rotated)
	{
		surface=new Surface(160*2,160*2,format);
		#include "filter_partB.h"
		console.open(app_window_title,160*2,160*2,format);
		while (1)
		{
				#include "filter_partC.h"
				console.open(app_window_title,160*2,160*2,format);
				#include "filter_partD.h"
				supervision_rotate_backbuffer(backbuffer);
				int16 *vs = (int16 *)surface->lock();
				int16	*backbuffer_alias=backbuffer;
				for (int line=0;line<160;line++)
				{
					supervision_drawDoubledHalfBrightnessRotatedScanlineSpecialEven(vs,backbuffer_alias);
					vs+=surfacePitch;
					supervision_drawDoubledHalfBrightnessRotatedScanlineSpecialOdd(vs,backbuffer_alias);
					vs+=surfacePitch;
					backbuffer_alias+=160;
				}
				surface->unlock();
				surface->copy(console);
				console.update();
			}
		}
		#include "filter_partE.h"
	}
	else
	{
		surface=new Surface(160*2,160*2,format);
		#include "filter_partB.h"
		console.open(app_window_title,160*2,160*2,format);
		while (1)
		{
				#include "filter_partC.h"
				console.open(app_window_title,160*2,160*2,format);
				#include "filter_partD.h"
				supervision_exec(backbuffer,1);
				int16 *vs = (int16 *)surface->lock();
				int16	*backbuffer_alias=backbuffer;
				for (int line=0;line<160;line++)
				{
					supervision_drawDoubledHalfBrightnessScanlineSpecialEven(vs,backbuffer_alias);
					vs+=surfacePitch;
					supervision_drawDoubledHalfBrightnessScanlineSpecialOdd(vs,backbuffer_alias);
					vs+=surfacePitch;
					backbuffer_alias+=160;
				}
				surface->unlock();
				surface->copy(console);
				console.update();
			}
		}
		#include "filter_partE.h"
	}
}
