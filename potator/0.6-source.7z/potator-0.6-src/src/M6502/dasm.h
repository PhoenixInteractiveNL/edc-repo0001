#ifndef __DASM_H__
#define __DASM_H__

#ifdef __cplusplus
extern "C" {
#endif

int Dasm(char *S,byte *A,unsigned long PC);

#ifdef __cplusplus
}
#endif

#endif