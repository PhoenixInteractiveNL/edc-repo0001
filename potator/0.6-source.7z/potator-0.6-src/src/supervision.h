////////////////////////////////////////////////////////////////////////////////
//
////////////////////////////////////////////////////////////////////////////////
//
//
//
//
//
//
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __SUPERVISION_H__
#define __SUPERVISION_H__

#include "log.h"
#include "types.h"
#include "memory.h"
#include "version.h"
#include "sound.h"
#include "io.h"
#include "gpu.h"
#include "timer.h"
#include "controls.h"
#include "memorymap.h"
#include "interrupts.h"

#include ".\\m6502\\M6502.h"
#include ".\\m6502\\dasm.h"

#define COLOUR_SCHEME_DEFAULT	0
#define COLOUR_SCHEME_AMBER		1
#define COLOUR_SCHEME_GREEN		2

void supervision_init(void);
void supervision_reset(void);
void supervision_reset_handler(void);
void supervision_done(void);
void supervision_exec(int16 *backbuffer, bool bRender);
bool supervision_load(char *szPath);
bool supervision_update_input(void);
void supervision_set_colour_scheme(int ws_colourScheme);
M6502	*supervision_get6502regs(void);
void supervision_turnSound(bool bOn);

#endif