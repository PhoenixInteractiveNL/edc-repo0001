#ifndef __MEMORYMAP_H__
#define __MEMORYMAP_H__

#include "supervision.h"

void memorymap_init();
void memorymap_done();
void memorymap_reset();
uint8  memorymap_registers_read(uint32 Addr);
void memorymap_registers_write(uint32 Addr, uint8 Value);
uint8	*memorymap_rom_load(char *path, uint32 *romSize);
void memorymap_load(uint8 *rom, uint32 size);
uint8 *memorymap_getUpperRamPointer(void);
uint8 *memorymap_getRomPointer(void);

#endif