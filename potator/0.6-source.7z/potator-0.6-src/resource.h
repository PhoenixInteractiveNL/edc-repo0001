//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gui.rc
//
#define IDD_DIALOG_MAIN                 101
#define IDB_BITMAP1                     102
#define IDB_BITMAP2                     103
#define IDB_BITMAP4                     112
#define IDB_BITMAP3                     113
#define IDC_BUTTON_LOAD                 1000
#define IDC_BUTTON_RESET                1001
#define IDC_BUTTON_EXIT                 1002
#define IDC_RADIO1                      1003
#define IDC_RADIO_WINDOWED              1003
#define IDC_RADIO2                      1004
#define IDC_RADIO_FULLSCREEN            1004
#define IDC_BUTTON_LOADSTATE            1005
#define IDC_BUTTON_SAVESTATE            1006
#define IDC_RADIO3                      1007
#define IDC_BUTTON_CONTINUE             1007
#define IDC_RADIO4                      1008
#define IDC_BUTTON_CONTROLS             1008
#define IDC_RADIO5                      1009
#define IDC_RADIO_STANDARD_MODE         1009
#define IDC_RADIO6                      1010
#define IDC_RADIO_DOUBLESIZE_MODE       1010
#define IDC_RADIO7                      1011
#define IDC_RADIO_SCANLINES_MODE        1011
#define IDC_RADIO8                      1012
#define IDC_RADIO_50PRCTSCANLINES_MODE  1012
#define IDC_RADIO9                      1013
#define IDC_RADIO_SPECIAL_MODE          1013
#define IDC_RADIO_SYSTEM_AUTODETECT     1014
#define IDC_RADIO_SYSTEM_MONO           1015
#define IDC_RADIO_SYSTEM_COLOR          1016
#define IDC_RADIO_2XSAI                 1017
#define IDC_RADIO_SUPER2XSAI            1018
#define IDC_COLOUR_DEFAULT              1019
#define IDC_COLOUR_AMBER                1020
#define IDC_COLOUR_GREEN                1021
#define IDC_RADIO_SUPEREAGLE            1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
