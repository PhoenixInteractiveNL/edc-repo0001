#!/bin/sh
# hope this makes someone happy - prg
rm /usr/local/bin/fceux

