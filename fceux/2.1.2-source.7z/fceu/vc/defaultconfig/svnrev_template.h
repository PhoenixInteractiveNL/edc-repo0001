#define SVN_REV $WCREV$
#define SVN_REV_STR "$WCREV$"