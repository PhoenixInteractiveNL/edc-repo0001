#!/bin/sh
gtk-builder-convert gfceux.glade gfceux.xml

