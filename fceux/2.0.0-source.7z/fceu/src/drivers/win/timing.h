#ifndef WIN_TIMING_H
#define WIN_TIMING_H

void ConfigTiming();

#endif
