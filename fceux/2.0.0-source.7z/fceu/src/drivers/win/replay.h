void Replay_LoadMovie(bool tasedit);
