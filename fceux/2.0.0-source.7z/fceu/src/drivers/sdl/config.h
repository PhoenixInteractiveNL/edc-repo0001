#include "../common/configSys.h"

Config *InitConfig(void);
void UpdateEMUCore(Config *);


