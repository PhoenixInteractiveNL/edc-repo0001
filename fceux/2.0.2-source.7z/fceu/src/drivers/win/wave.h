bool CreateSoundSave();
int CloseWave();
