#ifndef WIN_MAPINPUT_h
#define WIN_MAPINPUT_h

#endif
