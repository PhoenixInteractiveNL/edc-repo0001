#!/bin/sh
g++ `sdl-config --cflags --libs` main.cpp -o get_fceu_key;
