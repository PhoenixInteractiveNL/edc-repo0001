#ifndef WIN_MAPINPUT_h
#define WIN_MAPINPUT_h
char* GetKeyComboName(int c);
#endif
