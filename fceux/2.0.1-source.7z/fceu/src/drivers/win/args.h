extern char* MovieToLoad;
extern char* StateToLoad;
extern bool replayReadOnlySetting;
extern int replayStopFrameSetting;
extern int PauseAfterLoad;
char *ParseArgies(int argc, char *argv[]);
