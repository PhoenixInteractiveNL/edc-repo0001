void FCEUD_SaveStateAs();
void FCEUD_LoadStateFrom();
