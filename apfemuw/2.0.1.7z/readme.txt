May 2002:
This is the latest version of the APF Imagination Machine Emulator by Enrique Collado.

The instructions are both in English (two files: APF-Eng.txt & APFEMU-Eng.txt) and Spanish.

In this ZIP file should be two folders (besides this text file you're reading now).
 * apf_emuw (which contains the main APF emulator and associated files)
 * Concentr (I'm not sure, but I think this is a file for a "Concentration" game)

I've only had time to try the emulator out briefly, so please do not email me with
questions about it. I didn't write it, and probably won't have time to have a good look at it for a while, but wanted to place it up as soon as possible so others with more time could try it ASAP.

If you have a working APF Imagination Machine, please email Enrique, as he has some questions, and does not have a working machine handy.

It was written by Enrique Collado of Spain, and I'd just like to say "Thank You!"
to him for the great work!

Just two brief notes: when you first run the emulator (by clicking on the APF_EMUW icon)
you should see the opening screen. Press the F1 key to get to APF BASIC. There you can
do sample BASIC programs like:
  10 FOR X=0 to 255
  20 PRINT CHR$(X);
  30 NEXT
(this short program will show the character set -- note that after the initial characters, BASIC keyword 'tokens' appear!) Also note that the keyboard layout is slightly different than on a PC keyboard (to get the "=" key, you have to do a shift "-" key on a PC, etc.)

To EXIT the emulator, you must press F12, then POWER, and a prompt (in Spanish) will ask if you wish to abandon (quit) the emulator (you can't just close it in Windows).

One last note: APF had no "CLS" (clear the [letter] screen) command like other BASICs did.
Instead, the command to clear the screen is: CALL 17046

Enjoy!

Again, thanks Enrique!

Larry Greenfield
http://www.tcp.com/~lgreenf
         or
http://www.nausicaa.net/~lgreenf
