
gzFile zip2gz(ZIP* zip, struct zipent* ent);
int gzerror2(gzFile file);

