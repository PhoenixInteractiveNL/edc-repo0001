extern void lprintf(const char *fmt, ...);

