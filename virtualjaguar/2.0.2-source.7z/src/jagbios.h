#ifndef __JAGBIOS_H__
#define __JAGBIOS_H__

extern char jaguarBootROM[];

#endif	// __JAGBIOS_H__
