//
// state.cpp: VJ machine state save/load support
//
// by James L. Hammons
// (C) 2010 Underground Software
//
// JLH = James L. Hammons <jlhamm@acm.org>
//
// Who  When        What
// ---  ----------  -------------------------------------------------------------
// JLH  01/16/2010  Created this log ;-)
//

#include "state.h"

bool SaveState(void)
{
	return false;
}

bool LoadState(void)
{
	return false;
}

