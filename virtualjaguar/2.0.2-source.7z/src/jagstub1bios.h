#ifndef __JAGSTUB1BIOS_H__
#define __JAGSTUB1BIOS_H__

extern char jaguarDevBootROM1[];

#endif	// __JAGSTUB1BIOS_H__
