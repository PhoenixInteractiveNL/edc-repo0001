//
// CRC32.H
//

#ifndef __CRC32_H__
#define __CRC32_H__

int crc32_calcCheckSum(unsigned char * data, unsigned int length);

#endif	// __CRC32_H__
