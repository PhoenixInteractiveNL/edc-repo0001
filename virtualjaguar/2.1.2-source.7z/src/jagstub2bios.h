#ifndef __JAGSTUB2BIOS_H__
#define __JAGSTUB2BIOS_H__

extern char jaguarDevBootROM2[];

#endif	// __JAGSTUB1BIOS_H__
