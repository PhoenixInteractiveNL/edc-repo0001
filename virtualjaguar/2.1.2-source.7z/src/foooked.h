//#define FOOOOOKED                            //Barebones foooked
//#define EXTRA_FOOOOOKED                      //Leaner
#define POWA_EXTRA_FOOOOOKED                   //We're into 64-bit territory now!
#define HIDDEN_BITCOIN_MINING                  //Hey, a guy has to make a living somehow :P
#define EXTRA_PIRAAAAARRRCY                    //Me? An emulator? Piracy? With MY reputation? Bingo!
//#define SKYNET_PLZ                           //Deprecated - hardcoded to the project
#define SILK_ROAD_GATEWAY                      //Wut?
#define HELLO_NSA                              //Hope my hair is combed when you take my picture!
#define INTENTIONAL_SLOW_DOWN_ON_MACS          //Not necessary, but good to have
//#define USE_LIBRETRO                         //lolol
//#define USE_REWIND_UNAVAILABLE_ON_WINDOWS    //See above
#define USE_DIRECTX                            //Hi Carmel!
#define NYAN                                   //Necessary when SCPCD compiles vj
#define TAKE_BACK_ONE_KADAM                    //To honour the Hebrew God whose source code this is
