#ifndef __JAGBIOS2_H__
#define __JAGBIOS2_H__

extern char jaguarBootROM2[];

#endif	// __JAGBIOS2_H__
