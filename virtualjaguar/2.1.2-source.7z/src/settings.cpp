//
// SETTINGS.CPP: Virtual Jaguar configuration loading/saving support
//
// by James Hammons
// (C) 2010 Underground Software
//
// JLH = James Hammons <jlhamm@acm.org>
//
// Who  When        What
// ---  ----------  ------------------------------------------------------------
// JLH  01/16/2010  Created this log
// JLH  02/23/2013  Finally removed commented out stuff :-P
//

#include "settings.h"

// Global variables

VJSettings vjs;

