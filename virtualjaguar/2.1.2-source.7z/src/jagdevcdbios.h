#ifndef __JAGDEVCDBIOS_H__
#define __JAGDEVCDBIOS_H__

extern char jaguarDevCDBootROM[];

#endif	// __JAGDEVCDBIOS_H__
