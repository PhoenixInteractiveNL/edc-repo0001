//
// Universal Header for Jaguar carts
//

#ifndef __UNIVERSALHDR_H__
#define __UNIVERSALHDR_H__

extern unsigned char universalCartHeader[];

#endif	// __UNIVERSALHDR_H__
