#ifndef __JAGDASM__
#define __JAGDASM__

#define JAGUAR_GPU 0
#define JAGUAR_DSP 1

unsigned dasmjag(int dsp_type, char *buffer, unsigned pc);

#endif
