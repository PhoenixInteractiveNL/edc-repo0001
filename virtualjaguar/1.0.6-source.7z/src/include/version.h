//
// VERSION.H: Header file
//

#ifndef __VERSION_H__
#define __VERSION_H__

#include <stdio.h>
#include <stdlib.h>

void version_init(void);
void version_display(FILE *);
void version_done(void);

#endif	// __VERSION_H__
