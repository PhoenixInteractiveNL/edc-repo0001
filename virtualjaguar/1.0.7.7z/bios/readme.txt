Place the bios here
jagboot.rom (128 Kb)
