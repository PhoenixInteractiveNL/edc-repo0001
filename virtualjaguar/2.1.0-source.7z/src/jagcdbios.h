#ifndef __JAGCDBIOS_H__
#define __JAGCDBIOS_H__

extern char jaguarCDBootROM[];

#endif	// __JAGCDBIOS_H__
