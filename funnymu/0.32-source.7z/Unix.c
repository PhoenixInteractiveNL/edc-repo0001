/** FunnyMu: portable Funvision emulator *********************/
/**                                                         **/
/**                           Unix.c                        **/
/**                                                         **/
/** This file contains Unix/X-dependent subroutines and     **/
/** drivers. It includes common drivers from Common.h.      **/
/**                                                         **/
/** Copyright (C) Paul Hayter 2001                          **/
/**     based on ColEm by Marat Fayzullin                   **/
/**                                                         **/
/** Copyright (C) Marat Fayzullin 1994-1998                 **/
/**     You are not allowed to distribute this software     **/
/**     commercially. Please, notify me, if you make any    **/
/**     changes to this file.                               **/
/*************************************************************/
#ifdef UNIX

/** Private #includes ****************************************/
#include "funny.h"
#include "LibUnix.h"

#ifdef SOUND
#include "SndUnix.h"
#endif

/** Standard Unix/X #includes ********************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>

/** Public parameters ****************************************/
char *Title="FunnyMu Unix/X 0.32"; /* Window/command line title */
int SaveCPU  = 1;               /* 1 = freeze when focus out */
int UseSHM   = 1;               /* 1 = use MITSHM            */
int UseSound = 1;               /* 1 = use sound             */

/** Various variables ****************************************/
#define WIDTH  256
#define HEIGHT 208

static byte *XBuf;
static int XPal[16],XPal0;
static Image Img;

/** Various X-related variables ******************************/
static Display *Dsp;
static Window Wnd;
static Colormap DefaultCMap;
static GC DefaultGC;
static unsigned long White,Black;

/** Sound-related definitions ********************************/
#ifdef SOUND
static int SndSwitch = 0x0F;
static int SndVolume = 200;
#endif


/** This function is called on signals ***********************/
static void OnBreak(int Arg) { ExitNow=1;signal(Arg,OnBreak); }

/** InitMachine() ********************************************/
/** Allocate resources needed by Unix/X-dependent code.     **/
/*************************************************************/
int InitMachine(void)
{
  Screen *Scr;
  int J,I;

  /* Open display */
  if(Verbose) printf("Initializing Unix/X drivers:\n  Opening display...");
  if(!(Dsp=XOpenDisplay(NULL))) { if(Verbose) puts("FAILED");return(0); }

  /* Set internal variables */
  Scr=DefaultScreenOfDisplay(Dsp);
  White=WhitePixelOfScreen(Scr);
  Black=BlackPixelOfScreen(Scr);
  DefaultGC=DefaultGCOfScreen(Scr);
  DefaultCMap=DefaultColormapOfScreen(Scr);

  /* Reset the palette */
  for(XPal0=Black,J=0;J<16;J++) XPal[J]=Black;

  /* Keys do not autorepeat */
  XAutoRepeatOff(Dsp);

  /* Initialize LibUnix toolkit */
  if(Verbose) printf("OK\n  Initializing LibUnix...");
  if(!InitLibUnix(Dsp)) { if(Verbose) puts("FAILED");return(0); }

  /* Create a window */
  if(Verbose) printf("OK\n  Opening window...");
  if(!(Wnd=X11Window(Title,WIDTH,HEIGHT)))
  { if(Verbose) puts("FAILED");return(0); }

  /* Create an image */
  if(Verbose) printf("OK\n  Allocating screen buffer...");
  J=X11NewImage(&Img,WIDTH,HEIGHT,UseSHM? USE_SHM:0);
  if(Verbose) puts(J? "OK":"FAILED");
  if(!J) return(0);
  XBuf=Img.Data;

#ifdef SOUND
  /* Initialize sound */
  if(InitSound(UseSound,Verbose))
  {
    SetChannels(SndVolume,SndSwitch);
    SetSound(3,SND_NOISE);
  }
#endif SOUND

#ifdef NEWSOUND
  sound_init();
#endif
  /* Catch all signals */
  signal(SIGHUP,OnBreak);signal(SIGINT,OnBreak);
  signal(SIGQUIT,OnBreak);signal(SIGTERM,OnBreak);

  return(1);
}

/** TrashMachine() *******************************************/
/** Deallocate all resources taken by InitMachine().        **/
/*************************************************************/
void TrashMachine(void)
{
  unsigned long L;
  int J;

  if(Verbose) printf("Shutting down...\n");

  if(Dsp)
  {
    for(XPal[0]=XPal0,J=0;J<16;J++)
      if(XPal[J]!=Black)
      { L=XPal[J];XFreeColors(Dsp,DefaultCMap,&L,1,0); }

    X11FreeImage(&Img);
    XAutoRepeatOn(Dsp);
    XCloseDisplay(Dsp);
  }

#ifdef SOUND
  TrashSound();
#endif SOUND
}

/** SetColor() ***********************************************/
/** Allocate a given color.                                 **/
/*************************************************************/
void SetColor(byte N,byte R,byte G,byte B)
{
  XColor Color;
  unsigned long L;

  if(XPal[N]!=Black)
  { L=XPal[N];XFreeColors(Dsp,DefaultCMap,&L,1,0); }

  if(!R&&!G&&!B) XPal[N]=Black;
  else
  {
    Color.flags=DoRed|DoGreen|DoBlue;
    Color.red=(int)R<<8;
    Color.green=(int)G<<8;
    Color.blue=(int)B<<8;
    XPal[N]=XAllocColor(Dsp,DefaultCMap,&Color)? Color.pixel:Black;
  }

  XPal0=XPal[0];
}

/** PutImage() ***********************************************/
/** Put an image on the screen.                             **/
/*************************************************************/
void PutImage(void)
{ X11PutImage(Wnd,&Img,0,0,0,0,WIDTH,HEIGHT); }

/** Joysticks ************************************************/
/** Check for keyboard events, parse them, and modify       **/
/** joystick controller status                              **/
/*************************************************************/
void Joysticks(void)
{
  static word JS[2] = { 0xFFFF,0xFFFF };
  static byte N=0;
  XEvent E;
  word J;

  if(XCheckWindowEvent(Dsp,Wnd,KeyPressMask|KeyReleaseMask,&E))
  {
    J=XLookupKeysym((XKeyEvent *)&E,0);
    if(E.type==KeyPress)
      switch(J)
      {
        case XK_F2:  LogSnd=!LogSnd;break;
        case XK_Escape: Reset6502(&CPU); break;

        case XK_F12: ExitNow=1;break;
#ifdef DEBUG
        case XK_F1:  CPU.Trace=!CPU.Trace;break;
#endif
#ifdef SOUND
        case XK_F6:  SetChannels(SndVolume,SndSwitch^=0x01);break;
        case XK_F7:  SetChannels(SndVolume,SndSwitch^=0x02);break;
        case XK_F8:  SetChannels(SndVolume,SndSwitch^=0x04);break;
        case XK_F9:  SetChannels(SndVolume,SndSwitch^=0x08);break;
        case XK_F10: SndSwitch=SndSwitch? 0x00:0x0F;
                     SetChannels(SndVolume,SndSwitch);break;
        case XK_Page_Up:
          if(SndVolume<250) SndVolume+=10;
          SetChannels(SndVolume,SndSwitch);
          break;
        case XK_Page_Down:
          if(SndVolume>0) SndVolume-=10;    
          SetChannels(SndVolume,SndSwitch);
          break;
#endif

        case XK_z: KEYTBL[13]&=0xf5; break;
        case XK_a: KEYTBL[13]&=0xee; break;
        case XK_q: KEYTBL[13]&=0xe7; break;
        case XK_2: KEYTBL[13]&=0xcf; break;
        case XK_x: KEYTBL[13]&=0xed; break;
        case XK_s: KEYTBL[13]&=0xde; break;
        case XK_w: KEYTBL[13]&=0xf3; break;
        case XK_3: KEYTBL[13]&=0x9f; break;
        case XK_c: KEYTBL[13]&=0xdd; break;
        case XK_d: KEYTBL[13]&=0xbe; break;
        case XK_e: KEYTBL[13]&=0xeb; break;
        case XK_4: KEYTBL[13]&=0xd7; break;
        case XK_v: KEYTBL[13]&=0xbd; break;
        case XK_f: KEYTBL[13]&=0xfc; break;
        case XK_r: KEYTBL[13]&=0xdb; break;
        case XK_5: KEYTBL[13]&=0xb7; break;
        case XK_b: KEYTBL[13]&=0xf9; break;
        case XK_g: KEYTBL[13]&=0xfa; break;
        case XK_t: KEYTBL[13]&=0xbb; break;
        case XK_6: KEYTBL[13]&=0xaf; break;
        case XK_1: KEYTBL[14]&=0xf3; break;
        case XK_BackSpace: KEYTBL[13]&=0xf6; break;

        case XK_Control_L:  KEYTBL[7]&=0x7f; break;
        case XK_Shift_L: KEYTBL[13]&=0x7f; break;
        case XK_Shift_R: KEYTBL[14]&=0x7f; break;
        case XK_Tab: KEYTBL[11]&=0x7f; break;

        case XK_colon: KEYTBL[7]&=0xf5; break;
        case XK_p: KEYTBL[7]&=0xee; break;
        case XK_semicolon: KEYTBL[7]&=0xe7; break;
        case XK_slash: KEYTBL[7]&=0xcf; break;
        case XK_0: KEYTBL[7]&=0xed; break;
        case XK_o: KEYTBL[7]&=0xde; break;
        case XK_l: KEYTBL[7]&=0xf3; break;
        case XK_period: KEYTBL[7]&=0x9f; break;
        case XK_9: KEYTBL[7]&=0xdd; break;
        case XK_i: KEYTBL[7]&=0xbe; break;
        case XK_k: KEYTBL[7]&=0xeb; break;
        case XK_comma: KEYTBL[7]&=0xd7; break;
        case XK_8: KEYTBL[7]&=0xbd; break;
        case XK_u: KEYTBL[7]&=0xfc; break;
        case XK_j: KEYTBL[7]&=0xdb; break;
        case XK_m: KEYTBL[7]&=0xb7; break;
        case XK_7: KEYTBL[7]&=0xf9; break;
        case XK_y: KEYTBL[7]&=0xfa; break;
        case XK_h: KEYTBL[7]&=0xbb; break;
        case XK_n: KEYTBL[7]&=0xaf; break;
        case XK_Return: KEYTBL[7]&=0xf6; break;
        case XK_space: KEYTBL[11]&=0xf3; break;

        case XK_Down:   KEYTBL[14]&=0xfd;break;
        case XK_Up:     KEYTBL[14]&=0xf7;break;
        case XK_Left:   KEYTBL[14]&=0xdf;break;
        case XK_Right:  KEYTBL[14]&=0xfb;break;


      }
    else
      switch(J)
      {
        case XK_z: KEYTBL[13]|=0x0a; break;
        case XK_a: KEYTBL[13]|=0x11; break;
        case XK_q: KEYTBL[13]|=0x18; break;
        case XK_2: KEYTBL[13]|=0x30; break;
        case XK_x: KEYTBL[13]|=0x12; break;
        case XK_s: KEYTBL[13]|=0x21; break;
        case XK_w: KEYTBL[13]|=0x0c; break;
        case XK_3: KEYTBL[13]|=0x60; break;
        case XK_c: KEYTBL[13]|=0x22; break;
        case XK_d: KEYTBL[13]|=0x41; break;
        case XK_e: KEYTBL[13]|=0x14; break;
        case XK_4: KEYTBL[13]|=0x28; break;
        case XK_v: KEYTBL[13]|=0x42; break;
        case XK_f: KEYTBL[13]|=0x03; break;
        case XK_r: KEYTBL[13]|=0x24; break;
        case XK_5: KEYTBL[13]|=0x48; break;
        case XK_b: KEYTBL[13]|=0x06; break;
        case XK_g: KEYTBL[13]|=0x05; break;
        case XK_t: KEYTBL[13]|=0x44; break;
        case XK_6: KEYTBL[13]|=0x50; break;
        case XK_1: KEYTBL[14]|=0x0c; break;
        case XK_BackSpace: KEYTBL[13]|=0x09; break;

        case XK_colon: KEYTBL[7]|=0x0a; break;
        case XK_p: KEYTBL[7]|=0x11; break;
        case XK_semicolon: KEYTBL[7]|=0x18; break;
        case XK_slash: KEYTBL[7]|=0x30; break;
        case XK_0: KEYTBL[7]|=0x12; break;
        case XK_o: KEYTBL[7]|=0x21; break;
        case XK_l: KEYTBL[7]|=0x0c; break;
        case XK_period: KEYTBL[7]|=0x60; break;
        case XK_9: KEYTBL[7]|=0x22; break;
        case XK_i: KEYTBL[7]|=0x41; break;
        case XK_k: KEYTBL[7]|=0x14; break;
        case XK_comma: KEYTBL[7]|=0x28; break;
        case XK_8: KEYTBL[7]|=0x42; break;
        case XK_u: KEYTBL[7]|=0x03; break;
        case XK_j: KEYTBL[7]|=0x24; break;
        case XK_m: KEYTBL[7]|=0x48; break;
        case XK_7: KEYTBL[7]|=0x06; break;
        case XK_y: KEYTBL[7]|=0x05; break;
        case XK_h: KEYTBL[7]|=0x44; break;
        case XK_n: KEYTBL[7]|=0x50; break;
        case XK_Return: KEYTBL[7]|=0x09; break;
        case XK_space: KEYTBL[11]|=0x0c; break;

        case XK_Control_L:  KEYTBL[7]|=0x80; break;
        case XK_Shift_L: KEYTBL[13]|=0x80; break;
        case XK_Shift_R: KEYTBL[14]|=0x80; break;
        case XK_Tab: KEYTBL[11]|=0x80; break;

        case XK_Down:   KEYTBL[14]|=0x02;break;
        case XK_Up:     KEYTBL[14]|=0x08;break;
        case XK_Left:   KEYTBL[14]|=0x20;break;
        case XK_Right:  KEYTBL[14]|=0x04;break;

      }
  }

  /* Export joystick states into ColEm */
  JoyState[0]=JS[0];JoyState[1]=JS[1];

  /* If saving CPU and focus is out, sleep */
  for(E.type=0;XCheckWindowEvent(Dsp,Wnd,FocusChangeMask,&E););
  if(SaveCPU&&(E.type==FocusOut))
  {
    XAutoRepeatOn(Dsp);
#ifdef SOUND
    StopSound();
#endif

    do
      while(!XCheckWindowEvent(Dsp,Wnd,FocusChangeMask,&E)&&!ExitNow)
        sleep(1);
    while((E.type!=FocusIn)&&!ExitNow);

    XAutoRepeatOff(Dsp);
#ifdef SOUND
    ResumeSound();
#endif  
  }
}

/** Part of the code common for Unix/X and MSDOS drivers ********/
#include "Common.h"

#endif /* UNIX */
