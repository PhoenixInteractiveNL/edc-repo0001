/* Hacked and botched code from Generator (Genesis emu) */
/* Generator is (c) James Ponder, 1997-2001 http://www.squish.net/generator/ */

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <math.h>

#include "funny.h"
// #include "gensound.h"
#include "gensoundp.h"
//#include "vdp.h"
//#include "ui.h"

// #ifdef JFM
// #  include "jfm.h"
// #else
// #  include "support.h"
// #  include "fm.h"
// #endif

#include <sys/soundcard.h>
#define VDP_CLOCK 53200000
//#define VDP_CLOCK 10000000
#define SOUND_DEVICE "/dev/dsp"
/*** variables externed ***/

int sound_debug = 0;            /* debug mode */
int sound_feedback = 0;         /* -1, running out of sound
                                   +0, lots of sound, do something */
unsigned int sound_minfields = 5;       /* min fields to try to buffer */
unsigned int sound_maxfields = 10;      /* max fields before blocking */
unsigned int sound_speed = SOUND_SAMPLERATE;    /* sample rate */
unsigned int sound_sampsperfield;       /* samples per field */
unsigned int sound_threshold;   /* samples in buffer aiming for */
uint8 sound_regs1[256];
uint8 sound_regs2[256];
uint8 sound_address1 = 0;
uint8 sound_address2 = 0;
uint8 sound_keys[8];
int sound_logsample = 0;        /* sample to log or -1 if none */
unsigned int sound_on = 1;      /* sound enabled */
unsigned int sound_psg = 1;     /* psg enabled */
unsigned int sound_fm = 1;      /* fm enabled */
unsigned int vdp_framerate = 50;
/* pal is lowest framerate */
uint16 sound_soundbuf[2][SOUND_MAXRATE / 50];

/*** variables externed ***/

/*** forward references ***/

/*** file scoped variables ***/

static int soundp_dev = -1;
static int soundp_format;
static int soundp_stereo;
static int soundp_frag;
static unsigned int soundp_speed;

// #ifdef JFM
// static t_jfm_ctx *sound_ctx;
// #endif

int sound_init(void) {

   
   sound_sampsperfield = sound_speed /vdp_framerate;
   sound_threshold = sound_sampsperfield * sound_minfields;
   printf("sound_init , sampsperfield = %d, threshold = %d\n",sound_sampsperfield, sound_threshold);
   soundp_start();

   SN76496Init(0,VDP_CLOCK/15,0,sound_speed);
}

/*** soundp_start - start sound hardware ***/

int soundp_start(void)
{
  audio_buf_info sound_info;

  if ((soundp_dev = open(SOUND_DEVICE, O_WRONLY, 0)) == -1) {
    printf("open " SOUND_DEVICE " failed: %s\n", strerror(errno));
    return 1;
  }
  soundp_frag = (sound_maxfields << 16 |
                 (int)(ceil(log10(sound_sampsperfield * 4) / log10(2))));
  if (ioctl(soundp_dev, SNDCTL_DSP_SETFRAGMENT, &soundp_frag) == -1) {
    printf("Error setting fragment size: %s\n", strerror(errno));
    close(soundp_dev);
    return 1;
  }
  soundp_format = AFMT_S16_LE;
  if (ioctl(soundp_dev, SNDCTL_DSP_SETFMT, &soundp_format) == -1) {
    printf("Error setting sound device format: %s\n", strerror(errno));
    close(soundp_dev);
    return 1;
  }
  if (soundp_format != AFMT_S16_LE && soundp_format != AFMT_S16_BE) {
    printf("Sound device format not supported (must be 16 bit)\n");
    close(soundp_dev);
    return 1;
  }
  soundp_stereo = 1;
  if (ioctl(soundp_dev, SNDCTL_DSP_STEREO, &soundp_stereo) == -1) {
    printf("Error setting stereo: %s\n", strerror(errno));
    close(soundp_dev);
    return 1;
  }
  if (soundp_stereo != 1) {
    printf("Sound device does not support stereo\n");
    close(soundp_dev);
    return 1;
  }
  soundp_speed = sound_speed;
  if (ioctl(soundp_dev, SNDCTL_DSP_SPEED, &soundp_speed) == -1) {
    printf("Error setting sound speed: %s\n", strerror(errno));
    close(soundp_dev);
    return 1;
  }
  if (soundp_speed != sound_speed) {
    if (abs(soundp_speed - sound_speed) < 100) {
      printf("Warning: Sample rate not exactly 22050\n");
    } else {
      printf("Sound device does not support sample rate %d "
                    "(returned %d)\n", sound_speed, soundp_speed);
      close(soundp_dev);
      return 1;
    }
  }
  if (ioctl(soundp_dev, SNDCTL_DSP_GETOSPACE, &sound_info) == -1) {
    printf("Error getting output space info\n", strerror(errno));
    close(soundp_dev);
    return 1;
  }
  printf("Total allocated fragments = %d (requested %d)\n",
               sound_info.fragstotal, sound_maxfields);
  printf("Fragment size = %d (requested %d)\n", sound_info.fragsize,
               sound_sampsperfield * 4);
  printf("Bytes free in buffer = %d\n", sound_info.bytes);
  printf("Theshold = %d bytes (%d fields of sound === %dms latency)\n",
               sound_threshold * 4, sound_minfields,
               (int)(1000 * (float)sound_minfields / (float)vdp_framerate));
  if ((signed)sound_threshold >= sound_info.bytes) {
    printf("Threshold exceeds bytes free in buffer\n");
    close(soundp_dev);
    return 1;
  }
  return 0;
}

/*** soundp_stop - stop sound hardware ***/

void soundp_stop(void)
{
  if (soundp_dev != -1)
    close(soundp_dev);
  soundp_dev = -1;
}

/*** sound_samplesbuffered - how many samples are currently buffered? ***/

int soundp_samplesbuffered(void)
{
  audio_buf_info sound_info;
  int pending;

  if (ioctl(soundp_dev, SNDCTL_DSP_GETOSPACE, &sound_info) == -1) {
    printf("Error getting output space info: %s", strerror(errno));
    return -1;
  }
  pending = (sound_info.fragstotal * sound_info.fragsize) - sound_info.bytes;
  return (pending / 4);         /* 2 bytes per sample, 2 channel stereo */
}

void soundp_output(uint16 *left, uint16 *right, unsigned int samples)
{
  uint16 buffer[(SOUND_MAXRATE / 50) * 2];      /* pal is slowest framerate */
#ifdef WORDS_BIGENDIAN
  int endian = 1;
#else
  int endian = 0;
#endif
  unsigned int i;

  if (soundp_dev == -1) 
    return;

  if (samples > (sizeof(buffer) << 1)) {
    /* we only bother with coping with one fields worth of samples */
    printf("Too many samples passed to soundp_output!");
    return;
  }
  if (soundp_format == AFMT_S16_LE && endian == 0) {
    /* device matches endianness of host */
    for (i = 0; i < samples; i++) {
      buffer[i * 2] = left[i];
      buffer[i * 2 + 1] = right[i];
    }
  } else {
    /* device is odd and is different to host endianness */
    for (i = 0; i < samples; i++) {
      buffer[i * 2] = ((left[i] >> 8) | ((left[i] << 8) & 0xff00));
      buffer[i * 2 + 1] = ((right[i] >> 8) | ((right[i] << 8) & 0xff00));
    }
  }
  if (write(soundp_dev, buffer, samples * 4) == -1) {
    if (errno != EINTR)
      printf("Error writing to sound device: %s", strerror(errno));
  }
}
