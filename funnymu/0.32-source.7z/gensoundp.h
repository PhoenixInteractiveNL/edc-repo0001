extern unsigned int vdp_framerate;
extern unsigned int sound_sampsperfield;
extern uint16 sound_soundbuf[2][SOUND_MAXRATE / 50];
int sound_init(void);
int soundp_start(void);
void soundp_stop(void);
int soundp_samplesbuffered(void);
void soundp_output(uint16 *left, uint16 *right, unsigned int samples);
