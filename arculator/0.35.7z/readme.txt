Arculator 0.35
~~~~~~~~~~~~~~

Arculator emulates an old-style Archimedes (A3xx,A4xx,A3000,A540) with an ARM2 or
ARM3, 4, 8 or 16 megabytes of RAM, and a single floppy drive.


Changes since last release :

- Fixed reading of R15 in some instructions - Nebulus now works (at least from the
  desktop)
- Sound improved a bit
- Fixed RSC instruction (don't think it affects anything though)
- Altered ARM timing
- Beginnings of new-style Arc emulation (HD floppies + IDE hard discs in theory, not 
  working yet though)
- Palette splits slightly more stable (Lotus 2)


Files
~~~~~

arculator.exe - The emulator itself.
alleg41.dll   - Required DLL file
changes.txt   - Changelog
cmos.bin      - CMOS RAM
readme.txt    - This file
src\*         - Source (needs Ming/W and Allegro to compile)


Usage
~~~~~

Just run Arculator.exe. You will need to supply the RiscOS 3 ROM images as
either a single file rom, or four files ic24.rom-ic27.rom. They can be 
dumped from a real machine with the following sequence of commands :

*SAVE ic24 3800000+80000
*SAVE ic25 3880000+80000
*SAVE ic26 3900000+80000
*SAVE ic27 3980000+80000

Alternatively you could use

*SAVE rom 3800000+200000

but you'd have fun transfering it to a PC.

Forgotten how to use an Archie? Type desktop to get to the desktop.

A bug in the emulation means that the desktop will hang sometimes.
Enabling the OS hack will work around this for now.

For speed reasons, it is best to have your desktop in 16-bit colour when running
Arculator.


Mouse
~~~~~

The mouse hack has been removed for this release. Instead, clicking on the display
will 'capture' the mouse, and pressing CTRL-END or switching to another application
will release it. With this mode, all the old problems with mouse control are gone.


Menus
~~~~~

File - Reset - soft-resets the Archimedes
       Exit  - exits back to Windows
Disc - Change disc - Loads a new disc into drives 0-3
       Remove disc - Unloads any disc that might be loaded from drives 0-3
Machine - CPU Type - Select between ARM2 and ARM3. ARM3 is quite slow on my machine (AMD
                     2400XP), though part of that is due to the video speed.
          RAM Size - Select between 4, 8 and 16 megs of RAM.
Options - Sound enable - Enables/disables sound
	  Limit speed - Limit speed to what should be about 8mhz. Sound has to be disabled
                        as well as this for any speedup to happen (and your video card has
                        to be fast enough to catch up).
          OS hack - Enables/disables OS hack - try this if RiscOS appears to
                    hang
Video - Full screen - Goes to a full screen. Use CTRL+END to return to windowed mode.
        Full borders - Toggles expansion of borders - useful for programs that overscan.


Compatibility
~~~~~~~~~~~~~

RiscOS 3 - Boots. Supervisor useable. BASIC usable. Desktop usable, with some bugs.
RiscOS 2 - Doesn't boot correctly - unusable.
Arthur   - Supervisor and BASIC usable. Hangs when trying to enter desktop,
           refuses to read most discs.


Games :

Bug Hunter 2            - Playable
Cannon Fodder           - Playable
Cataclysm               - Playable
Chuck Rock              - Playable
Cycloids                - Playable
Enter The Realm         - Playable, flickery
Gods                    - Playable
Gyrinus 2               - Playable, no music unless run from desktop
James Pond              - Playable
Lander                  - Playable
Lemmings 2              - Playable, no sound ingame
Lemmings 2 (demo)       - Playable
Lemmings                - Playable
Lemings                 - Playable
Lotus 2                 - Playable, slightly flickery palette splits
Mad Professor Mariarti  - Playable
Magic Pockets (demo)    - Playable
Moondash                - Playable
Nebulus                 - Playable from desktop only
Last Ninja (demo)       - Playable
Pacmania                - Playable
Paradroid 2000          - Playable
Repton 3                - Playable
Speedball 2             - Playable from desktop only
Spheres of Chaos (demo) - Playable
Talisman                - Playable
Terramex                - Playable
Twinworld               - Playable
Warlocks (demo)         - Playable, not sure about position of borders
Zelanites (demo)        - Playable, not sure about position of borders
Zool (demo)             - Playable

Elite            - Needs OS hack
Flashback (demo) - Needs OS hack
Starfighter 3000 - Needs OS hack, sometimes doesn't respond to keys

Bug Hunter     - Out of data error
EGO : Repton 4 - Hangs

Apps :
!65Host - Works
!ArmSI - Works. Results are about double that of the MIPs display for some reason
Coconizer - Works
Impression Jr - Works. Seems to crash after saving sometimes (but files get saved
correctly)
Logotron Pen Down 1.72 - Works
Notate - Works


Todo list :
~~~~~~~~~~~

Fix the bug relating to running programs via the desktop. (this appears to be
related to the RiscOS FIQ handling - the 1772 handler doesn't seem to be releasing
FIQs always)

Get 82c711 emulation working. It won't initialise properly - RiscOS will reset the
FDC, but won't attempt to detect any drives.

Optimize. There are a few areas in the ARM emulation that I know of that can be
optimized, and probably the video emulation as well. 

Change video emulation to use hardware bitmaps + blitting.

Add hard drive emulation. Either via hardfiles (need docs on ST506 or SCSI 
controllers) or a fileswitch module.


Tom Walker
b-em@bbcmicro.com