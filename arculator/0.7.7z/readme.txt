Arculator 0.7
~~~~~~~~~~~~~

Arculator emulates an Archimedes (old A3xx,A4xx,A3000,A540, or newer A5000,
A30x0, A4000) with an ARM2 or ARM3, 4, 8 or 16 megabytes of RAM, up to four 
floppy drives, an IDE hard disc and a multisync monitor.


Changes since last release :

- Improved video code :
  - Display centered always
  - Multisync mode support (eg 640x480, 640x512 and 800x600)
  - Borders always drawn correctly (eg Zelanites)
  - Multisync modes are a useful workaround the desktop hanging bug!
- Fixed bug with LDMxx!, !NewLook now works, Arthur desktop now works
- Fixed bug in WD1772 FDC, disc writing now works again
- Some improvements to ArculFS


Files
~~~~~

arculator.exe - The emulator itself.
alleg42.dll   - Required DLL file
changes.txt   - Changelog
cmos.bin      - CMOS RAM
readme.txt    - This file
src\*         - Source (needs Ming/W and Allegro to compile)


Usage
~~~~~

Just run Arculator.exe. You will need to supply the RiscOS 3 ROM images as
either a single file rom, or four files ic24.rom-ic27.rom. They can be 
dumped from a real machine with the following sequence of commands :

*SAVE ic24 3800000+80000
*SAVE ic25 3880000+80000
*SAVE ic26 3900000+80000
*SAVE ic27 3980000+80000

Alternatively you could use

*SAVE rom 3800000+200000

but you'd have fun transfering it to a PC.

For speed reasons, it is best to have your desktop in 16-bit colour when running
Arculator.


Menus
~~~~~

File - Reset - soft-resets the Archimedes
       Exit  - exits back to Windows
Disc - Change disc - Loads a new disc into drives 0-3
       Remove disc - Unloads any disc that might be loaded from drives 0-3
       Fast disc loading - Increases speed of WD1772 FDC only
Machine - CPU Type - Select between :
		     ARM2   - 8mhz, used on A3xx, A4xx, A3000
		     ARM250 - 12mhz, used on A3010, A3020 and A4000
		     ARM3   - 25mhz (ish) used on A4 and A5000
          RAM Size - Select between 4, 8 and 16 megs of RAM.
          FDC Type - Selects between 
                      WD1772 (old, double density only, sometimes crashes desktop, supports
                              FDI, no hard disc)
                      82c711 (new, double + high density, doesn't crash desktop, no FDI
                              support, hard disc support)
Options - Sound enable - Enables/disables sound
	  Limit speed - Limit speed to what should be about 8mhz. Sound has to be disabled
                        as well as this for any speedup to happen (and your video card has
                        to be fast enough to catch up).
Video - Full screen - Goes to a full screen. Use CTRL+END to return to windowed mode.
        Full borders - Toggles expansion of borders - useful for programs that overscan.
        Blit method - Selects between :
          Scanlines - Skip every other line to create a TV-style effect
          Software scale - Double each line in software. Reliable, but slow
          Hardware scale - Double each line in hardware. Fast, but some graphics cards 
    			   apply a filter effect.


Standard configurations
~~~~~~~~~~~~~~~~~~~~~~~

These are the standard configurations to emulate the various Archimedes models :

A3000, A3xx,  A4xx  - ARM2,   WD1772 FDC
A540                - ARM3,   WD1772 FDC
A3010, A3020, A4000 - ARM250, 82c711 FDC
A5000, A4           - ARM3,   82c711 FDC

The ARM3 emulation runs somewhere between 25 and 33 mhz (I haven't determined where yet).
The ARM2 and ARM250 run slightly faster than the real machines, as video DMA isn't taken
into account.


FAQ
~~~

Q : I'm at a supervisor prompt, how do I make it go to the desktop?
A : Type 'desktop'. If you want to avoid this, type 'configure language 10' and it
    will then go to the desktop at startup.

Q : I'm having trouble running a game
A : Some games are incompatible with RISC OS 3 (mainly pre-1990 games) and need to be run
    with RISC OS 2. Some (very old games) are incompatible with RISC OS and need to be run
    with Arthur. The only answer, short of finding a fixed version, is to track down the
    relevant OS.
    Many protected FDI images do not work as of yet. They may be made to work in the future
    however.
    Some stuff runs into other bugs in Arculator, eg Nebulus does not work with the 82c711
    FDC, for no apparent reason.
    And some just don't work (Bug Hunter, EGO : Repton 4).

Q : The picture looks blurry.
A : This is a side effect of using hardware scaling on many graphics cards. If you
    can spare the speed, go to Video->Blit method and choose one of the other blit
    modes.

Q : The sound is skipping.
A : Arculator is not able to run at full speed. Change to a slower processor emulation (ie      avoid ARM3) or change to a faster blit mode (hardware scale is faster than scanlines,       which is faster than software scale). Try setting your Windows desktop to 16-bit colour
    - when it is not in 16-bit colour Arculator has to perform an extra video conversion,
    which slows it down.
    This can happen during IDE disc access, which is unavoidable. IDE emulation is _not_
    fast. FDI disc access is also very slow, as Arculator has to decompress the disc in
    real time (the alternative would have been a very long pause when the disc image had
    been selected).


Compatibility
~~~~~~~~~~~~~

RiscOS 3 - Boots. Supervisor useable. BASIC usable. Desktop usable. Desktop hangs sometimes
           with 1772 FDC.
RiscOS 2 - Seems okay. OS Hack doesn't work, so some programs won't run. 82c711 doesn't work
           as ROS 2 doesn't support it.
Arthur   - Supervisor and BASIC usable. Hangs when trying to enter desktop,


Games :

Bug Hunter 2             - Playable
Cannon Fodder            - Playable
Cataclysm                - Playable
Chuck Rock               - Playable
Cycloids                 - Playable
Darkwood		 - Playable
Elite                    - Playable
Enter The Realm          - Playable, flickery
Flashback (demo)         - Playable
Gods                     - Playable
Gyrinus 2                - Playable, no music unless run from desktop
Inertia	(FDI)		 - Playable
James Pond               - Playable
Lander                   - Playable
Lemmings 2               - Playable
Lemmings 2 (demo)        - Playable
Lemmings                 - Playable
Lemings                  - Playable
Lotus 2                  - Playable, slightly flickery palette splits
Mad Professor Mariarti   - Playable
Magic Pockets (demo)     - Playable
Master Break             - Playable
Moondash                 - Playable
Nebulus                  - Playable, only with WD1772 FDC
Last Ninja (demo)        - Playable
Pacmania (+FDI)          - Playable
Paradroid 2000           - Playable
Phaethon                 - Playable
Repton 3                 - Playable
Saloon Cars Deluxe (FDI) - Playable
Speedball 2              - Playable
Spheres of Chaos (demo)  - Playable
Starfighter 3000 (demo)  - Playable
Talisman                 - Playable
Technodream (FDI)        - Playable
Terramex                 - Playable
Twinworld                - Playable
Warlocks (demo)          - Playable
Wolfenstein 3D (FDI)     - Playable, if you install to RAM disc (!)
Zarch (+FDI)             - Playable, don't set screen memory too high, bit flickery
Zelanites (demo)         - Playable
Zool (demo)              - Playable

Man United Europe - Bad scrolling

Bug Hunter        - Out of data error
EGO : Repton 4    - Hangs


Apps :

!65Host - Works
!ArmSI - Works. Results are about double that of the MIPS display
!ARPlayer - Works
Coconizer - Works
Impression Jr - Works. 
Logotron Pen Down 1.72 - Works
Notate - Works


Demos :

Arcangels  - Megademo    - Works (slow at times in ARM2 mode)
Arcangels  - Spinguin    - Works
Arc Empire - Transmortal - Works
Armageddon - Demo Collection 3 - Works
Armaxess   - Megademo 2  - Works
Armaxess   - Risc Dream  - Works (flickery in first part, slow on ARM2 in second part)
BIA        - BIA^2       - Works. Screen too wide for Arculator window?
BIA        - Bounce      - Works
Bytepool   - Nirvana     - Works
TXP        - Xcentric    - Works. Screen too wide for Arculator window

Arcangels  - Arcangels   - No display


Todo list :
~~~~~~~~~~~

Optimize. There are a few areas in the ARM emulation that I know of that can be
optimized, and probably the video emulation as well. 

Add FDI support to 82c711 FDC. Probably not that difficult, but after implementing it
on 1772 it's not something I really fancy doing at the minute.

Finish off ArculFS - make it read/write.


Tom Walker
b-em@bbcmicro.com

If you email me can you please state which emulator you are emailing about. Since Arculator
and RPCemu emulate similar machines it can be very difficult to tell which one you are
talking about.