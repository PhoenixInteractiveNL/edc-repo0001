Arculator 0.1
~~~~~~~~~~~~~

Arculator emulates an old-style Archimedes (A3xx,A4xx,A3000) with an ARM2, 4mb
RAM, and a single floppy drive.


Files
~~~~~

arculator.exe - The emulator itself
alleg41.dll   - Required DLL file
arc.cfg       - Configuration file
changes.txt   - Changelog
cmos.bin      - CMOS RAM
readme.txt    - This file
src\*         - Source (needs Ming/W and Allegro to compile)


Usage
~~~~~

Just run Arculator.exe. ic24.rom-ic27.rom must be present to start. 
A bug in the ARM emulation means that the desktop will hang sometimes.
Enabling the OS hack will work around this for now.


Mouse
~~~~~

With the mouse hack on, the RiscOS pointer should follow the Windows pointer.
This works fine for almost everything except Cannon Fodder. With the mouse
hack off, the pointer attempts to follow mouse movements, but use of the tilde
key (below escape) is needed to reposition the cursor.


Menus
~~~~~

File - Reset - soft-resets the Archimedes
       Exit  - exits back to Windows
Disc - Change disc - Loads a new disc
       Remove disc - Unloads any disc that might be loaded
Options - Sound enable - Enables/disables sound
	  Fast vsync  - Skips vsync calls, speeding up games/demos
	  Limit speed - Limit speed to what should be about 8mhz
	  Mouse hack - Enables/disables mouse hack
          OS hack - Enables/disables OS hack - try this if RiscOS appears to
                    hang


Compatibility
~~~~~~~~~~~~~

RiscOS 3 - Boots. Supervisor useable. BASIC usable, with some bugs. Desktop
           usable, with some bugs.
RiscOS 2 - Doesn't boot correctly - unusable.
Arthur   - Supervisor and BASIC usable. Hangs when trying to enter desktop,
           refuses to read most discs.


Games :

Cannon Fodder - Playable, mouse cursor doesn't go away when it should, disable mouse hack
Cataclysm     - Playable
Chuck Rock    - Playable
Cycloids      - Playable
Magic Pockets (demo) - Playable
Zool (demo) - Playable
Gods - Playable
Gyrinus 2 - Playable, no sound
James Pond - Playable
Lemmings 2 - Playable, no sound ingame
Lemmings 2 (demo) - Playable
Lemmings - Playable
Lemings - Playable
Mad Professor Mariarti - Playable
Man United Europe - Playable, bad scrolling
Last Ninja (demo) - Playable
Pacmania - Playable
Paradroid 2000 - Playable
Repton 3 - Playable
Speedball 2 - Playable
Spheres of Chaos (demo) - Playable
Twinworld - Playable

EGO : Repton 4 - Hangs
Elite - Needs OS hack, data abort
Flashback (demo) - Needs OS hack
Starfighter 3000 - Needs OS hack, doesn't respond properly to keys
Nebulus - Data abort
Terramex - Crashes


Apps :
!65Host - Works
Logotron Pen Down 1.72 - Works
Impression Jr - Works

Todo list :
~~~~~~~~~~~

Fix the bug relating to running programs via the desktop. (incidentally, this
appears to be the same bug that plagued Archie 0.5)

Fix up the sound. Does anyone have any documentation on the Archie sound system?
Also attempt to reduce the latency.

Optimize. There are a few areas in the ARM emulation that I know of that can be
optimized, and probably the video emulation as well.

Rewrite video emulation. Support for mid-screen palette changes should be added
at least.


Tom Walker
b-em@bbcmicro.com
