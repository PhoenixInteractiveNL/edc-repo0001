#include <stdio.h>
#include "arc.h"
#include "fdi2raw.h"

int fdiin[4];
int fdcside;
char err2[256];
FILE *olog;
FDI *fdi[4];
FILE *fdifiles[4];
int fdiopen[4]={0,0,0,0};
unsigned char mfmbuf[4][2][0x20000];
unsigned short tracktiming[0x10000];
int fdilen[4][2],indexh[4][2];
int fdilasttrack[4];
int fdipos;
int fdinextsector=0;
int fdisect,fditrack;
void (*fdiwrite)(unsigned char dat, int last);
FILE *fdidmp;
void fdireadsector(int sector, int track, void (*func)(unsigned char dat, int last));
void fdiseek(int track);
void fdiload(char *fn, int drv);
int indexpasses=0;

void fdiload(char *fn, int drv)
{
        FILE *f;
        if (!fdidmp) fdidmp=fopen("fdi.dmp","wb");
        drv&=3;
        if (fdiopen[drv]) fclose(fdifiles[drv]);
        fdifiles[drv]=fopen(fn,"rb");
        fdiin[drv]=1;
        f=fdifiles[drv];
        fdi[drv]=fdi2raw_header(f);
        fdilasttrack[drv]=fdi2raw_get_last_track(fdi[drv]);
        memset(mfmbuf[drv][0],0,0x10000);
        memset(mfmbuf[drv][1],0,0x10000);
        fdiopen[drv]=1;
//        fputs("Changed disc\n",olog);
}

void fdiseek(int track)
{
        int tracklen,indexoffset;
        int temp,c;
        unsigned short tempd[0x20000];
        unsigned char *mfmbufb;
        char s[511];
        if (track>fdilasttrack[curdrive]) track=fdilasttrack[curdrive];
//        if (!olog) olog=fopen("olog.txt","wt");
        temp=fdi2raw_loadtrack(fdi[curdrive],tempd,tracktiming,track<<1,&tracklen,&indexoffset,&mr,1);
        mfmbufb=(unsigned char *)tempd;
        for (c=0;c<tracklen;c++)
            mfmbuf[curdrive][0][c]=mfmbufb[c^1];
        if (!temp) memset(mfmbuf[curdrive][0],0,tracklen);
//        sprintf(s,"temp %i\n",temp);
//        fputs(s,olog);
        fdilen[curdrive][0]=tracklen;
        indexh[curdrive][0]=indexoffset;
        temp=fdi2raw_loadtrack(fdi[curdrive],tempd,tracktiming,(track<<1)+1,&tracklen,&indexoffset,&mr,1);
        mfmbufb=(unsigned char *)tempd;
        for (c=0;c<tracklen;c++)
            mfmbuf[curdrive][1][c]=mfmbufb[c^1];
        if (!temp) memset(mfmbuf[curdrive][1],0,tracklen);
//        sprintf(s,"temp %i\n",temp);
//        fputs(s,olog);
        fdilen[curdrive][1]=tracklen;
        indexh[curdrive][1]=indexoffset;
//        sprintf(err2,"Read track %i - %i %i  %i %i\n",track,fdilen[curdrive][0],indexh[curdrive][0],tracklen,indexoffset);
//        fputs(err2,olog);
}

void fdireadsector(int sector, int track, void (*func)(unsigned char dat, int last))
{
        char s[256];
//        if (!olog) olog=fopen("olog.txt","wt");
//        sprintf(s,"read sector %i %i\n",sector,track);
//        fputs(s,olog);
        inreadop=1;
        fdinextsector=0;
        fdisect=sector;
        fditrack=track;
        fdiwrite=func;
        indexpasses=0;
}

void fdiclose()
{
        int c;
        for (c=0;c<4;c++)
        {
                if (fdiopen[c])
                {
                        fclose(fdifiles[c]);
                }
        }
}

unsigned char decodefm(unsigned short dat)
{
        unsigned char temp;
        temp=0;
        if (dat&0x0001) temp|=1;
        if (dat&0x0004) temp|=2;
        if (dat&0x0010) temp|=4;
        if (dat&0x0040) temp|=8;
        if (dat&0x0100) temp|=16;
        if (dat&0x0400) temp|=32;
        if (dat&0x1000) temp|=64;
        if (dat&0x4000) temp|=128;
        return temp;
}

unsigned short fdibuffer;
int ddidbitsleft=0;
int pollbytesleft=0,pollbitsleft=0;
int readidpoll=0,readdatapoll=0;
unsigned char fdisector[6];
int sectorsize;
unsigned short crc;
unsigned char sectorcrc[2];
void calccrc(unsigned char byte)
{
        int i;
	for (i = 0; i < 8; i++) {
		if (crc & 0x8000) {
			crc <<= 1;
			if (!(byte & 0x80)) crc ^= 0x1021;
		} else {
			crc <<= 1;
			if (byte & 0x80) crc ^= 0x1021;
		}
		byte <<= 1;
	}
}

void fdinextbit()
{
        int tempi;
        int c;
        char s[256];
//        if (!olog) olog=fopen("olog.txt","wt");
        if (fdipos>fdilen[curdrive&3][fdcside&1])
        {
                fdipos=0;
//                fputs("Disc looping\n",olog);
        }
        if (inreadop)
        {
                tempi=mfmbuf[curdrive&3][fdcside&1][(fdipos>>3)&0xFFFF]&(1<<(7-(fdipos&7)));
                fdibuffer<<=1;
                fdibuffer|=(tempi?1:0);
//                sprintf(s,"FDI buffer %04X %i %i %i %02X %02X\n",fdibuffer,curdrive,fdcside,fdipos,mfmbuf[curdrive&3][fdcside&1][(fdipos>>3)&0xFFFF],(1<<(7-(fdipos&7))));
//                fputs(s,olog);
                if (pollbitsleft)
                {
                        pollbitsleft--;
                        if (!pollbitsleft)
                        {
                                pollbytesleft--;
                                if (pollbytesleft) pollbitsleft=16; /*Set up another word if we need it*/
                                if (readidpoll)
                                {
                                        fdisector[5-pollbytesleft]=decodefm(fdibuffer);
                                        if (!pollbytesleft)
                                        {
                                                crc=0xcdb4;
                                                calccrc(0xFE);
                                                for (c=0;c<4;c++) calccrc(fdisector[c]);
                                                if ((crc>>8)!=fdisector[4] || (crc&0xFF)!=fdisector[5])
                                                {
//                                                        sprintf(s,"Header CRC error : %02X %02X %02X %02X\n",crc>>8,crc&0xFF,fdisector[4],fdisector[5]);
//                                                        fputs(s,olog);
                                                        inreadop=0;
                                                        headercrcerror();
                                                        return;
                                                }
//                                                sprintf(s,"Found header : %02X %02X %02X %02X %02X %02X\n",fdisector[0],fdisector[1],fdisector[2],fdisector[3],fdisector[4],fdisector[5]);
//                                                fputs(s,olog);
                                                if (fdisector[0]==fditrack && fdisector[2]==fdisect)
                                                {
//                                                        fputs("Read this sector!!!\n",olog);
                                                        fdinextsector=1;
                                                        readidpoll=0;
                                                        sectorsize=(1<<(fdisector[3]+7))+2;
                                                }
                                        }
                                }
                                if (readdatapoll)
                                {
                                        if (pollbytesleft>1)
                                        {
                                                calccrc(decodefm(fdibuffer));
                                                fdiwrite(decodefm(fdibuffer),0);
                                        }
                                        else
                                           sectorcrc[1-pollbytesleft]=decodefm(fdibuffer);
                                        if (!pollbytesleft)
                                        {
                                                if ((crc>>8)!=sectorcrc[0] || (crc&0xFF)!=sectorcrc[1])
                                                {
//                                                        sprintf(s,"Data CRC error : %02X %02X %02X %02X\n",crc>>8,crc&0xFF,sectorcrc[0],sectorcrc[1]);
//                                                        fputs(s,olog);
                                                        inreadop=0;
                                                        datacrcerror();
                                                        return;
                                                }
                                                fdiwrite(decodefm(fdibuffer),1);
                                        }
                                        fputc(decodefm(fdibuffer),fdidmp);
                                        if (!pollbytesleft)
                                           readdatapoll=0;
                                }
                        }
                }
                else if (fdibuffer==0x4489)
                {
//                        fputs("Found sync\n",olog);
                        ddidbitsleft=17;
                }
                if (ddidbitsleft)
                {
                        ddidbitsleft--;
                        if (!ddidbitsleft)
                        {
                                if (decodefm(fdibuffer)==0xFE)
                                {
//                                        fputs("Sector header\n",olog);
                                        pollbytesleft=6;
                                        pollbitsleft=16;
                                        readidpoll=1;
                                }
                                else if (decodefm(fdibuffer)==0xFB)
                                {
//                                        dataheader=1;
//                                        fputs("Data header\n",olog);
                                        if (fdinextsector)
                                        {
//                                                fputs("Reading this sector\n",olog);
                                                pollbytesleft=sectorsize;
                                                pollbitsleft=16;
                                                readdatapoll=1;
                                                fdinextsector=0;
                                                crc=0xcdb4;
                                                if (fdibuffer==0xF56A) calccrc(0xF8);
                                                else                   calccrc(0xFB);
                                        }
                                }
                        }
                }
        }
        fdipos++;
        if (fdipos==indexh[curdrive&3][fdcside&1] && inreadop)
        {
                indexpasses++;
                if (indexpasses==3)
                {
                        inreadop=0;
                        sectornotfound();
                }
        }
}
