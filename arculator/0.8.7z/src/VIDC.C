/*Arculator 0.8 by Tom Walker
  VIDC10 emulation*/
#include <stdio.h>
#include <allegro.h>
#include <winalleg.h>
#include "arc.h"

/*b - memory buffer
  b2 - DirectX buffer (used for hardware blitting)*/
BITMAP *b,*b2;
int framecount=0;
int cyclesperline=0;
int redrawall;
int flyback,flybacklines=0;
int deskdepth;
int colourconv;
int videodma=0;
int palchange;
unsigned long vidlookup[256];   /*Lookup table for 4bpp modes*/

float sampdiff;
unsigned long sdif;

struct
{
        unsigned long vtot,htot,vsync;
        int line;
        int displayon,borderon;
        unsigned long addr,caddr;
        int cycs;
        int vbstart,vbend;
        int vdstart,vdend;
        int hbstart,hbend;
        int hdstart,hdend;
        int hdstart2,hdend2;
        int sync,inter;
        /*Palette lookups - pal8 for 8bpp modes, pal for all others*/
        unsigned short pal[32],pal8[256];
        int cx,cys,cye;
        int blanking;
        int scanrate;
} vidc;

int getline()
{
//        if (vidc.scanrate) return vidc.line>>1;
        return vidc.line;
}

void redolookup()
{
        int c;
        switch (vidcr[0x38]&0xF)
        {
                case 8: /*Mode 9*/
                for (c=0;c<16;c++)
                {
                        vidlookup[c]=vidc.pal[c&0xF]|(vidc.pal[c&0xF]<<16);
                }
                break;
                case 10: /*Mode 12*/
                case 11: /*Mode 27*/
                for (c=0;c<256;c++)
                {
                        vidlookup[c]=vidc.pal[c&0xF]|(vidc.pal[(c>>4)&0xF]<<16);
                }
                break;
        }
}

void recalcse()
{
        switch (vidcr[0xE0>>2]&0xC)
        {
                case 0xC: /*8bpp*/
                vidc.hdstart=(vidc.hdstart2<<1)+5;
                vidc.hdend=(vidc.hdend2<<1)+5;
                break;
                case 8: /*4bpp*/
                vidc.hdstart=(vidc.hdstart2<<1)+7;
                vidc.hdend=(vidc.hdend2<<1)+7;
                break;
                case 4: /*2bpp*/
                vidc.hdstart=(vidc.hdstart2<<1)+11;
                vidc.hdend=(vidc.hdend2<<1)+11;
                break;
                case 0: /*1bpp*/
                vidc.hdstart=(vidc.hdstart2<<1)+19;
                vidc.hdend=(vidc.hdend2<<1)+19;
                break;
        }
}

void writevidc(unsigned long v)
{
//        char s[80];
        RGB r;
        int c,d,oldscanrate=vidc.scanrate,oldvtot=vidc.vtot;
        if ((v>>26)==0x38 && v!=vidcr[0x38]) redrawall=2;
        if (((v>>24)&~0x1F)==0x60)
        {
                stereoimages[((v>>26)-1)&7]=v&7;
//                rpclog("Stereo image write %08X %i %i\n",v,((v>>26)-1)&7,v&7);
        }
        if (((v>>26)<0x14) && v!=vidcr[v>>26])
        {
                vidcr[v>>26]=v;
                r.b=(v&0xF00)>>6;
                r.g=(v&0xF0)>>2;
                r.r=(v&0xF)<<2;
                c=vidc.pal[(v>>26)&0x1F];
                vidc.pal[(v>>26)&0x1F]=makecol(r.r<<2,r.g<<2,r.b<<2);
                if (((v>>26)&0x1F)==0x10 && c!=vidc.pal[0x10])
                {
                        redrawall=2;
//                        rpclog("Border change\n");
                }
                d=v>>26;
                palchange=1;
//                if ((v>>26)==0x10)
//                   redrawall=2;
                for (c=d;c<0x100+d;c+=16)
                {
                        r.r=vidcr[d&15]&0xF;
                        r.g=(vidcr[d&15]&0xF0)>>4;
                        r.b=(vidcr[d&15]&0xF00)>>8;
                        if (c&0x10) r.r|=8; else r.r&=~8;
                        if (c&0x20) r.g|=4; else r.g&=~4;
                        if (c&0x40) r.g|=8; else r.g&=~8;
                        if (c&0x80) r.b|=8; else r.b&=~8;
                        if (c<0x100) vidc.pal8[c]=makecol(r.r<<4,r.g<<4,r.b<<4);
                }
        }
        vidcr[v>>26]=v;
        if ((v>>24)==0x80)
        {
                vidc.htot=(v&0xFFFFFF)>>14;
                cyclesperline=0;
        }
        if ((v>>24)==0xA0)
        {
                vidc.vtot=((v&0xFFFFFF)>>14)+1;
                if (vidc.vtot>400)
                   vidc.scanrate=1;
                else
                   vidc.scanrate=0;
                if ((vidc.scanrate!=oldscanrate) || (vidc.vtot!=oldvtot))
                {
                        clear(screen);
                        clear(b2);
                        clear(b);
                }
        }
        if ((v>>24)==0x84) vidc.sync=(v&0xFFFFFF);
        if ((v>>24)==0x88) vidc.hbstart=(((v&0xFFFFFF)>>14)<<1)+1;
        if ((v>>24)==0x8C)
        {
                vidc.hdstart2=((v&0xFFFFFF)>>14);
                recalcse();
        }
        if ((v>>24)==0x90)
        {
                vidc.hdend2=((v&0xFFFFFF)>>14);
                recalcse();
        }
        if ((v>>24)==0x94) vidc.hbend=(((v&0xFFFFFF)>>14)<<1)+1;
        if ((v>>24)==0x98) vidc.cx=((v&0xFFE000)>>13)+6;
        if ((v>>24)==0x9C) vidc.inter=(v&0xFFFFFF);
        if ((v>>24)==0xA4) vidc.vsync=((v&0xFFFFFF)>>14)+1;
        if ((v>>24)==0xA8)
        {
                vidc.vbstart=((v&0xFFFFFF)>>14)+1;
                redrawall=2;
        }
        if ((v>>24)==0xAC)
        {
                vidc.vdstart=((v&0xFFFFFF)>>14)+1;
                redrawall=2;
        }
        if ((v>>24)==0xB0)
        {
                vidc.vdend=((v&0xFFFFFF)>>14)+1;
                redrawall=2;
        }
        if ((v>>24)==0xB4)
        {
                vidc.vbend=((v&0xFFFFFF)>>14)+1;
                redrawall=2;
        }
        if ((v>>24)==0xB8) vidc.cys=(v&0xFFC000);
        if ((v>>24)==0xBC) vidc.cye=(v&0xFFC000);
        if ((v>>24)==0xC0)
        {
                soundhz=250000/((v&0xFF)+2);
                soundper=((v&0xFF)+2);//8000000/soundhz;
                sampdiff=200.0f/(float)soundper;
                sdif=(int)((float)sampdiff*4096.0f);
//                rpclog("Sound frequency write %08X period %i\n",v,soundper);
        }
        if ((v>>24)==0xE0)
        {
                recalcse();
                cyclesperline=0;
        }
//        printf("VIDC write %08X\n",v);
}

void clearbitmap()
{
        redrawall=2;
        clear(b);
        clear(b2);
}

void initvid()
{
        int depth;
        allegro_init();
        depth=deskdepth=desktop_color_depth();
        if (depth==16)
        {
                set_color_depth(16);
                if (set_gfx_mode(GFX_AUTODETECT_WINDOWED,800,600,0,0))
                {
                        set_color_depth(15);
                        depth=15;
                        set_gfx_mode(GFX_AUTODETECT_WINDOWED,800,600,0,0);
                }
        }
        else if (depth)
        {
                set_color_depth(depth);
                set_gfx_mode(GFX_AUTODETECT_WINDOWED,800,600,0,0);
        }
        else
           set_gfx_mode(GFX_AUTODETECT_WINDOWED,800,600,0,0);
        b2=create_system_bitmap(1024,1024);
        if (depth!=15) set_color_depth(16);
        else           set_color_depth(15);
//        set_color_depth(8);
        b=create_bitmap(1024,1024);
        vidc.line=0;
        clear(b);
        clear(b2);
}

void reinitvideo()
{
//        int c;
        destroy_bitmap(b2);
        destroy_bitmap(b);
        if (fullscreen)
        {
                set_color_depth(16);
                if (set_gfx_mode(GFX_AUTODETECT_FULLSCREEN,800,600,0,0))
                {
                        set_color_depth(15);
                        set_gfx_mode(GFX_AUTODETECT_FULLSCREEN,800,600,0,0);
                }
        }
        else
        {
                if (deskdepth==16)
                {
                        set_color_depth(16);
                        if (set_gfx_mode(GFX_AUTODETECT_WINDOWED,800,600,0,0))
                        {
                                set_color_depth(15);
                                set_gfx_mode(GFX_AUTODETECT_WINDOWED,800,600,0,0);
                        }
                }
                else if (deskdepth)
                {
                        set_color_depth(deskdepth);
                        set_gfx_mode(GFX_AUTODETECT_WINDOWED,800,600,0,0);
                }
                else
                   set_gfx_mode(GFX_AUTODETECT_WINDOWED,800,600,0,0);
                if (deskdepth!=15) set_color_depth(16);
                else               set_color_depth(15);
        }
        b=create_bitmap(1024,1024);
        b2=create_system_bitmap(1024,1024);
        clear(b2);
        clear(b);
}

//#if 0
int lastblack=0;
PALETTE pal;

void updatepal()
{
        int c;
        switch (vidcr[0x38]&0xC)
        {
                case 0x0: /*1 bpp*/
                case 0x4: /*2 bpp*/
                case 0x8: /*4 bpp*/
                for (c=0;c<20;c++)
                {
                        pal[c].r=(vidcr[c]&0xF)<<2;
                        pal[c].g=((vidcr[c]&0xF0)>>4)<<2;
                        pal[c].b=((vidcr[c]&0xF00)>>8)<<2;
                        if (!c) pal[c].b=31;
                }
                break;
                case 0xC: /*8 bpp*/
                for (c=0;c<256;c++)
                {
                        pal[c].r=vidcr[c&15]&0xF;
                        pal[c].g=(vidcr[c&15]&0xF0)>>4;
                        pal[c].b=(vidcr[c&15]&0xF00)>>8;
                        if (c&0x10) pal[c].r|=8; else pal[c].r&=~8;
                        if (c&0x20) pal[c].g|=4; else pal[c].g&=~4;
                        if (c&0x40) pal[c].g|=8; else pal[c].g&=~8;
                        if (c&0x80) pal[c].b|=8; else pal[c].b&=~8;
                        pal[c].r<<=2; pal[c].g<<=2; pal[c].b<<=2;
                }
                break;
        }
}
//#endif

void drawvid()
{
}

FILE *vlog;
int getvidcline()
{
        return vidc.line;
}
int getvidcwidth()
{
        return vidc.htot;
}

int yh,yl,xxh,xxl;

int oldflash;

int startb,endb;

void pollline()
{
//        int col=0;
        int x,xx,xl;//,y,c;
        unsigned long temp;
        unsigned long *p;
        unsigned char *bp;
//        char s[256];
        int l=(vidc.line-16);
        int xoffset,xoffset2;
        if (!vidc.scanrate && !hardwareblit) l<<=1;
        if (vidc.scanrate) l+=32;
        if (vidc.scanrate && vidc.vtot>600) l-=40;
        if (palchange)
        {
                redolookup();
                palchange=0;
        }
        flybacklines--;
//        if (flybacklines)
//        {
//                if (flybacklines==0)
                if (vidc.line==vidc.vdstart)
                {
                        vidc.addr=vinit;
                        vidc.caddr=cinit;
//                        rpclog("Reloaded addresses\n");
                }
//        }
//        rpclog("%i %i %i %i %i\n",vidc.scanrate,vidc.line,vidc.vdstart,vidc.vdend,vidc.vtot);
//        rpclog("VBSTART %i VDSTART %i\n",vidc.vbstart,vidc.vdstart);
        if (vidc.line==vidc.vbstart) { vidc.borderon=0; flyback=0; /*rpclog("border off %i %i\n",vidc.line,l);*/ }
        if (vidc.line==vidc.vdstart) { vidc.displayon=1; flyback=0; if (yl==-1) yl=l; /*rpclog("Display on %i %i\n",vidc.line,l);*/ }
        if (vidc.line==vidc.vdend)
        {
                vidc.displayon=0;
                ioc.irqa|=8;
                updateirqs();
                flyback=0x80;
                flybacklines=vidc.vsync;
                if (yh==-1) yh=l;
//                rpclog("Display off %i %i\n",vidc.line,l);
//                rpclog("Vsync interrupt\n");
        }
        if (vidc.line==vidc.vbend) { vidc.borderon=1; if (yh==-1) yh=l; /*rpclog("Border on %i %i\n",vidc.line,l);*/ }
        vidc.line++;
        videodma=vidc.addr;
//#if 0
        if (l>=0 && vidc.line<=((vidc.scanrate)?800:316))
        {
                xoffset=vidc.hbend-vidc.hbstart;
                if (!(vidcr[0x38]&2))
                {
                        xoffset=200-(xoffset>>1);
                        xoffset2=xoffset+(vidc.hdstart-vidc.hbstart);
                        xoffset<<=1;
                        xoffset2<<=1;
                }
                else
                {
                        xoffset=400-(xoffset>>1);
                        xoffset2=xoffset+(vidc.hdstart-vidc.hbstart);
                }
                if (vidc.displayon)
                {
                        bp=(unsigned char *)bmp_write_line(b,l);
                        switch (vidcr[0x38]&0xF)
                        {
                                case 2: /*Mode 0*/
                                case 3: /*Mode 25*/
                                xl=xxl=(vidc.hdend-vidc.hdstart)+xoffset2;
                                x=xxh=xoffset2;
                                for (;x<xl;x+=32)
                                {
                                        temp=ram[vidc.addr++];
                                        if (x<800)
                                        {
                                                ((unsigned short *)bp)[x]=vidc.pal[temp&1];
                                                ((unsigned short *)bp)[x+1]=vidc.pal[(temp>>1)&1];
                                                ((unsigned short *)bp)[x+2]=vidc.pal[(temp>>2)&1];
                                                ((unsigned short *)bp)[x+3]=vidc.pal[(temp>>3)&1];
                                                ((unsigned short *)bp)[x+4]=vidc.pal[(temp>>4)&1];
                                                ((unsigned short *)bp)[x+5]=vidc.pal[(temp>>5)&1];
                                                ((unsigned short *)bp)[x+6]=vidc.pal[(temp>>6)&1];
                                                ((unsigned short *)bp)[x+7]=vidc.pal[(temp>>7)&1];
                                                ((unsigned short *)bp)[x+8]=vidc.pal[(temp>>8)&1];
                                                ((unsigned short *)bp)[x+9]=vidc.pal[(temp>>9)&1];
                                                ((unsigned short *)bp)[x+10]=vidc.pal[(temp>>10)&1];
                                                ((unsigned short *)bp)[x+11]=vidc.pal[(temp>>11)&1];
                                                ((unsigned short *)bp)[x+12]=vidc.pal[(temp>>12)&1];
                                                ((unsigned short *)bp)[x+13]=vidc.pal[(temp>>13)&1];
                                                ((unsigned short *)bp)[x+14]=vidc.pal[(temp>>14)&1];
                                                ((unsigned short *)bp)[x+15]=vidc.pal[(temp>>15)&1];
                                                ((unsigned short *)bp)[x+16]=vidc.pal[(temp>>16)&1];
                                                ((unsigned short *)bp)[x+17]=vidc.pal[(temp>>17)&1];
                                                ((unsigned short *)bp)[x+18]=vidc.pal[(temp>>18)&1];
                                                ((unsigned short *)bp)[x+19]=vidc.pal[(temp>>19)&1];
                                                ((unsigned short *)bp)[x+20]=vidc.pal[(temp>>20)&1];
                                                ((unsigned short *)bp)[x+21]=vidc.pal[(temp>>21)&1];
                                                ((unsigned short *)bp)[x+22]=vidc.pal[(temp>>22)&1];
                                                ((unsigned short *)bp)[x+23]=vidc.pal[(temp>>23)&1];
                                                ((unsigned short *)bp)[x+24]=vidc.pal[(temp>>24)&1];
                                                ((unsigned short *)bp)[x+25]=vidc.pal[(temp>>25)&1];
                                                ((unsigned short *)bp)[x+26]=vidc.pal[(temp>>26)&1];
                                                ((unsigned short *)bp)[x+27]=vidc.pal[(temp>>27)&1];
                                                ((unsigned short *)bp)[x+28]=vidc.pal[(temp>>28)&1];
                                                ((unsigned short *)bp)[x+29]=vidc.pal[(temp>>29)&1];
                                                ((unsigned short *)bp)[x+30]=vidc.pal[(temp>>30)&1];
                                                ((unsigned short *)bp)[x+31]=vidc.pal[(temp>>31)&1];
                                        }
                                        if (vidc.addr==vend+4) vidc.addr=vstart;
                                }
                                break;
                                case 4: /*Mode 1*/
                                case 5:
                                xl=xxl=((vidc.hdend-vidc.hdstart)<<1)+xoffset2;
                                x=xxh=xoffset2;
                                for (;x<xl;x+=32)
                                {
                                        temp=ram[vidc.addr++];
                                        if (x<800)
                                        {
                                                ((unsigned short *)bp)[x]=((unsigned short *)bp)[x+1]=vidc.pal[temp&3];
                                                ((unsigned short *)bp)[x+2]=((unsigned short *)bp)[x+3]=vidc.pal[(temp>>2)&3];
                                                ((unsigned short *)bp)[x+4]=((unsigned short *)bp)[x+5]=vidc.pal[(temp>>4)&3];
                                                ((unsigned short *)bp)[x+6]=((unsigned short *)bp)[x+7]=vidc.pal[(temp>>6)&3];
                                                ((unsigned short *)bp)[x+8]=((unsigned short *)bp)[x+9]=vidc.pal[(temp>>8)&3];
                                                ((unsigned short *)bp)[x+10]=((unsigned short *)bp)[x+11]=vidc.pal[(temp>>10)&3];
                                                ((unsigned short *)bp)[x+12]=((unsigned short *)bp)[x+13]=vidc.pal[(temp>>12)&3];
                                                ((unsigned short *)bp)[x+14]=((unsigned short *)bp)[x+15]=vidc.pal[(temp>>14)&3];
                                                ((unsigned short *)bp)[x+16]=((unsigned short *)bp)[x+17]=vidc.pal[(temp>>16)&3];
                                                ((unsigned short *)bp)[x+18]=((unsigned short *)bp)[x+19]=vidc.pal[(temp>>18)&3];
                                                ((unsigned short *)bp)[x+20]=((unsigned short *)bp)[x+21]=vidc.pal[(temp>>20)&3];
                                                ((unsigned short *)bp)[x+22]=((unsigned short *)bp)[x+23]=vidc.pal[(temp>>22)&3];
                                                ((unsigned short *)bp)[x+24]=((unsigned short *)bp)[x+25]=vidc.pal[(temp>>24)&3];
                                                ((unsigned short *)bp)[x+26]=((unsigned short *)bp)[x+27]=vidc.pal[(temp>>26)&3];
                                                ((unsigned short *)bp)[x+28]=((unsigned short *)bp)[x+29]=vidc.pal[(temp>>28)&3];
                                                ((unsigned short *)bp)[x+30]=((unsigned short *)bp)[x+31]=vidc.pal[(temp>>30)&3];
                                        }
                                        if (vidc.addr==vend+4) vidc.addr=vstart;
                                }
                                break;
                                case 6: /*Mode 8*/
                                case 7: /*Mode 26*/
                                xl=xxl=(vidc.hdend-vidc.hdstart)+xoffset2;
                                x=xxh=xoffset2;
                                for (;x<xl;x+=16)
                                {
                                        temp=ram[vidc.addr++];
                                        if (x<800)
                                        {
                                                ((unsigned short *)bp)[x]=vidc.pal[temp&3];
                                                ((unsigned short *)bp)[x+1]=vidc.pal[(temp>>2)&3];
                                                ((unsigned short *)bp)[x+2]=vidc.pal[(temp>>4)&3];
                                                ((unsigned short *)bp)[x+3]=vidc.pal[(temp>>6)&3];
                                                ((unsigned short *)bp)[x+4]=vidc.pal[(temp>>8)&3];
                                                ((unsigned short *)bp)[x+5]=vidc.pal[(temp>>10)&3];
                                                ((unsigned short *)bp)[x+6]=vidc.pal[(temp>>12)&3];
                                                ((unsigned short *)bp)[x+7]=vidc.pal[(temp>>14)&3];
                                                ((unsigned short *)bp)[x+8]=vidc.pal[(temp>>16)&3];
                                                ((unsigned short *)bp)[x+9]=vidc.pal[(temp>>18)&3];
                                                ((unsigned short *)bp)[x+10]=vidc.pal[(temp>>20)&3];
                                                ((unsigned short *)bp)[x+11]=vidc.pal[(temp>>22)&3];
                                                ((unsigned short *)bp)[x+12]=vidc.pal[(temp>>24)&3];
                                                ((unsigned short *)bp)[x+13]=vidc.pal[(temp>>26)&3];
                                                ((unsigned short *)bp)[x+14]=vidc.pal[(temp>>28)&3];
                                                ((unsigned short *)bp)[x+15]=vidc.pal[(temp>>30)&3];
                                        }
                                        if (vidc.addr==vend+4) vidc.addr=vstart;
                                }
                                break;
                                case 8: /*Mode 9*/
                                case 9:
                                xl=xxl=((vidc.hdend-vidc.hdstart)<<1)+xoffset2;
                                x=xxh=xoffset2;
                                p=(unsigned long *)(bp+(x<<1));
                                xl-=x;
                                xl>>=1;
                                xx=x;
                                for (x=0;x<xl;x+=8)
                                {
                                        temp=ram[vidc.addr++];
                                        if (x<(800-xx))
                                        {
                                                p[0]=vidlookup[temp&0xF];
                                                p[1]=vidlookup[(temp>>4)&0xF];
                                                p[2]=vidlookup[(temp>>8)&0xF];
                                                p[3]=vidlookup[(temp>>12)&0xF];
                                                p[4]=vidlookup[(temp>>16)&0xF];
                                                p[5]=vidlookup[(temp>>20)&0xF];
                                                p[6]=vidlookup[(temp>>24)&0xF];
                                                p[7]=vidlookup[(temp>>28)&0xF];
                                                p+=8;
                                        }
                                        if (vidc.addr==vend+4) vidc.addr=vstart;
                                }
                                xl=((vidc.hdend-vidc.hdstart)<<1)+xoffset2;
                                break;
                                case 10: /*Mode 12*/
                                case 11: /*Mode 27*/
                                xl=xxl=(vidc.hdend-vidc.hdstart)+xoffset2;
                                x=xxh=xoffset2;
                                p=(unsigned long *)(bp+(x<<1));
                                xl-=x;
                                xl>>=1;
                                xx=x;
                                for (x=0;x<xl;x+=4)
                                {
                                        temp=ram[vidc.addr++];
                                        if (x<(800-xx))
                                        {
                                                p[0]=vidlookup[temp&0xFF];
                                                p[1]=vidlookup[(temp>>8)&0xFF];
                                                p[2]=vidlookup[(temp>>16)&0xFF];
                                                p[3]=vidlookup[(temp>>24)&0xFF];
                                                p+=4;
                                        }
                                        if (vidc.addr==vend+4) vidc.addr=vstart;
                                }
                                xl=(vidc.hdend-vidc.hdstart)+xoffset2;
                                break;
                                case 12: /*Mode 13*/
                                case 13:
                                xl=xxl=((vidc.hdend-vidc.hdstart)<<1)+xoffset2;
                                x=xxh=xoffset2;
                                for (;x<xl;x+=8)
                                {
                                        temp=ram[vidc.addr++];
                                        if (x<800)
                                        {
                                                ((unsigned short *)bp)[x]=((unsigned short *)bp)[x+1]=vidc.pal8[temp&0xFF];
                                                ((unsigned short *)bp)[x+2]=((unsigned short *)bp)[x+3]=vidc.pal8[(temp>>8)&0xFF];
                                                ((unsigned short *)bp)[x+4]=((unsigned short *)bp)[x+5]=vidc.pal8[(temp>>16)&0xFF];
                                                ((unsigned short *)bp)[x+6]=((unsigned short *)bp)[x+7]=vidc.pal8[(temp>>24)&0xFF];
                                        }
                                        if (vidc.addr==vend+4) vidc.addr=vstart;
                                }
                                break;
                                case 14: /*Mode 15*/
                                case 15: /*Mode 28*/
                                xl=xxl=(vidc.hdend-vidc.hdstart)+xoffset2;
                                x=xxh=xoffset2;
                                for (;x<xl;x+=4)
                                {
                                        temp=ram[vidc.addr++];
                                        if (x<800)
                                        {
                                                ((unsigned short *)bp)[x]=vidc.pal8[temp&0xFF];
                                                ((unsigned short *)bp)[x+1]=vidc.pal8[(temp>>8)&0xFF];
                                                ((unsigned short *)bp)[x+2]=vidc.pal8[(temp>>16)&0xFF];
                                                ((unsigned short *)bp)[x+3]=vidc.pal8[(temp>>24)&0xFF];
                                        }
                                        if (vidc.addr==vend+4) vidc.addr=vstart;
                                }
                                break;

                                default:
                                textprintf(b,font,0,0,0x7FFF,"%i",(int)(vidcr[0x38]&0xF));
                        }
                        if (((vidc.cys>>14)+2)<=vidc.line && ((vidc.cye>>14)+2)>vidc.line)
                        {
                                switch (vidcr[0x38]&0xF)
                                {
                                        case 0: /*Mode 4*/
                                        case 1:
                                        case 4: /*Mode 1*/
                                        case 5:
                                        case 8: /*Mode 9*/
                                        case 9:
                                        case 12: /*Mode 13*/
                                        case 13:
                                        x=((vidc.cx-vidc.hdstart)<<1)+xoffset2;
                                        if (x>800) break;
                                        temp=ram[vidc.caddr++];
                                        for (xx=0;xx<32;xx+=2)
                                        {
                                                if (temp&3) ((unsigned short *)bp)[x+xx]=((unsigned short *)bp)[x+xx+1]=vidc.pal[(temp&3)|0x10];
                                                temp>>=2;
                                        }
                                        temp=ram[vidc.caddr++];
                                        for (xx=32;xx<64;xx+=2)
                                        {
                                                if (temp&3) ((unsigned short *)bp)[x+xx]=((unsigned short *)bp)[x+xx+1]=vidc.pal[(temp&3)|0x10];
                                                temp>>=2;
                                        }
//                                        hline(b,x,l,x+31,0xFFFF);
                                        break;

                                        case 2:  /*Mode 0*/
                                        case 3:  /*Mode 25*/
                                        case 6:  /*Mode 8*/
                                        case 7:  /*Mode 26*/
                                        case 10: /*Mode 12*/
                                        case 11: /*Mode 27*/
                                        case 14: /*Mode 15*/
                                        case 15: /*Mode 28*/
                                        x=(vidc.cx-vidc.hdstart)+xoffset2;
                                        if (x>800) break;
                                        temp=ram[vidc.caddr++];
                                        for (xx=0;xx<16;xx++)
                                        {
                                                if (temp&3) ((unsigned short *)bp)[x+xx]=vidc.pal[(temp&3)|0x10];
                                                temp>>=2;
                                        }
                                        temp=ram[vidc.caddr++];
                                        for (xx=16;xx<32;xx++)
                                        {
                                                if (temp&3) ((unsigned short *)bp)[x+xx]=vidc.pal[(temp&3)|0x10];
                                                temp>>=2;
                                        }
//                                        hline(b,x,l,x+31,0xFFFF);
                                        break;
                                }
                        }
//                        bmp_unwrite_line(b);
                        switch (vidcr[0x38]&0xF)
                        {
                                case 0: /*Mode 4*/
                                case 1:
                                case 4: /*Mode 1*/
                                case 5:
                                case 8: /*Mode 9*/
                                case 9:
                                case 12: /*Mode 13*/
                                case 13:
                                if (vidc.hbstart<vidc.hdstart)
                                   hline(b,startb,l,xoffset2-1,vidc.pal[0x10]);
                                else
                                   hline(b,startb,l,xoffset-1,vidc.pal[0x10]);
                                if ((xoffset+((vidc.hbend-vidc.hbstart)<<1))<xl)
                                   hline(b,xoffset+((vidc.hbend-vidc.hbstart)<<1),l,endb,vidc.pal[0x10]);
                                else
                                   hline(b,xl,l,endb,vidc.pal[0x10]);
                                break;
                                case 2:  /*Mode 0*/
                                case 3:  /*Mode 25*/
                                case 6:  /*Mode 8*/
                                case 7:  /*Mode 26*/
                                case 10: /*Mode 12*/
                                case 11: /*Mode 27*/
                                case 14: /*Mode 15*/
                                case 15: /*Mode 28*/
                                if (vidc.hbstart<vidc.hdstart)
                                   hline(b,startb,l,xoffset2-1,vidc.pal[0x10]);
                                else
                                   hline(b,startb,l,xoffset-1,vidc.pal[0x10]);
                                if (vidc.hbend<xl)
                                   hline(b,xoffset+(vidc.hbend-vidc.hbstart),l,endb,vidc.pal[0x10]);
                                else
                                   hline(b,xl,l,endb,vidc.pal[0x10]);
                                break;
                        }
                        if (dblscan && !hardwareblit && !vidc.scanrate)
                        {
                                if (fullborders || fullscreen)
                                   blit(b,b,0,l,0,l+1,800,1);
                                else
                                   blit(b,b,60,l,60,l+1,672,1);
                        }
                }
                if (vidc.blanking && redrawall)
                {
                        hline(b,startb,l,799,0);
                        if (dblscan && !vidc.scanrate)
                           hline(b,startb,l+1,799,0);
                }
                else if ((vidc.borderon || !vidc.displayon) && redrawall)
                {
                        hline(b,startb,l,799,vidc.pal[16]);
                        if (dblscan && !vidc.scanrate)
                           hline(b,startb,l+1,799,vidc.pal[16]);
                }
//                if (vidc.displayon)
//#if 0
                if (hardwareblit)// && !vidc.scanrate)
                {
                        if (redrawall)
                        {
                                if (fullborders || fullscreen)
                                   blit(b,b2,0,l,0,l,799,1);
                                else
                                   blit(b,b2,60,l,60,l,672,1);
                        }
                        else
                           blit(b,b2,xxh,l,xxh,l,xxl-xxh,1);
/*                        }
                        else
                        {
//                                rpclog("Blitting from line %i to %i\n",l,l>>1);
                                if (fullborders || fullscreen)
                                   blit(b,b2,0,l,0,l>>1,799,1);
                                else
                                   blit(b,b2,60,l,60,l>>1,672,1);
                        }*/
                }
//#endif
//                bmp_unwrite_line(b);
        }
        videodma=(vidc.addr-videodma);
        if (videodma>0)
        {
                videodma>>=2;
                videodma*=5;
                videodma<<=1;
        }
        else
           videodma=0;
//        videodma=0;
//        rpclog("Video DMA %i cycles\n",videodma);
//#endif
//        if (vidc.line==vidc.vsync) vidc.blanking=1;
//        #if 0
        if (vidc.line>=vidc.vtot)// || (vidc.line==313 && !vidc.scanrate))
        {
                vidc.blanking=0;
                if (vidc.displayon)
                {
                        vidc.displayon=0;
                        ioc.irqa|=8;
                        updateirqs();
                        flyback=0x80;
                        flybacklines=vidc.vsync;
//                        rpclog("Vsync interrupt late %i %i\n",vidc.line,vidc.vtot);
                        yh=l;
//                        if (!olog) olog=fopen("armlog.txt","wt");
//                        sprintf(s,"VBLANK\n");
//                        fputs(s,olog);
                }
//                #if 0
//                rpclog("Drawscreen\n");
//                #if 0
//                if (vidc.line==vidc.vtot)
//                {
//                        rpclog("Blit\n");
                        framecount++;
//                        textprintf(b,font,0,0,0x7FFF,"%i %i %i %i %i %i %08X",vidc.vsync,vidc.vtot,vidc.vdstart,vidc.vdend,vidc.vbstart,vidc.vbend,vidcr[0xb0>>2]);
                        if (!redrawall && oldflash^(readflash[0]|readflash[1]|readflash[2]|readflash[3]))
                        {
                                if (fullborders|fullscreen)
                                {
                                        if (!readflash[0]) rectfill(screen,780,4,796,8,vidc.pal[16]);
                                        if (!readflash[1]) rectfill(screen,760,4,776,8,vidc.pal[16]);
                                        if (!readflash[2]) rectfill(screen,740,4,756,8,vidc.pal[16]);
                                        if (!readflash[3]) rectfill(screen,720,4,736,8,vidc.pal[16]);
                                        if (!dblscan) hline(screen,720,5,796,0);
                                        if (!dblscan) hline(screen,720,7,796,0);
                                }
                                else
                                {
                                        if (!readflash[0]) rectfill(screen,652,4,668,8,vidc.pal[16]);
                                        if (!readflash[1]) rectfill(screen,632,4,648,8,vidc.pal[16]);
                                        if (!readflash[2]) rectfill(screen,612,4,628,8,vidc.pal[16]);
                                        if (!readflash[3]) rectfill(screen,592,4,608,8,vidc.pal[16]);
                                        if (!dblscan) hline(screen,592,5,668,0);
                                        if (!dblscan) hline(screen,592,7,668,0);
                                }
                        }
                        oldflash=readflash[0]|readflash[1]|readflash[2]|readflash[3];
//                        #if 0
                        if (fullborders|fullscreen)
                        {
                                if (redrawall)
                                {
                                        if (hardwareblit)
                                        {
                                                if (vidc.scanrate)
                                                   blit(b2,screen,0,0,0,0,800,600);
                                                else
                                                   stretch_blit(b2,screen,0,0,800,300,0,0,800,600);
                                        }
                                        else
                                        {
                                                blit(b,screen,0,0,0,0,800,600);
                                        }
                                        redrawall--;
                                }
                                else
                                {
//                                        rpclog("Blit %i,%i %i,%i %i %i\n",xxh,yl,xxl,yh,hardwareblit,vidc.scanrate);
                                        if (hardwareblit)
                                        {
                                                if (vidc.scanrate)
                                                   blit(b2,screen,xxh,yl,xxh,yl,xxl-xxh,yh-yl);
                                                else
                                                   stretch_blit(b2,screen,xxh,yl,xxl-xxh,(yh-yl), xxh,(yl<<1),xxl-xxh,(yh-yl)<<1);
                                        }
                                        else
                                        {
                                                blit(b,screen,xxh,yl,xxh,yl,xxl-xxh,yh-yl);
                                        }
                                }
                                xxh=xxl=yh=yl=-1;
                        }
                        else
                        {
//                                rpclog("YL=%i YH=%i   ",yl,yh);
                                if (redrawall)
                                {
                                        xxh=60;
                                        yl=24;//12;
                                        xxl=732;
                                        yh=568;//284;
                                        if (vidc.scanrate)
                                        {
                                                yl-=16;
                                                yh-=16;
                                        }
                                        else if (hardwareblit)
                                        {
                                                yl=12;
                                                yh=284;
                                        }
                                }
/*                                else if (vidc.scanrate)
                                {
                                        yl>>=1;
                                        yh>>=1;
                                }*/
//                                rpclog("YL=%i YH=%i   ",yl,yh);
//                                yl<<=1;
//                                yh<<=1;
//                                rpclog("YL=%i YH=%i\n",yl,yh);
                                if (hardwareblit)// && !vidc.scanrate)
                                {
                                        if (vidc.scanrate)
                                        {
//                                                yl+=16;
//                                                yh+=16;
//                                                if (yl>24) yl-=2;
//                                                rpclog("Blitting s %i %i %i %i %i %i\n",yl,yh,xxl,xxh,yh-yl,redrawall);
                                                blit(b2,screen,xxh,yl,xxh-60,yl-24,xxl-xxh,yh-yl);
//                                                hline(screen,0,yl-24,671,makecol(255,255,255));
//                                                hline(screen,0,yh-24,671,makecol(255,255,255));
                                        }
                                        else
                                        {
//                                                rpclog("Blitting %i %i %i %i  %i %i %i %i\n",yl,yh,xxl,xxh,bitmap_color_depth(b),bitmap_color_depth(b2),bitmap_color_depth(screen),gfx_capabilities&GFX_HW_SYS_TO_VRAM_BLIT);
//                                                acquire_bitmap(b2);
//                                                blit(b,b2,xxh,yl,xxh,yl,xxl-xxh,yh-yl);
//                                                release_bitmap(b2);
//                                                rpclog("Blit size %i,%i\n",xxl-xxh,yh-yl);
                                                if (((yl<<1)-24)<0)
                                                   yl=12;
                                                if ((xxh-60)<0)
                                                   xxh=60;
                                                if ((xxl-60)>=672)
                                                   xxl=672+60;
                                                if (((yh<<1)-24)>=544)
                                                   yh=272+12;
//                                                rpclog("Blit from %i,%i to %i,%i\n",xxh-60,(yl<<1)-24,(xxh-60)+(xxl-xxh),((yl<<1)-24)+((yh-yl)<<1));
                                                stretch_blit(b2,screen,xxh,yl,xxl-xxh,(yh-yl), xxh-60,(yl<<1)-24,xxl-xxh,(yh-yl)<<1);
                                        }
                                }
                                else
                                {
//                                        yl+=16;
//                                        yh+=16;
//                                        rpclog("Blitting %i %i\n",yl,yh);
//                                        clear(screen);
                                        blit(b,screen,xxh,yl,xxh-60,yl-24,xxl-xxh,yh-yl);
//                                        textprintf(screen,font,0,0,makecol(255,255,255),"%i %i %i %i\n",xxh,xxl,yl,yh);
//                                        hline(screen,0,yl-24,639,makecol(255,255,255));
//                                        hline(screen,0,(yl-24)+(yh-yl),639,makecol(255,255,255));
                                }
                                if (redrawall) redrawall--;
                                xxh=xxl=yh=yl=-1;
                        }
//                        #endif
//                        textprintf(screen,font,0,0,makecol(255,255,255),"%02X %02X %02X %02X",ioc.mska,ioc.mskb,ioc.irqa,ioc.irqb);
/*                        else
                        {
                                for (y=0;y<544;y+=2)
                                    blit(b,screen,60,y+24,0,y,672,1);
                        }*/

                        if (fullborders|fullscreen)
                        {
                                if (readflash[0]) rectfill(screen,780,4,796,8,makecol(255,160,32));
                                if (readflash[1]) rectfill(screen,760,4,776,8,makecol(255,160,32));
                                if (readflash[2]) rectfill(screen,740,4,756,8,makecol(255,160,32));
                                if (readflash[3]) rectfill(screen,720,4,736,8,makecol(255,160,32));
                        }
                        else
                        {
                                if (readflash[0]) rectfill(screen,652,4,668,8,makecol(255,160,32));
                                if (readflash[1]) rectfill(screen,632,4,648,8,makecol(255,160,32));
                                if (readflash[2]) rectfill(screen,612,4,628,8,makecol(255,160,32));
                                if (readflash[3]) rectfill(screen,592,4,608,8,makecol(255,160,32));
                        }
                        readflash[0]=readflash[1]=readflash[2]=readflash[3]=0;
                        if (fullborders || fullscreen)
                        {
                                startb=0;
                                endb=799;
                        }
                        else
                        {
                                startb=60;
                                endb=731;
                        }
//                }
//                #endif
                vidc.line=0;
/*                if (!(vidcr[0x38]&3)) offsetx=((vidc.hdstart+1)<<2)-176;
                else                  offsetx=((vidc.hdstart+1)<<1)-176;
                offsety=(vidc.vdstart-16)<<1;
                if (!fullborders)
                {
                        offsetx-=60;
                        offsety-=24;
                }*/
        }
//        #endif
}

int vidcgetcycs()
{
        int temp;
        if (cyclesperline)
        {
                return cyclesperline-videodma;
//                if (vidc.displayon) return cyclesperline-200;
//                return cyclesperline;
        }
        temp=(vidc.htot+1)<<1;
//        rpclog("Vidcycs %i ",temp);
        switch (vidcr[0x38]&3)
        {
                case 2: temp>>=1; break;
                case 3: temp/=3; break;
        }
//        rpclog("%i  ",temp);
//        if (vidcr[0x38]&2) temp>>=1;
        vidc.cycs=temp<<1;
        if (!speed) cyclesperline=(temp<<1);
        else if (speed==1) cyclesperline=(temp*3);
        else cyclesperline=(temp*6);
//        rpclog("%i\n",cyclesperline);
        return cyclesperline;
}

int vidcgetoverflow()
{
        return videodma;
//        if (cyclesperline && vidc.displayon) return videodma;
        return 0;
}

int vidcgetendline()
{
        int temp=(vidc.hbend+1)<<1;
        if (vidcr[0x38]&2) temp>>=1;
//        vidc.cycs=temp<<1;
        if (!speed) return temp<<1;
        else if (speed==1) return temp*3;
        return temp*6;
}

//117-436
void dumpvid()
{
        int c,x,y;
        unsigned char temp;
        BITMAP *b;
        allegro_init();
        set_gfx_mode(GFX_AUTODETECT,640,480,0,0);
        b=create_bitmap(640,256);
        c=0;
        for (y=0;y<256;y++)
        {
                for (x=0;x<640;x+=8)
                {
                        temp=((unsigned char *)ram)[c]; c++;
                        b->line[y][x+7]=(temp>>7)&1;
                        b->line[y][x+6]=(temp>>6)&1;
                        b->line[y][x+5]=(temp>>5)&1;
                        b->line[y][x+4]=(temp>>4)&1;
                        b->line[y][x+3]=(temp>>3)&1;
                        b->line[y][x+2]=(temp>>2)&1;
                        b->line[y][x+1]=(temp>>1)&1;
                        b->line[y][x+0]=temp&1;
                }
        }
        save_pcx("arc.pcx",b,desktop_palette);
}

void setredrawall()
{
        redrawall=2;
        clear(b);
        clear(b2);
}
