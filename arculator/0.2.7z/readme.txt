Arculator 0.2
~~~~~~~~~~~~~

Arculator emulates an old-style Archimedes (A3xx,A4xx,A3000,A540) with an ARM2 or
ARM3, 4, 8 or 16 megabytes of RAM, and a single floppy drive.


Changes since last release :

- Added support for dual/quad MEMCs (8 and 16 megs of RAM)
- ARM3 emulation
- ARM & video optimisations - 25% speed boost
- Rewritten video emulation - support midscreen palette/mode changes, correct
  cursor in 256 colour modes, better scrolling in hardware scrolling games, etc.
- Reduced sound lag and improved sound overall
- Added fullscreen mode.


Files
~~~~~

arculator.exe - The emulator itself.
alleg41.dll   - Required DLL file
changes.txt   - Changelog
cmos.bin      - CMOS RAM
readme.txt    - This file
src\*         - Source (needs Ming/W and Allegro to compile)


Usage
~~~~~

Just run Arculator.exe. You will need to supply the RiscOS 3 ROM images as
ic24.rom-ic27.rom. They can be dumped from a real machine with the following
sequence of commands :

*SAVE ic24 3800000+80000
*SAVE ic25 3880000+80000
*SAVE ic26 3900000+80000
*SAVE ic27 3980000+80000

A bug in the ARM emulation means that the desktop will hang sometimes.
Enabling the OS hack will work around this for now.


Mouse
~~~~~

With the mouse hack on, the RiscOS pointer should follow the Windows pointer.
This works fine for almost everything except Cannon Fodder. With the mouse
hack off, the pointer attempts to follow mouse movements, but use of the tilde
key (below escape) is needed to reposition the cursor.
In fullscreen none of this actually matters and the mouse pointer works correctly all
the time.


Menus
~~~~~

File - Reset - soft-resets the Archimedes
       Exit  - exits back to Windows
Disc - Change disc - Loads a new disc
       Remove disc - Unloads any disc that might be loaded
Machine - CPU Type - Select between ARM2 and ARM3. ARM3 is quite slow on my machine (AMD
                     2400XP), though part of that is due to the video speed.
          RAM Size - Select between 4, 8 and 16 megs of RAM.
Options - Sound enable - Enables/disables sound
	  Limit speed - Limit speed to what should be about 8mhz. Sound has to be disabled
                        as well as this for any speedup to happen (and your video card has
                        to be fast enough to catch up).
	  Mouse hack - Enables/disables mouse hack
          OS hack - Enables/disables OS hack - try this if RiscOS appears to
                    hang
Video - Full screen - Goes to a full screen. Use CTRL+END to return to windowed mode.
        Full borders - Toggles expansion of borders - useful for programs that overscan.


Compatibility
~~~~~~~~~~~~~

RiscOS 3 - Boots. Supervisor useable. BASIC usable, with some bugs. Desktop
           usable, with some bugs.
RiscOS 2 - Doesn't boot correctly - unusable.
Arthur   - Supervisor and BASIC usable. Hangs when trying to enter desktop,
           refuses to read most discs.


Games :

Cannon Fodder           - Playable, some mouse problems (disable mouse hack)
Cataclysm               - Playable
Chuck Rock              - Playable
Cycloids                - Playable
Gods                    - Playable
Gyrinus 2               - Playable, no sound
James Pond              - Playable
Lemmings 2              - Playable, no sound ingame
Lemmings 2 (demo)       - Playable
Lemmings                - Playable
Lemings                 - Playable
Mad Professor Mariarti  - Playable
Magic Pockets (demo)    - Playable
Last Ninja (demo)       - Playable
Pacmania                - Playable
Paradroid 2000          - Playable
Repton 3                - Playable
Speedball 2             - Playable
Spheres of Chaos (demo) - Playable
Twinworld               - Playable
Zool (demo)             - Playable

EGO : Repton 4   - Hangs
Elite            - Needs OS hack, data abort
Flashback (demo) - Needs OS hack
Starfighter 3000 - Needs OS hack, doesn't respond properly to keys
Nebulus          - Data abort
Terramex         - Crashes


Apps :
!65Host                - Works
Logotron Pen Down 1.72 - Works
Notate                 - Works
Impression Jr          - Works

Todo list :
~~~~~~~~~~~

Fix the bug relating to running programs via the desktop. (incidentally, this
appears to be the same bug that plagued Archie 0.5)

Fix up the sound. Does anyone have any documentation on the Archie sound system?

Optimize. There are a few areas in the ARM emulation that I know of that can be
optimized, and probably the video emulation as well. The biggest bottleneck at
the moment appears to be the blit from backbuffer to screen - on my machine, if
the blit size is dropped slightly, the speed is nearly doubled.


Tom Walker
b-em@bbcmicro.com