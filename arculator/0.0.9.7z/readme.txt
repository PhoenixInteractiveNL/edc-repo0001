Arculator 0.09
~~~~~~~~~~~~~~

This is an actual release of the Acorn Archimedes emulator Arculator. This
time you can load some stuff up

If anyone can fix the hanging disc bug, please email me. A hack is in place to
work around this, but many programs still have loading problems.


Files -

arculator.exe - The emulator itself
alleg41.dll   - Required DLL
arc.cfg       - Config file
cmos.bin      - CMOS RAM
readme.txt    - This file
changes.txt   - Changelog
src\*         - Source (needs Ming/W and Allegro to compile)
test.adf      - Test disc image (Armaxess Megademo 2)

Usage -

Just run arculator.exe. ic24.rom-ic27.rom must be present to start. 

Menus -

File - Reset - soft-resets the Archimedes
       Exit  - exits back to Windows
Disc - Change disc - Loads a new disc
       Remove disc - Unloads any disc that might be loaded
Options - Disc hack   - Enables the disc hack, which gets some stuff to load
          Fast vsync  - Skips vsync calls, speeding up games/demos
	  Limit speed - Limit speed to what should be about 8mhz
	  Log sound   - Turns sound logging on/off.
                        Sound logging creates 'sound.pcm', 16-bit mono.


Compatibility -

RiscOS 3 - Boots. Supervisor useable. BASIC seems fines. Desktop seems fine.
           Hangs during most file loading.
Arthur   - BASIC and Supervisor seem okay. Hangs at *DESKTOP though.
RiscOS 2 - Lost the ROM dump for this one.

Games :

Lemmings 2 demo - Playable, bad cursor colours on menu, bad panel colours ingame.
Mad Professor   - Playable, some levels don't load.
Lemmings        - Playable, most levels don't load, doesn't like sound logging.
Cannon Fodder   - Intro works, hangs loading game
Lemmings 2      - Hangs loading

Demos :

Armaxess - Megademo 2 - works
TCD      - Demo 2     - doesn't

Tom Walker
tommowalker@yahoo.co.uk