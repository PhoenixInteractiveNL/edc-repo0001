/*Arculator 0.4 by Tom Walker
  82c711 emulation - NOT WORKING YET*/
#include <windows.h>
#include <stdio.h>
#include "arc.h"

FILE *olog;
int discint,discrint;
int output,timetolive;
int fdcindex;

struct pccombo
{
        unsigned char scratch1,scratch2;
        unsigned char byteformat2;
        unsigned char dor,status;
        int fdcreset;
        int incommand;
        unsigned char command,lastcommand;
        unsigned char st0,st1,st2,st3;
        int track;
        int pos;
        int justreset;
        int params,curparam;
        unsigned char p[10];
} pccombo;

unsigned char read82c711(unsigned long a)
{
        char s[256];
/*        sprintf(s,"Read %07X %07X\n",a,PC);
        if (!olog) olog=fopen(".txt","wt");
        fputs(s,olog);*/
        switch (a)
        {
//                case 0x3010BE8: /*Serial interrupt register*/
//                return 0;
                case 0x3010BFC: /*Serial scratch register*/
                return pccombo.scratch2;
                case 0x3010FD0: /*FDC status register*/
//                sprintf(s,"Reading FDC status %02X\n",pccombo.status);
//                fputs(s,olog);
                ioc.irqb&=~0x10;
                updateirqs();
                return pccombo.status;
                case 0x3010FD4: /*FDC data register*/
                switch (pccombo.command)
                {
                        case 8: /*Sense interrupt status*/
//                        sprintf(s,"Reading interrupt status %i %02X %02X %02X\n",pccombo.pos,pccombo.st0,pccombo.status,pccombo.track);
//                        fputs(s,olog);
                        if (!pccombo.pos)
                        {
                                pccombo.pos=1;
                                return pccombo.st0;
                        }
                        pccombo.incommand=0;
                        pccombo.status=0x80;
                        if (pccombo.fdcreset==5)   pccombo.fdcreset=0;
                        else if (pccombo.fdcreset) discrint=100;
                        pccombo.command=0;
                        pccombo.st0=0;
                        return pccombo.track;
                }
                sprintf(s,"Bad read FDC data command %02X\n",pccombo.command);
                MessageBox(NULL,s,"Arculator",MB_OK);
                dumpregs();
                exit(-1);
                case 0x3010FEC: /*Byte format*/
                return pccombo.byteformat2;
                case 0x3010FF8: /*Modem status*/
                return 0;
                case 0x3010FFC: /*Serial scratch register*/
                return pccombo.scratch1;
                case 0x302C03C: /*?*/
                return 0xFF;
                default:
                sprintf(s,"Bad 82c711 read %07X\n",a);
                MessageBox(NULL,s,"Arculator",MB_OK);
                dumpregs();
                exit(-1);
        }
}

void write82c711(unsigned long a, unsigned char v)
{
        char s[256];
/*        sprintf(s,"Write %07X %02X %07X\n",a,v,PC);
        if (!olog) olog=fopen("olog.txt","wt");
        fputs(s,olog);*/
        switch (a)
        {
                case 0x30109E8: /*Parallel control*/
                return;
                case 0x3010BE8: /*Serial interrupt register*/
                return;
                case 0x3010BFC: /*Serial scratch register*/
                pccombo.scratch1=v;
                return;
                case 0x3010E40: /*???*/
                case 0x3010E44: /*???*/
                case 0x3010FC0: /*???*/
                case 0x3010FC4: /*???*/
                return;
                case 0x3010FC8: /*FDC drive output register*/
                if (!(v&4) && (pccombo.dor&4))
                {
                        discrint=1000;
                        pccombo.fdcreset=1;
                        pccombo.status=0;
                }
                pccombo.dor=v;
                return;
                case 0x3010FD4: /*FDC data register*/
                if (!pccombo.incommand)
                {
                        pccombo.incommand=1;
                        pccombo.lastcommand=pccombo.command;
                        pccombo.command=v;
//                        sprintf(s,"FDC command %02X\n",v);
//                        fputs(s,olog);
                        switch (v)
                        {
                                case 3: /*Specify*/
                                pccombo.params=2;
                                pccombo.curparam=0;
                                pccombo.pos=0;
                                pccombo.status=0x90;
                                return;
                                case 8: /*Sense interrupt status*/
                                pccombo.pos=0;
                                pccombo.status=0x30;
                                discint=400;
                                return;
                                default:
                                sprintf(s,"Bad FDC command %02X\n",v);
                                MessageBox(NULL,s,"Arculator",MB_OK);
                                dumpregs();
                                exit(-1);
                        }
                }
                else
                {
                        pccombo.p[pccombo.curparam++]=v;
                        if (pccombo.curparam>=pccombo.params)
                        {
                                switch (pccombo.command)
                                {
                                        case 3: /*Specify*/
                                        pccombo.status=0x30;
                                        discint=400;
//                                        output=1;
//                                        timetolive=1000;
                                        return;
                                        default:
                                        sprintf(s,"Bad FDC params command %02X\n",pccombo.command);
                                        MessageBox(NULL,s,"Arculator",MB_OK);
                                        dumpregs();
                                        exit(-1);
                                }
                        }
                }
                return;
                case 0x3010FDC: /*FDC data rate*/
                return;
                case 0x3010FEC: /*Byte format*/
                pccombo.byteformat2=v;
                return;
                case 0x3010FE0: /*Serial divisor*/
                case 0x3010FE4: /*Serial divisor*/
                case 0x3010FE8: /*Serial interrupt register*/
                case 0x3010FF0: /*Modem control*/
                return;
                case 0x3010FFC: /*Serial scratch register*/
                pccombo.scratch2=v;
                return;
                default:
                sprintf(s,"Bad 82c711 write %07X %02X\n",a,v);
                MessageBox(NULL,s,"Arculator",MB_OK);
                dumpregs();
                exit(-1);
        }
}

void callbackr82c711()
{
        char s[256];
/*        sprintf(s,"Reset callback %i\n",pccombo.fdcreset);
        if (!olog) olog=fopen("olog.txt","wt");
        fputs(s,olog);*/
        if (pccombo.fdcreset)
        {
                ioc.irqb|=0x10;
                updateirqs();
                pccombo.status=0x80;
                pccombo.fdcreset++;
                pccombo.st0=0xC0;
                return;
        }
}

void callback82c711()
{
        char s[256];
/*        sprintf(s,"Callback %i %02X %i\n",pccombo.fdcreset,pccombo.command,pccombo.incommand);
        if (!olog) olog=fopen("olog.txt","wt");
        fputs(s,olog);*/
        switch (pccombo.command)
        {
                case 3: /*Specify*/
                ioc.irqb|=0x10;
                updateirqs();
                pccombo.status=0x80;
                pccombo.incommand=0;
                pccombo.st0=0;
                break;
                case 8: /*Sense interrupt status*/
//                ioc.irqb|=0x10;
//                updateirqs();
                pccombo.status=0xD0;
                break;
                
                default:
                sprintf(s,"Bad 82c711 callback %02X\n",pccombo.command);
                MessageBox(NULL,s,"Arculator",MB_OK);
                dumpregs();
                exit(-1);
        }
}

void callback82c711index()
{
        char s[256];
        ioc.irqa|=4;
        updateirqs();
/*        sprintf(s,"Index interrupt\n");
        if (!olog) olog=fopen("olog.txt","wt");
        fputs(s,olog);*/
        fdcindex=64;
}
