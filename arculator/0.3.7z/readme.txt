Arculator 0.3
~~~~~~~~~~~~~

Arculator emulates an old-style Archimedes (A3xx,A4xx,A3000,A540) with an ARM2 or
ARM3, 4, 8 or 16 megabytes of RAM, and a single floppy drive.


Changes since last release :

- Much improved sound (filter still a bit off though)
- Slight ARM optimisations - 10% speedup
- Bug fixes to VIDC and IOC - TCD Powerscroll and ARMageddon Megademo 3 now work
- Emulated prefetch - Elite now works (stupid protection)
- Fixed stupid video mode 0 bug
- Replaced mouse hack with mouse capture technique
- Reduced CPU usage on NT/2000/XP


Files
~~~~~

arculator.exe - The emulator itself.
alleg41.dll   - Required DLL file
changes.txt   - Changelog
cmos.bin      - CMOS RAM
readme.txt    - This file
src\*         - Source (needs Ming/W and Allegro to compile)


Usage
~~~~~

Just run Arculator.exe. You will need to supply the RiscOS 3 ROM images as
either a single file rom, or four files ic24.rom-ic27.rom. They can be 
dumped from a real machine with the following sequence of commands :

*SAVE ic24 3800000+80000
*SAVE ic25 3880000+80000
*SAVE ic26 3900000+80000
*SAVE ic27 3980000+80000

Alternatively you could use

*SAVE rom 3800000+200000

but you'd have fun transfering it to a PC.

A bug in the emulation means that the desktop will hang sometimes.
Enabling the OS hack will work around this for now.

For speed reasons, it is best to have your desktop in 16-bit colour when running
Arculator.


Mouse
~~~~~

The mouse hack has been removed for this release. Instead, clicking on the display
will 'capture' the mouse, and pressing CTRL-END or switching to another application
will release it. With this mode, all the old problems with mouse control are gone.


Menus
~~~~~

File - Reset - soft-resets the Archimedes
       Exit  - exits back to Windows
Disc - Change disc - Loads a new disc into drives 0-3
       Remove disc - Unloads any disc that might be loaded from drives 0-3
Machine - CPU Type - Select between ARM2 and ARM3. ARM3 is quite slow on my machine (AMD
                     2400XP), though part of that is due to the video speed.
          RAM Size - Select between 4, 8 and 16 megs of RAM.
Options - Sound enable - Enables/disables sound
	  Limit speed - Limit speed to what should be about 8mhz. Sound has to be disabled
                        as well as this for any speedup to happen (and your video card has
                        to be fast enough to catch up).
          OS hack - Enables/disables OS hack - try this if RiscOS appears to
                    hang
Video - Full screen - Goes to a full screen. Use CTRL+END to return to windowed mode.
        Full borders - Toggles expansion of borders - useful for programs that overscan.


Compatibility
~~~~~~~~~~~~~

RiscOS 3 - Boots. Supervisor useable. BASIC usable, with some bugs. Desktop
           usable, with some bugs.
RiscOS 2 - Doesn't boot correctly - unusable.
Arthur   - Supervisor and BASIC usable. Hangs when trying to enter desktop,
           refuses to read most discs.


Games :

Bug Hunter 2 - Playable
Cannon Fodder - Playable
Cataclysm     - Playable
Chuck Rock    - Playable
Cycloids      - Playable
Magic Pockets (demo) - Playable
Zool (demo) - Playable
Gods - Playable
Gyrinus 2 - Playable, no sound
James Pond - Playable
Lemmings 2 - Playable, no sound ingame
Lemmings 2 (demo) - Playable
Lemmings - Playable
Lemings - Playable
Mad Professor Mariarti - Playable
Moondash - Playable
Last Ninja (demo) - Playable
Pacmania - Playable
Paradroid 2000 - Playable
Repton 3 - Playable
Speedball 2 - Playable
Spheres of Chaos (demo) - Playable
Terramex - Playable
Twinworld - Playable
Warlocks (demo) - Playable, not sure about position of borders
Zelanites (demo) - Playable, not sure about position of borders

Elite - Needs OS hack
Flashback (demo) - Needs OS hack
Starfighter 3000 - Needs OS hack

Bug Hunter - Out of data error
EGO : Repton 4 - Hangs
Nebulus - Data abort

Apps :
!65Host - Works
Logotron Pen Down 1.72 - Works
Notate - Works
Impression Jr - Works. Seems to crash after saving sometimes (but files get saved
correctly).
Coconizer - Hangs


Todo list :
~~~~~~~~~~~

Fix the bug relating to running programs via the desktop. (this appears to be
related to the RiscOS FIQ handling - the 1772 handler doesn't seem to be releasing
FIQs always)

Optimize. There are a few areas in the ARM emulation that I know of that can be
optimized, and probably the video emulation as well. 

Change video emulation to use hardware bitmaps + blitting.

Add hard drive emulation. Either via hardfiles (need docs on ST506 or SCSI 
controllers) or a fileswitch module.


Tom Walker
b-em@bbcmicro.com