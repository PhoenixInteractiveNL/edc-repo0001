pSX readme
-=-=-=-=-=

Introduction
============

pSX emulates the Sony Playstation 1, pretty much everything is emulated
(to my knowledge) and most games run perfectly.

One thing that should be noted is that pSX DOES NOT use plugins.
The emulator is completely self contained.

The emulator has been designed to be as easy and unobtrusive to use
as possible - in most cases you will not need to configure anything
to use it (except maybe the controls).

Installation
============

Extract all files from the .rar including folders.

The emulator requires a PS1 BIOS file which should be placed in the
bios directory.  By default the emulator will look for scph1001.bin
- this version is highly recommend because it is the only well tested 
one although other bioses should work.

Once the emulator is running you can change the BIOS from the 
configuration menu.  In the event that you only have a different bios
file you can edit psx.ini to get the emulator running (run psx.exe
once, you will get an error message, now look for psx.ini).

Running games
=============

The emulator supports .cue/.bin CD images, the easiest way to run a
game is to run the exe then select "Insert CD image" from the File
menu.  It is also possible to start a game from the command line:

	psx.exe c:\psxgames\mygame.bin

Note that you will get best performance running in full-screen mode.
Press ALT+ENTER to switch between full-screen and windowed.

cdz images
==========

pSX supports compressed CD images - these can be created from .cue/.bin
files using the cdztool.exe util which is provided.  To create a .cdz
file :

	utils\cdztool.exe c:\psxgames\mygame.bin c:\psxgames\mygame.cdz

You can also convert a cdz back to .cue/.bin by reversing the order of
the parameters, eg:

	utils\cdztool.exe c:\psxgames\mygame.cdz c:\psxgames\mygame.bin

Configuration
=============

The configuration menu is fairly self explanatory.  This is a quick
run through of the various options.

Paths
-----

This tab allows you to set the default paths for state saves, memory 
cards and cd images.

BIOS
----

This tab allows you to set the BIOS image used by the emulator.

Memory cards
------------

This tab configures the memory cards inserted into the Playstations
slots.  To create a memory card click ..., navigate to where you want
the file to be saved, and enter a filename (eg. "mycard").

Graphics
--------

Frame skipping - enables/disables frame skipping

Sleep when idle in windowed mode - when running in windowed mode this
option causes the emulator to use less CPU time but can result in
choppier performance.

Pause when not focused - when enabled the emulator will pause when its
main window does not have focus (note: sound is always disabled when
not focused).

Status icons - displays status icons (CD/XA/etc..) at the bottom left

Controllers
-----------

This tab allows you to configure joystick and keyboard mappings for
the Playstations controllers.

Note that you MUST configure the gamepad controls if you want to use
a joystick or gamepad (by default only keys are set up).  Also note
that you must configure the analog axes if you want to use an analog
controller (eg. dualshock).

Default controls (for port1) :

  Up        Cursor up
  Left      Cursor left
  Down      Cursor down
  Right     Cursor right
  Triangle  A
  Square    X
  Cross     Z
  Circle    S
  Start     Return
  Select    Space
  L1        Left shift
  L2        Left ctrl
  R1        Right shift
  R2        Right ctrl

Sound
-----

From this tab you can configure sound settings.

Device: set the device used for sound output, in most cases this should
be set to "Primary Sound Driver"

Frequency: normally you should leave "Same as emulated machine" checked
which will cause the emulator to use the same frequency as the PS1.  To
change the output frequency untick the option and select from the combo
box.

Latency: This option controls how much delay there is in the sound output
in most cases the default setting will be fine, but if you experience 
dropouts or choppy sound you can try increasing this.

XA latency: Controls how much delay there is in XA sound output.

Reverb: Enables/disables reverb emulation.

Sync sound: When enabled the emulator will try to keep the sound in sync
with the graphics (this should normally be enabled).

Interpolate: Enables/disables linear interpolation of sound output -
takes slightly more CPU power (not much) but reduces aliasing significantly.

Misc
----

Allows redefinition of various miscellaneous keyboard controls.


CDROM
-----

Allows selection of CDROM driver (Auto detect, IoControl or ASPI) - normally
Auto detect should be used.

ASPI Drive letter mapping under Win98/ME
========================================

Under Windows98/ME there is no way to correctly map drive letters to ASPI
drives.  Because of this the emulator makes a guess (it guesses that the drives
are in order of scsi adapter/target) - if you have multiple drives it may
guess wrong.  For this reason it is possible to override the mapping.

To see what pSX thinks the mappings are run the emulator with the -x option:

psxfin -x

This will show a list of drives with the corresponding drive letter on the left.
If this is incorrect you can add entries to the [CDROM] section in the .ini file 
to override it, for example :

[CDROM]
Driver=-1
SCSI4:1=x:

This tells the emulator that SCSI target 4:1 is drive x:

Crash dumps
===========

If the emulator crashes it will ask if you want to save a crash dump.
There are two types of crash dump, mini dump and full dump - a dialog
box will ask you if you want to save a full dump.  In most cases you
will want to say no to this because full dumps can be very large - a
mini dump is usually enough to debug problems.

Dump files can be included in a bug report (see email address below).

NOTE: crash dump saving is only supported if you have dgbhelp.dll installed

History
=======

v1.0 Initial release

v1.1 ALT+F4 now exits the emulatoer
     Pressing F1/Shift+F1 switches back to windowed mode for file dialog
     *.mcr files are shown in memory card dialog
     Option to disable status icons (CD/XA/MR, etc..) - disabled by default
     dbghelp.dll is now optional (required for saving crash dumps though)
     CD drives (IoControl and ASPI) should now work
     pSX now works under Win98/ME (hopefully ;)
     Fixed save state loading bug
     Fixed crash when entering non existant save state filename

Contact
=======

Questions or bug reports should be directed to: psxemulator@googlemail.com
