#ifndef __FILTER_EPX_UNSAFE_H
#define __FILTER_EPX_UNSAFE_H

void EPX_16_unsafe (uint8 *, uint32, uint8 *, uint32, int, int);
void EPX_16_smooth_unsafe (uint8 *, uint32, uint8 *, uint32, int, int);

#endif /* __FILTER_EPX_UNSAFE_H */
