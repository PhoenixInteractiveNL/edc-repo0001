Snapshot Release 0.4.4 13th June 2001

Changes in this version (didn't realise it was so long!)

RISC OS 4 works (at last). RISC OS 3.7 shouldn't have worked...
Some sound crackle is fixed. Some games and RiscPC will
still suffer from bad crackle or just noise.
Sound timing is handled in a different way which may improve
matters on Win2k but it may also have other unwanted effects
RiscPC memory/vram size is configurable.
HostFS configuration is less broken ;-)
Status bar indicators for floppy/ide work again
Very slow response on fast machines (>700mhz) is fixed. This
may rear its head again on > 1400Mhz machines.

Don't use 'Free' on large HostFS shares, it'll lock up the
desktop.

Snapshot release 0.4.3 12th May 2001

Changes in this version

New Arm710 models with Vram support and quadrature mouse
Changes to mouse button mappings are applied immediately
Menu key setting is more useful
PS/2 (Arm7500) mouse buttons dont cause odd  mouse movement
Better reset handling
Better/Different Vidc timings on RiscPC
Fixed windows pointer corruption (and Win2k crashes)
Sound buffer is zero'd to avoid noise at startup
Fixed !Alarm month and year settings

Snapshot release 0.4.2 28th April 2001

Changes in this version

Model selection panel, choose between RiscPC and Archimedes emulation
Experimental, read only, real floppy access under win98
Better clocking code
8-10% faster

Snapshot release 0.4.1 14th April 2001

Changes in this version

Fixed 16bit display modes
Hostfs works (now as a podule)
Hostfs is bootable, either via 'opt 4,2' or via the mounts config
Hostfs mounts stored in plugins/hostfs
Finds some of its config via executable path, some still via registry

Snapshot release 0.4.0 1st April 2001

First 'public' release
Desktop boots correctly
Display mode set correctly

Installation

You need to have RedSquirrel 0.3 installed as this version needs some of
the registry settings that 0.3 adds.

DO NOT overwrite your RedSquirrel 0.3 installation with anything here. 
This version should run from wherever you unpack it.

For RiscPC emulation you will need copies of the RISC OS 3.7 roms and,
to do anything useful, a copy of the RISC OS 3.7/4.0 !boot files.

For Archimedes emulation you will need copies of the RISC OS 3.11 roms.

Copy the roms into the Romsets/RiscosX_XX folder and RedSquirrel should
run. Please don't put anything else in these folders, RedSquirrel will
happily try to execute zip files but wont make much sense of them.

If you can't work out how to configure this version of RedSquirrel, it's
not for you.

Info

All versions of RedSquirrel 0.4.x will be snapshot releases; these are 
released as I feel like it, when interesting features have been added or
odd fixes made. Hopefully this will be on a regular basis (once a week
or so) so everone can see where it's going. There is no guarantee that
RS will run or not crash your PC or corrupt any config. Anything can and
will change from release to release.

The current snapshot version emulates:

A RiscPC with an Arm7500 processor running at about 5Mips (on my PIII 500Mhz).
The Arm7500 doesn't support VRAM so RISC OS limits display memory to 1Mb
and also the video bandwidth.
RAM is temporarily fixed at 16Mb.
Floppy/IDE doesn't work.
Large size/resolution modes severly affect performance.

An Archimedes type machine with an Arm3 processor running at about 5mips.

There is a 'console' which I use for debugging. Currently it's showing
unused IO addresses to which RISCOS is writing. Some of these are
empty podule slots the others are to devices that I don't know about.
If you know what these are I'd be interested to know.

Please dont ask for help on installing the snapshot versions of RedSquirrel.

Have fun
Graeme
