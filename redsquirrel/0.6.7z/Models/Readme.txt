In an ideal world, users shouldn't have to touch model files and everything would be done via a nice GUI. One day this will be so.

For now, certain things have to be edited by hand so this is a brief description of the model file format.

RedSquirrel expects to find a folder called Models in the same folder as RedSquirrel.exe. In this folder there should be a number of folders whose names will appear in the 'Select Model' panel at startup. Each of these folders must contain a model.cfg file describing the components that form the model.

The model.cfg file is in the same format as RedSquirrel.cfg, with a section for each component. The section header identifies a component to be added e.g. [Ram] and can be followed by a number of component parameters to be set e.g. 'base=0x2000000'.

At some point in the future there will be a way to enumerate all available components and all available options.

There are currently two types of parameters. String parameters are  of the form param = "Name" and are typically used for filenames. Integer parameters are of the form param = 10 and. The value can be in hex (0x1234), decimal (1234) and be postfixed by a scaling factor (K/k for kilobytes), (M/m for megabytes), (G/g for gigabytes).

Filenames can be fully qualified (C:\dir\) or unqualified (dir\file). Unqualified files will be searched for in the model directory, then the app directory, then the current directory (which is typically the app directory)

[Ram]
base = 0x2000000
size = 16m

will add some ram at 32Mb of size 16Mb.

Specific devices:

[PhysicalBus]

All machines need a PhysicalBus as all memory mapped devices are connected to it. 

width: specifies the width in bits of the bus.

[Arm2/Arm3/Arm7/JITArm2/JITArm3/JITArm7]

A particular processor. There must be only one at present. Different versions of the app support differing sets of processors.

[Memc1a]

Only needed in Arm2/Arm3 machines, the MMU is built into the Arm7

[Vidc1a/Vidc20]

Useful if you want some visual feedback

[Ioc1/Iomd/Iomd7500]

Ioc1 is the IO controller in Arm2/Arm3 machines
Iomd/Iomd7500 is the IO controller in Arm7 machines

vram: (Iomd only). Size of vram - should be 0, 1m or 2m

[Ioeb]

Halfhearted Ioc extensions used in A5000/Portable machines to control video/clock settings

[Rom]

Specifies a rom file/directory which contains an OS

filename: path to file/directory containing roms
base: base address in physical space to load the rom
size: area of physical space convered by the rom. This is generally larger than the rom and the rom repeats over all this space

[Ram]

Most OS's need some ram. Arm7 machines have up to four banks of ram at 0x10000000, 0x14000000. 0x18000000, 0x1c000000 each up to 64Mb in size. Arm2/3 machines have up to 16Mb of ram at 0x2000000

base: base address in physical memory
size: area covered by ram (doesn't repeat at present)

[CmosRam]

A file where cmos ram settings are stored

filename: file where cmos is kept. Typically this should be in the model folder

[82c711/37c665]

This is the 'Super IO' chip used in many Acorn machines to control the floppy drive, ide bus, parallel and serial ports. 82c711 chips were used in Arm2/3 machines, and the 37c665 in Arm7 machines

[ClockChip]

The clockchip sits on the I2C bus and provides a realtime clock. It is the same on all machines

[IocI2CBus]

Provices an I2CBus for I2C devices so they can connect to an Ioc chip

[HostFS]

The HostFS podule for accessing the host filing system

podule: the podule number/slot to which to connect HostFS
mount0, mount1 etc. Mount points for hostfs. The value is a string of the format "name 'windows path' options". Best to use the GUI to set this one.


[ImageFloppyDrive]

A floppy drive that provices a 'virtual' floppy drive reading the floppy from a 800/1600k file


[RealFloppyDrive]

A floppy drive providing access to the real PC floppy drive. This DOESN'T WORK YET

[IdeDisc]

Provides an ide disk image. There can be up to two of these.

filename: The file containing the disk image.


