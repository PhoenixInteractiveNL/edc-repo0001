This file is in RedSquirrel\Hostfs\Disk310

You can place other files in here and see them from
both Windows and RISC OS 3.1

