//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Win32.rc
//
#define IDR_LICENSE                     104
#define IDR_IMAGEDATABASE               105
#define IDB_LAUNCHERTREE_CLOSED         130
#define IDB_LAUNCHERTREE_OPEN           131
#define IDI_APP                         141
#define IDI_APP_J                       142
#define IDI_NES                         143
#define IDI_NES_J                       144
#define IDI_UNF                         145
#define IDI_UNF_J                       146
#define IDI_FDS                         147
#define IDI_NSF                         148
#define IDI_NSF_J                       149
#define IDI_NSP                         150
#define IDI_NSP_J                       151
#define IDI_PAD                         152
#define IDI_PAD_J                       153
#define IDC_CURSOR_GUN                  161

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        3060
#define _APS_NEXT_COMMAND_VALUE         4106
#define _APS_NEXT_CONTROL_VALUE         5163
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
