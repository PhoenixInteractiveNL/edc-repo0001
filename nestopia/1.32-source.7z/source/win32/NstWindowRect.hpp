////////////////////////////////////////////////////////////////////////////////////////
//
// Nestopia - NES/Famicom emulator written in C++
//
// Copyright (C) 2003-2006 Martin Freij
//
// This file is part of Nestopia.
//
// Nestopia is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Nestopia is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Nestopia; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
////////////////////////////////////////////////////////////////////////////////////////

#ifndef NST_WINDOW_RECT_H
#define NST_WINDOW_RECT_H

#pragma once

#include "NstWindowPoint.hpp"

namespace Nestopia
{
	namespace Window
	{
		struct Rect : RECT
		{
			Rect(int v=0)
			{
				left = v;
				top = v;
				right = v;
				bottom = v;
			}

			Rect(const POINT& p)
			{
				left = 0;
				top = 0;
				right = p.x;
				bottom = p.y;
			}

			Rect(int l,int t,int r,int b)
			{
				left = l;
				top = t;
				right = r;
				bottom = b;
			}

			Rect(const RECT& r)
			{
				left = r.left;
				top = r.top;
				right = r.right;
				bottom = r.bottom;
			}

			Rect& Set(int l,int t,int r,int b)
			{
				left = l;
				top = t;
				right = r;
				bottom = b;
				return *this;
			}

			Rect& operator = (int v)
			{
				left = v;
				top = v;
				right = v;
				bottom = v;
				return *this;
			}

			Rect& operator = (const POINT& p)
			{
				left = 0;
				top = 0;
				right = p.x;
				bottom = p.y;
				return *this;
			}

			Rect& operator = (const RECT& r)
			{
				left = r.left;
				top = r.top;
				right = r.right;
				bottom = r.bottom;
				return *this;
			}

			ibool operator == (const Rect& r) const
			{
				return
				(
					right == r.right &&
					bottom == r.bottom &&
					left == r.left &&
					top == r.top
				);
			}

			ibool operator != (const Rect& r) const
			{
				return
				(
					right != r.right ||
					bottom != r.bottom ||
					left != r.left ||
					top != r.top
				);
			}

			ibool operator ! () const
			{
				return (right | bottom | left | top) == 0;
			}

			long& operator [] (uint i)
			{
				return (&left)[i];
			}

			const long& operator [] (uint i) const
			{
				return (&left)[i];
			}

			ibool IsInside(const Point& p) const
			{
				return p.x >= left && p.x < right && p.y >= top && p.y < bottom;
			}

			ibool Valid() const
			{
				return left <= right && top <= bottom;
			}

			ibool IsVisible() const
			{
				return right - left > 0 && bottom - top > 0;
			}

		private:

			class PosProxy
			{
				friend struct Rect;

				Rect& r;

				PosProxy(Rect& rect)
				: r(rect) {}

			public:

				PosProxy& operator = (const Point& p)
				{
					r.right = p.x + (r.right - r.left);
					r.bottom = p.y + (r.bottom - r.top);
					r.left = p.x;
					r.top = p.y;
					return *this;
				}

				PosProxy& operator += (const Point& p)
				{
					r.left += p.x;
					r.top += p.y;
					r.right += p.x;
					r.bottom += p.y;
					return *this;
				}

				Rect operator + (const Point& p) const
				{
					return Rect
					(
						r.left + p.x,
						r.top + p.y,
						r.right + p.x,
						r.bottom + p.y
					);
				}

				PosProxy& operator -= (const Point& p)
				{
					r.left -= p.x;
					r.top -= p.y;
					r.right -= p.x;
					r.bottom -= p.y;
					return *this;
				}

				Rect operator - (const Point& p) const
				{
					return Rect
					(
						r.left - p.x,
						r.top - p.y,
						r.right - p.x,
						r.bottom - p.y
					);
				}

				operator Point () const
				{
					return Point(r.left,r.top);
				}
			};

			class WidthHeightProxy
			{
				friend struct Rect;

				long* p;

				WidthHeightProxy(long* point)
				: p(point) {}

			public:

				WidthHeightProxy& operator = (int xy)
				{
					p[2] = p[0] + xy;
					return *this;
				}

				WidthHeightProxy& operator += (int xy)
				{
					p[2] += xy;
					return *this;
				}

				int operator + (int xy) const
				{
					return p[2] + xy;
				}

				WidthHeightProxy& operator -= (int xy)
				{
					p[2] -= xy;
					return *this;
				}

				int operator - (int xy) const
				{
					return p[2] - xy;
				}

				operator int () const
				{
					return p[2] - p[0];
				}
			};

			class SizeProxy
			{
				friend struct Rect;

				Rect& r;

				SizeProxy(Rect& rect)
				: r(rect) {}

			public:

				SizeProxy operator = (const Point& p)
				{
					r.right = r.left + p.x;
					r.bottom = r.top + p.y;
					return *this;
				}

				SizeProxy operator += (const Point& p)
				{
					r.right += p.x;
					r.bottom += p.y;
					return *this;
				}

				Point operator + (const Point& p) const
				{
					return Point
					(
						(r.right - r.left) + p.x,
						(r.bottom - r.top) + p.y
					);
				}

				SizeProxy operator -= (const Point& p)
				{
					r.right -= p.x;
					r.bottom -= p.y;
					return *this;
				}

				Point operator - (const Point& p) const
				{
					return Point
					(
						(r.right - r.left) - p.x,
						(r.bottom - r.top) - p.y
					);
				}

				operator Point () const
				{
					return Point
					(
						r.right - r.left,
						r.bottom - r.top
					);
				}
			};

			class CenterProxy
			{
				friend struct Rect;

				Rect& r;

				CenterProxy(Rect& rect)
				: r(rect) {}

			public:

				CenterProxy operator = (const Point& p)
				{
					const Point size
					(
						r.right - r.left,
						r.bottom - r.top
					);

					r.left = p.x - (size.x / 2);
					r.right = p.x + (size.x / 2) + (size.x % 2);
					r.top = p.y - (size.y / 2);
					r.bottom = p.y + (size.y / 2) + (size.y % 2);

					return *this;
				}

				operator Point () const
				{
					return Point
					(
						r.left + ((r.right - r.left) / 2),
						r.top  + ((r.bottom - r.top) / 2)
					);
				}
			};

		public:

			PosProxy Position()
			{
				return PosProxy(*this);
			}

			Point Position() const
			{
				return Point( left, top );
			}

			SizeProxy Size()
			{
				return SizeProxy(*this);
			}

			Point Size() const
			{
				return Point( right - left, bottom - top );
			}

			CenterProxy Center()
			{
				return CenterProxy(*this);
			}

			Point Center() const
			{
				return Point
				(
					left + ((right - left) / 2),
					top  + ((bottom - top) / 2)
				);
			}

			Point& Corner()
			{
				return reinterpret_cast<Point&>(right);
			}

			const Point& Corner() const
			{
				return reinterpret_cast<const Point&>(right);
			}

			WidthHeightProxy Width()
			{
				return WidthHeightProxy(&left);
			}

			int Width() const
			{
				return right - left;
			}

			WidthHeightProxy Height()
			{
				return WidthHeightProxy(&top);
			}

			int Height() const
			{
				return bottom - top;
			}

			ibool operator <  (const Rect& r) const { return Width() * Height() <  r.Width() * r.Height(); }
			ibool operator >  (const Rect& r) const { return Width() * Height() >  r.Width() * r.Height(); }
			ibool operator <= (const Rect& r) const { return Width() * Height() <= r.Width() * r.Height(); }
			ibool operator >= (const Rect& r) const { return Width() * Height() >= r.Width() * r.Height(); }

			Rect operator * (const Rect& r) const
			{
				return Rect
				(
					left * r.left,
					top * r.top,
					right * r.right,
					bottom * r.bottom
				);
			}

			Rect operator * (const long v) const
			{
				return Rect
				(
					left * v,
					top * v,
					right * v,
					bottom * v
				);
			}

			Rect operator * (const Point& p) const
			{
				return Rect
				(
					left * p.x,
					top * p.y,
					right * p.x,
					bottom * p.y
				);
			}

			Rect operator / (const long v) const
			{
				return Rect
				(
					left / v,
					top / v,
					right / v,
					bottom / v
				);
			}

			Rect operator / (const Point& p) const
			{
				return Rect
				(
					left / p.x,
					top / p.y,
					right / p.x,
					bottom / p.y
				);
			}

			struct Screen;
			struct Window;
			struct Client;
			struct Picture;
		};

		struct Rect::Screen : Rect
		{
			Screen(HWND);
		};

		struct Rect::Window : Rect
		{
			Window(HWND);
		};

		struct Rect::Client : Rect
		{
			Client(HWND);
		};

		struct Rect::Picture : Rect
		{
			enum Space
			{
				CLIENT,
				SCREEN
			};

			Picture(HWND,Space=CLIENT);
		};
	}
}

#endif
