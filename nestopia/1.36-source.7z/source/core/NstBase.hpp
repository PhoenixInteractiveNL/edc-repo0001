////////////////////////////////////////////////////////////////////////////////////////
//
// Nestopia - NES/Famicom emulator written in C++
//
// Copyright (C) 2003-2007 Martin Freij
//
// This file is part of Nestopia.
//
// Nestopia is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Nestopia is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Nestopia; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
////////////////////////////////////////////////////////////////////////////////////////

#ifndef NST_BASE_H
#define NST_BASE_H

#include "api/NstApiConfig.hpp"

//--------------------------------------------------------------------------------------
// Microsoft Visual C++
//--------------------------------------------------------------------------------------

#ifdef _MSC_VER
#define NST_MSVC _MSC_VER
#else
#define NST_MSVC 0
#endif

//--------------------------------------------------------------------------------------
// Intel C/C++ Compiler
//--------------------------------------------------------------------------------------

#ifdef __INTEL_COMPILER
#define NST_ICC __INTEL_COMPILER
#else
#define NST_ICC 0
#endif

//--------------------------------------------------------------------------------------
// GNU Compiler Collection
//--------------------------------------------------------------------------------------

#ifdef __GNUC__
#define NST_GCC (__GNUC__ * 100 + __GNUC_MINOR__)
#else
#define NST_GCC 0
#endif

//--------------------------------------------------------------------------------------
// Borland C++
//--------------------------------------------------------------------------------------

#ifdef __BORLANDC__
#define NST_BCB __BORLANDC__
#else
#define NST_BCB 0
#endif

//--------------------------------------------------------------------------------------
// Metrowerks CodeWarrior
//--------------------------------------------------------------------------------------

#ifdef __MWERKS__
#define NST_MWERKS __MWERKS__
#else
#define NST_MWERKS 0
#endif

//--------------------------------------------------------------------------------------

#ifdef NST_PRAGMA_ONCE
#pragma once
#elif NST_MSVC >= 1020 || NST_MWERKS >= 0x3000
#pragma once
#define NST_PRAGMA_ONCE
#endif

//--------------------------------------------------------------------------------------

#ifndef NST_CALL
#define NST_CALL
#endif

namespace Nes
{
	typedef signed char schar;
	typedef unsigned char uchar;
	typedef unsigned short ushort;
	typedef unsigned int uint;
	typedef unsigned long ulong;

	enum
	{
		b00000000, b00000001, b00000010, b00000011, b00000100, b00000101, b00000110, b00000111,
		b00001000, b00001001, b00001010, b00001011, b00001100, b00001101, b00001110, b00001111,
		b00010000, b00010001, b00010010, b00010011, b00010100, b00010101, b00010110, b00010111,
		b00011000, b00011001, b00011010, b00011011, b00011100, b00011101, b00011110, b00011111,
		b00100000, b00100001, b00100010, b00100011, b00100100, b00100101, b00100110, b00100111,
		b00101000, b00101001, b00101010, b00101011, b00101100, b00101101, b00101110, b00101111,
		b00110000, b00110001, b00110010, b00110011, b00110100, b00110101, b00110110, b00110111,
		b00111000, b00111001, b00111010, b00111011, b00111100, b00111101, b00111110, b00111111,
		b01000000, b01000001, b01000010, b01000011, b01000100, b01000101, b01000110, b01000111,
		b01001000, b01001001, b01001010, b01001011, b01001100, b01001101, b01001110, b01001111,
		b01010000, b01010001, b01010010, b01010011, b01010100, b01010101, b01010110, b01010111,
		b01011000, b01011001, b01011010, b01011011, b01011100, b01011101, b01011110, b01011111,
		b01100000, b01100001, b01100010, b01100011, b01100100, b01100101, b01100110, b01100111,
		b01101000, b01101001, b01101010, b01101011, b01101100, b01101101, b01101110, b01101111,
		b01110000, b01110001, b01110010, b01110011, b01110100, b01110101, b01110110, b01110111,
		b01111000, b01111001, b01111010, b01111011, b01111100, b01111101, b01111110, b01111111,
		b10000000, b10000001, b10000010, b10000011, b10000100, b10000101, b10000110, b10000111,
		b10001000, b10001001, b10001010, b10001011, b10001100, b10001101, b10001110, b10001111,
		b10010000, b10010001, b10010010, b10010011, b10010100, b10010101, b10010110, b10010111,
		b10011000, b10011001, b10011010, b10011011, b10011100, b10011101, b10011110, b10011111,
		b10100000, b10100001, b10100010, b10100011, b10100100, b10100101, b10100110, b10100111,
		b10101000, b10101001, b10101010, b10101011, b10101100, b10101101, b10101110, b10101111,
		b10110000, b10110001, b10110010, b10110011, b10110100, b10110101, b10110110, b10110111,
		b10111000, b10111001, b10111010, b10111011, b10111100, b10111101, b10111110, b10111111,
		b11000000, b11000001, b11000010, b11000011, b11000100, b11000101, b11000110, b11000111,
		b11001000, b11001001, b11001010, b11001011, b11001100, b11001101, b11001110, b11001111,
		b11010000, b11010001, b11010010, b11010011, b11010100, b11010101, b11010110, b11010111,
		b11011000, b11011001, b11011010, b11011011, b11011100, b11011101, b11011110, b11011111,
		b11100000, b11100001, b11100010, b11100011, b11100100, b11100101, b11100110, b11100111,
		b11101000, b11101001, b11101010, b11101011, b11101100, b11101101, b11101110, b11101111,
		b11110000, b11110001, b11110010, b11110011, b11110100, b11110101, b11110110, b11110111,
		b11111000, b11111001, b11111010, b11111011, b11111100, b11111101, b11111110, b11111111
	};

	enum System
	{
		SYSTEM_HOME,
		SYSTEM_VS,
		SYSTEM_PC10
	};

	enum Region
	{
		REGION_NTSC = 1,
		REGION_PAL,
		REGION_BOTH
	};

	enum CpuType
	{
		CPU_2A03
	};

	enum PpuType
	{
		PPU_RP2C02,
		PPU_RP2C03B,
		PPU_RP2C03G,
		PPU_RP2C04_0001,
		PPU_RP2C04_0002,
		PPU_RP2C04_0003,
		PPU_RP2C04_0004,
		PPU_RC2C03B,
		PPU_RC2C03C,
		PPU_RC2C05_01,
		PPU_RC2C05_02,
		PPU_RC2C05_03,
		PPU_RC2C05_04,
		PPU_RC2C05_05
	};

	enum
	{
		FPS_NTSC = 60,
		FPS_PAL  = 50
	};

	enum Result
	{
		RESULT_ERR_INVALID_MAPPER           = -15,
		RESULT_ERR_MISSING_BIOS             = -14,
		RESULT_ERR_UNSUPPORTED_SOUND_CHIP   = -13,
		RESULT_ERR_UNSUPPORTED_GAME         = -12,
		RESULT_ERR_UNSUPPORTED_MAPPER       = -11,
		RESULT_ERR_UNSUPPORTED_VSSYSTEM     = -10,
		RESULT_ERR_UNSUPPORTED_FILE_VERSION =  -9,
		RESULT_ERR_UNSUPPORTED              =  -8,
		RESULT_ERR_INVALID_CRC              =  -7,
		RESULT_ERR_CORRUPT_FILE             =  -6,
		RESULT_ERR_INVALID_FILE             =  -5,
		RESULT_ERR_INVALID_PARAM            =  -4,
		RESULT_ERR_NOT_READY                =  -3,
		RESULT_ERR_OUT_OF_MEMORY            =  -2,
		RESULT_ERR_GENERIC                  =  -1,
		RESULT_OK                           =   0,
		RESULT_NOP                          =  +1,
		RESULT_WARN_UNSUPPORTED             =  +2,
		RESULT_WARN_BAD_DUMP                =  +3,
		RESULT_WARN_BAD_PROM                =  +4,
		RESULT_WARN_BAD_CROM                =  +5,
		RESULT_WARN_BAD_FILE_HEADER         =  +6,
		RESULT_WARN_SAVEDATA_LOST           =  +7,
		RESULT_WARN_ENCRYPTED_ROM           =  +8,
		RESULT_WARN_INCORRECT_FILE_HEADER   =  +9,
		RESULT_WARN_DATA_REPLACED           = +10
	};
}

#define NES_FAILED(x_) ((x_) < Nes::RESULT_OK)
#define NES_SUCCEEDED(x_) ((x_) >= Nes::RESULT_OK)

#endif
