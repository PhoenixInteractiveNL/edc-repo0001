////////////////////////////////////////////////////////////////////////////////////////
//
// Nestopia - NES/Famicom emulator written in C++
//
// Copyright (C) 2003-2007 Martin Freij
//
// This file is part of Nestopia.
//
// Nestopia is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Nestopia is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Nestopia; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
////////////////////////////////////////////////////////////////////////////////////////

#ifndef NST_MANAGER_EMULATOR_H
#define NST_MANAGER_EMULATOR_H

#pragma once

#include "NstCollectionVector.hpp"
#include "NstObjectDelegate.hpp"
#include "NstString.hpp"
#include "../core/api/NstApiEmulator.hpp"
#include "../core/api/NstApiMachine.hpp"
#include "../core/api/NstApiVideo.hpp"
#include "../core/api/NstApiSound.hpp"
#include "../core/api/NstApiInput.hpp"

namespace Nes
{
	using namespace Api;
}

namespace Nestopia
{
	namespace Io
	{
		namespace Nsp
		{
			struct Context;
		}

		namespace Stream
		{
			class Input;
			class Output;
		}
	}

	namespace Managers
	{
		class Emulator : public Nes::Emulator
		{
		public:

			Emulator();
			~Emulator();

		private:

			struct Netplay
			{
				Netplay();

				typedef Object::Delegate<void,Nes::Input::Controllers*> Callback;

				Callback callback;
				uint player, players;

				operator bool () const
				{
					return callback;
				}
			};

		public:

			enum
			{
				DEFAULT_SPEED = 0
			};

			enum Alert
			{
				NOISY,
				QUIETLY,
				STICKY
			};

			enum DiskImageSaveMethod
			{
				DISKIMAGE_SAVE_DISABLED,
				DISKIMAGE_SAVE_TO_IMAGE,
				DISKIMAGE_SAVE_TO_IPS
			};

			enum Event
			{
				EVENT_INIT = 1,
				EVENT_LOAD,
				EVENT_UNLOAD,
				EVENT_POWER_ON,
				EVENT_POWER_OFF,
				EVENT_RESET_SOFT,
				EVENT_RESET_HARD,
				EVENT_MODE_NTSC,
				EVENT_MODE_PAL,
				EVENT_PAUSE,
				EVENT_RESUME,
				EVENT_NETPLAY_MODE_ON,
				EVENT_NETPLAY_MODE_OFF,
				EVENT_NETPLAY_LOAD,
				EVENT_NETPLAY_UNLOAD,
				EVENT_NETPLAY_POWER_ON,
				EVENT_NETPLAY_POWER_OFF,
				EVENT_SPEED,
				EVENT_BASE_SPEED,
				EVENT_SPEEDING_ON,
				EVENT_SPEEDING_OFF,
				EVENT_REWINDING_ON,
				EVENT_REWINDING_OFF,
				EVENT_REWINDING_PREPARE,
				EVENT_REWINDING_START,
				EVENT_REWINDING_STOP,
				EVENT_NSF_PLAY,
				EVENT_NSF_STOP,
				EVENT_NSF_NEXT,
				EVENT_NSF_PREV,
				EVENT_PORT1_CONTROLLER,
				EVENT_PORT2_CONTROLLER,
				EVENT_PORT3_CONTROLLER,
				EVENT_PORT4_CONTROLLER,
				EVENT_PORT5_CONTROLLER,
				EVENT_QUERY_FDS_BIOS
			};

			void Initialize() const;
			void Stop();
			void Resume();
			void Wait();
			bool Pause(bool);
			void ResetSpeed(uint,bool,bool);
			void SetSpeed(uint);
			uint GetBaseSpeed();
			uint GetSpeed();
			bool SetMode(Nes::Machine::Mode);
			void ToggleSpeed(bool);
			void ToggleRewind(bool);
			bool AutoSetMode();
			void AutoSelectController(uint);
			void AutoSelectControllers();
			void ConnectController(uint,Nes::Input::Type);
			void PlaySong();
			void StopSong();
			void SelectNextSong();
			void SelectPrevSong();
			void Save(Io::Nsp::Context&);
			bool Load(Collection::Buffer&,const Path&,const Io::Nsp::Context&,bool);
			bool Unload();
			bool SaveState(Collection::Buffer&,bool,Alert=NOISY);
			bool LoadState(Collection::Buffer&,Alert=NOISY);
			bool Power(bool);
			bool Reset(bool);
			void Execute(Nes::Video::Output*,Nes::Sound::Output*,Nes::Input::Controllers*);
			void BeginNetplayMode();
			void EndNetplayMode();
			void DisableNetplay();
			void Unhook();

		private:

			struct Callbacks;

			class EventHandler
			{
				friend class Emulator;
				friend struct Callbacks;

				typedef Object::Delegate<void,Event> Callback;
				typedef Collection::Vector<Callback> Callbacks;

				Callbacks callbacks;

				~EventHandler();

				void operator () (Event) const;
				void Add(const Callback&);

			public:

				void Remove(const void*);

				template<typename Data,typename Code>
				void Add(Data* data,Code code)
				{
					Add( Callback(data,code) );
				}
			};

			struct Settings
			{
				Settings();
				~Settings();

				void Reset();

				struct Timing
				{
					inline Timing();

					uint speed;
					uint baseSpeed;
					bool speeding;
					bool sync;
					bool tripleBuffering;
					bool rewinding;
				};

				struct Fds
				{
					inline Fds();

					DiskImageSaveMethod save;
					Collection::Buffer original;
				};

				struct Cartridge
				{
					inline Cartridge();

					bool writeProtect;
				};

				Timing timing;

				struct
				{
					Path start;
					Path image;
					Path save;
					Path tape;
				}   paths;

				Cartridge cartridge;
				Fds fds;
				bool askSave;
			};

			struct State
			{
				typedef Object::Delegate<bool> Activator;
				typedef Object::Delegate<void> Inactivator;

				inline State();

				bool NoActivator();
				void NoInactivator();

				bool running;
				bool paused;
				Activator activator;
				Inactivator inactivator;
			};

			bool IsDiskImage(const Collection::Buffer&) const;
			bool UsesBaseSpeed() const;
			void EnableNetplay(const Netplay::Callback&,uint,uint);
			void Unpause();

			struct CallbackData;

			void LoadImageData(CallbackData&);
			void SaveImageData(CallbackData&) const;
			void LoadDiskData(Collection::Buffer&);
			void SaveDiskData(CallbackData&) const;

			State state;
			EventHandler events;
			Netplay netplay;
			Settings settings;

		public:

			bool Running() const
			{
				return state.running;
			}

			bool Idle() const
			{
				return !state.running;
			}

			bool Paused() const
			{
				return state.paused;
			}

			bool Speeding() const
			{
				return settings.timing.speeding;
			}

			bool Rewinding() const
			{
				return settings.timing.rewinding;
			}

			bool Is(uint a)
			{
				return Nes::Machine(*this).Is( a );
			}

			bool Is(uint a,uint b)
			{
				return Nes::Machine(*this).Is( a, b );
			}

			void AskBeforeSaving()
			{
				settings.askSave = true;
			}

			DiskImageSaveMethod GetDiskImageSaveMethod() const
			{
				return settings.fds.save;
			}

			void SetDiskImageSaveMethod(DiskImageSaveMethod method)
			{
				settings.fds.save = method;
			}

			void WriteProtectCartridge(bool state)
			{
				settings.cartridge.writeProtect = state;
			}

			bool CartridgeWriteProtected() const
			{
				return settings.cartridge.writeProtect;
			}

			const Path& GetStartPath() const
			{
				return settings.paths.start;
			}

			const Path& GetImagePath() const
			{
				return settings.paths.image;
			}

			const Path& GetSavePath() const
			{
				return settings.paths.save;
			}

			bool SyncFrameRate() const
			{
				return settings.timing.sync;
			}

			bool UseTripleBuffering() const
			{
				return settings.timing.tripleBuffering;
			}

			uint GetPlayer() const
			{
				return netplay.player;
			}

			uint NumPlayers() const
			{
				return netplay.players;
			}

			bool IsNetplaying() const
			{
				return netplay;
			}

			EventHandler& Events()
			{
				return events;
			}

			template<typename Data,typename Activator,typename Inactivator>
			void Hook(Data data,Activator activator,Inactivator inactivator)
			{
				state.activator.Set( data, activator );
				state.inactivator.Set( data, inactivator );
			}

			template<typename Data,typename Code>
			void EnableNetplay(Data data,Code code,uint player,uint players)
			{
				EnableNetplay( Netplay::Callback(data,code), player, players );
			}
		};
	}
}

#endif
