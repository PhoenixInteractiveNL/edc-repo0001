Turn Word Wrap ON if you're using Notepad.

Virtual APF Imagination Machine for Windows95/98, by James the Animal Tamer.

System Requirements:
====================
Fast system, Celeron 400MHz or equivalent recommended
Windows95/98
DirectX
16-bit video card (Virtual APF will work in other modes, but may be slow or not look right)
Sound card compatible with DirectX
Joypad(s)


Preliminary Note:
=================
Here's Virtual APF version 0.1.  The low number indicates that it is barely working, and lacking in most features.

Joypads are not implemented.  Press the SHIFT key on your keyboard when the APF BASIC screen appears.

An important feature in this early version is Quicktype (from the file menu).  This automatically types a text file.  The best way to use this is to edit a BASIC program as a text file using NOTEPAD.  Save it (from NOTEPAD).  Then use Quicktype to load it into the Virtual APF.  This is much easier than trying to type in a program on the Virtual APF itself (although that can be done -- beware, the odd layout of the original APF keyboard is emulated in Virtual APF).



What works:
=====================
CPU (It's a MAME 6808, with the CPX instructions broken so they do not change the C flag, to be like a 6800)
Memory (mostly)
Keyboard (emulated and sensible;  can be configured)
Video (In progress)
Quicktype (provides a means of loading in BASIC programs from text files)
Character set (good but not perfect)


What does NOT work:
=====================
Optional loading of other ROM OS
Insertion/removal of BASIC expansion cartridges
Sound (Help me!)
Timers (if any)
Interrupts (if any)
Peripherals
BASIC CLOAD
BASIC CSAVE
Insertion/removal of game cartridges
Video border
Joysticks
Accurate timing


What will NEVER work:
=====================
Modem or other RS-232c interface
Any peripheral I can't analyze
Pokemon (sorry, that's for the GAME BOY)


Still left to be done:
======================
Darn near everything


NOTES:
=====================

1.  Keyboard.  The keyboard operates in one of two modes:  Emulated or Sensible.  Emulated mode is most like the real APF keyboard;  use this mode for playing games.  Sensible makes it easier to type from the PC keyboard.  You can switch back and forth in the same session.



Versions:
=========

0.1:  August 8, 2000
	First useful version, but without any way to save programs.

