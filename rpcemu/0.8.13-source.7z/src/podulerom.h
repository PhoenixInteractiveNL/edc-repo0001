#ifndef PODULEROM_H
#define PODULEROM_H

#include <stdint.h>
#include "podules.h"

extern void initpodulerom(void);
extern void podulerom_reset(void);

#endif
