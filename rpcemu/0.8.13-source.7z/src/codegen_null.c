#include "rpcemu.h"
#include "mem.h"

void initcodeblocks(void)
{
}

void resetcodeblocks(void)
{
}

void cacheclearpage(uint32_t a)
{
}

