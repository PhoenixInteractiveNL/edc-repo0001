#ifndef PODULES_WIN_H
#define PODULES_WIN_H

#ifdef __cplusplus
extern "C" {
#endif

extern void opendlls(void);

#ifdef __cplusplus
}
#endif

#endif /* ! PODULES_WIN_H */
