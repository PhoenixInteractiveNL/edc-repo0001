RPCemu v0.2
~~~~~~~~~~~

RPCemu is a RiscPC emulator for Win32. At the moment it emulates an ARM7500
class machine - basically an A7000. It also supports two disc drives (so you
can always have !Boot loaded).

Changes from v0.1 :
~~~~~~~~~~~~~~~~~~~

- Ignored all unimplemented memory accesses, including Econet - RiscOS 3.7
  now works
- 70% speed increase
- CMOS now actually saves
- Cursor now correct colours
- Less restrictive ROM loading

At the moment RPCemu is unoptimised and has quite a few bugs, but is useable
as long as the program you are tring to run fits on a floppy and runs in a
supported video mode.

ROMs :
~~~~~~

RiscOS is a commercial product, please do not ask me to provide ROM images, as I
won't. However, they can be obtained from a real RiscPC/A7000 with the following 
commands :

*save ic24 3800000+100000
*save ic25 3800000+100000
*save ic26 3800000+100000
*save ic27 3800000+100000

or alternatively

*save rom  3800000+400000

The ROM files need to be placed in the roms directory.
RiscOS 3.6 and 3.7 both have been tested and work, not sure about any other
versions.
RPCemu will load in the disc images 'boot.adf' and 'notboot.adf' into :0 and :1
on startup if they exist, so that you can boot straight away. (the CMOS is
configured for this).

The disc access is a little buggy - from time to time errors like 'parameter not
recognised' crop up. Also discs can sometimes be corrupted, especially in drive 1,
when they've been written to - so keep backups!

Emulates :
~~~~~~~~~~

ARM7500
16mb RAM
Two high density 3.5" disc drives
VIDC20
IOMD
PS/2 keyboard and mouse

Doesn't emulate :
~~~~~~~~~~~~~~~~~

Sound
VRAM (A7000 remember)
Hard disc
Anything else

Performance on my system (AXP/2400) is useable, about the same speed as an
A7000 (around 16/17 MIPS on Windows 98, 18/19 MIPS on Windows XP). 
The performance partly depends on your graphics card - I noticed a doubling in 
speed after installing decent AGP drivers. It doesn't suffer from the usual 
drawbacks of an ARM7500 system as RPCemu doesn't emulate the slowdown associated 
with using DRAM for video.
The only video modes supported at the moment are 4, 16 and 256 colours, up to
1024x768. The cursor has the wrong colours at the moment.


Todo list :
~~~~~~~~~~~

Optimise memory accesses further
Finish VIDC20 support - implement other resolutions/colour depths and sound
Add some kind of hard disc emulation
Fix mouse in lower resolutions

Programs tested :
~~~~~~~~~~~~~~~~~

Working -

Blocks
Meteors
Minehunt
Patience
Syndicate (demo)
Wizard Apprentice (demo)
Sidewinder
Artworks Viewer
VKiller
Extend virus

Not working -

Bubble Impact
Almost anything by Krisalis


Tom Walker
tommowalker@yahoo.co.uk
b-em@bbcmicro.com