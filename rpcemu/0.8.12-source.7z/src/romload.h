#ifndef ROMLOAD_H
#define ROMLOAD_H

void loadroms(void);

#endif /* ROMLOAD_H */
