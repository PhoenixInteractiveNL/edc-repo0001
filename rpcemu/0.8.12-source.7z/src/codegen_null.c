#include "rpcemu.h"
#include "mem.h"

#ifndef DYNAREC
void initcodeblocks(void)
{
}

void resetcodeblocks(void)
{
}

void cacheclearpage(uint32_t a)
{
}
#endif
