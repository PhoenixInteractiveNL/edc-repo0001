#ifndef __GUI__
#define __GUI__

extern void entergui();

#endif //__GUI__
