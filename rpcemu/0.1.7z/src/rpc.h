/*RPCemu 0.1 by Tom Walker
  Main header file*/
  
/*ARM*/
unsigned long *usrregs[16],userregs[17],superregs[17],fiqregs[17],irqregs[17],abortregs[17],undefregs[17],systemregs[17];
unsigned long spsr[16];
unsigned long armregs[17];
int armirq,armfiq;
#define PC ((armregs[15])&r15mask)
int ins,output;
int r15mask;
int mode;

void resetarm();
void execarm(int cycles);
void dumpregs();
int databort;
unsigned long opcode,opcode2,opcode3;
int prog32;

unsigned long *ram,*rom,*vram;
unsigned char *ramb,*romb,*vramb;

int mmu,memmode;

/*IOMD*/
struct iomd
{
        unsigned char stata,statb,statc,statd,statf;
        unsigned char maska,maskb,maskc,maskd,maskf;
        unsigned char romcr0,romcr1;
        unsigned long vidstart,vidend,vidcur,vidinit;
        int t0l,t1l,t0c,t1c,t0r,t1r;
        unsigned char ctrl;
        unsigned char vidcr;
        unsigned char sndstat;
        unsigned char keydat;
        unsigned char msdat;
} iomd;

int i2cclock,i2cdata;

int kcallback,mcallback;

unsigned long cinit;
int fdccallback;
int motoron;
