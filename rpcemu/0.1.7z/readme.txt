RPCemu v0.1
~~~~~~~~~~~

RPCemu is a RiscPC emulator for Win32. At the moment it emulates an ARM7500
class machine - basically an A7000. It also supports two disc drives (so you
can always have !Boot loaded).

Files in this archive -
RPCemu.exe  - The emulator itself.
alleg41.dll - Required DLL file
cmos.ram    - CMOS RAM
readme.txt  - This file
src\*       - Source (needs Ming/W and Allegro to compile)

At the moment RPCemu is unoptimised and has quite a few bugs, but is useable
as long as the program you are tring to run fits on a floppy and runs in a
supported video mode.

You will need 4 1mb rom images named ic24, ic25, ic26 and ic27. These can be
dumped from a RiscPC / A7000 with the following commands :

*save ic24 3800000+100000
*save ic25 3800000+100000
*save ic26 3800000+100000
*save ic27 3800000+100000

I've only tested RiscOS 3.6, so I can only verify that that version will work.
RPCemu will load in the disc images 'boot.adf' and 'notboot.adf' into :0 and :1
on startup if they exist, so that you can boot straight away. (the CMOS is
configured for this).

The disc access is a little buggy - from time to time errors like 'parameter not
recognised' crop up, and sometimes RiscOS hangs in the middle of disc operations
(though that is rare). Also discs can sometimes be corrupted, especially in drive 1, 
when they've been written to - so keep backups!

Emulates :

ARM7500
16mb RAM
Two high density 3.5" disc drives
VIDC20
IOMD
PS/2 keyboard and mouse

Doesn't emulate :

Sound
VRAM (A7000 remember)
Hard disc
Anything else

Performance on my system (AXP/2400) is useable, but slow (around 9-11 MIPs,
depending on OS). 
The performance depends on your graphics card - I noticed a doubling in speed
after installing decent AGP drivers. It doesn't suffer from the usual drawbacks 
of an ARM7500 system as RPCemu doesn't emulate the slowdown associated with 
using DRAM for video.
The only video modes supported at the moment are 16 and 256 colours, up to
1024x768. The cursor has the wrong colours at the moment.

Todo list :

Implement TLB-like system to speed up memory access
Implement dirty buffering for video - will be useful at higher resolutions
Finish VIDC20 support - implement other resolutions/colour depths and sound
Add some kind of hard disc emulation

Programs tested :

Working -

Blocks
Meteors
Minehunt
Patience
Syndicate (demo)
Wizard Apprentice (demo)
Sidewinder
Artworks Viewer
VKiller
Extend virus

Not working -

Bubble Impact
Almost anything by Krisalis


Tom Walker
tommowalker@yahoo.co.uk
b-em@bbcmicro.com