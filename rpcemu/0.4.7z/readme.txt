RPCemu v0.4
~~~~~~~~~~~

RPCemu is a RiscPC emulator for Win32. At the moment it emulates an ARM7500
class machine - basically an A7000 - or a RiscPC 600/700/SA with or without VRAM. 
It also supports two disc drives and two IDE hard drives.

RPCemu is licensed under the GPL, see COPYING for more details.

There is a preliminary Linux port also, see linux/linux.txt for more details.


Changes from v0.3 :
~~~~~~~~~~~~~~~~~~~

- Fixed stupid bug with flyback bit in IOMD control register - RiscOS 3.x now
  starts up correctly every single time (why did XXXX X work?).
- Rewritten video emulation - now supports 16-bit & 32-bit colour, has correctly 
  coloured cursor, some video acceleration, etc.
- HostFS - allows access of the Windows filesystem from RISC OS
- Now supports 2 hard discs
- Now supports >16 megs RAM, and VRAM


ROMs :
~~~~~~

RiscOS is a commercial product, please do not ask me to provide ROM images, as I
won't. However, they can be obtained from a real RiscPC/A7000 with the following 
commands :

*save ic24 3800000+100000
*save ic25 3800000+100000
*save ic26 3800000+100000
*save ic27 3800000+100000

or alternatively

*save rom  3800000+400000

On later RiscOS versions you may need to type

*save rom  3800000+600000

The ROM files need to be placed in the roms directory.
RiscOS 3.6, 3.7 and X.XX have been tested and work, not sure about any other 
versions.
RPCemu will load in the disc images 'boot.adf' and 'notboot.adf' into :0 and :1
on startup if they exist, so that you can boot straight away. (the CMOS is
configured for this). It will also load in hd4.hdf and hd5.hdf straight on startup.

Floppy discs can sometimes be corrupted when they've been written to - so keep backups!
IDE emulation appears to be fine though.


Emulates :
~~~~~~~~~~

ARM610/ARM710/ARM7500 (selectable)
4-128mb RAM
Up to 2mb VRAM
Two high density 3.5" disc drives
Two IDE hard drive
VIDC20
IOMD
PS/2 keyboard and mouse


Doesn't emulate :
~~~~~~~~~~~~~~~~~

Sound
Networking
Anything else


Performance on my system (AXP/2400) is useable, a bit faster than an ARM710 (around 
16/17 MIPS on Windows 98, 18/19 MIPS on Windows XP - about 55-60 mhz - mind you since
I only have an ARM610 in real life this is largely guesswork).  
The emulator runs faster on an Athlon than a P4, A P4 2.6ghz with otherwise superior 
components gets about 14 MIPS.

The performance partly depends on your graphics card - I noticed a doubling in 
speed after installing decent AGP drivers. It doesn't suffer from the usual 
drawbacks of an ARM7500 system as RPCemu doesn't emulate the slowdown associated 
with using DRAM for video.


Hard disc emulation :
~~~~~~~~~~~~~~~~~~~~~

You will need to format the hardfile to make use of it. !HForm will do the
job. There are a couple of things to note when formatting :

- The hard disc must always have 63 sectors and 16 heads
- The number of cylinders can vary, the default 101 gives about 50 megs
- Never run a long soak test on the hard disc - this does not work!

Once formatted you can copy the boot sequence from floppy (or just download
the preprepared hardfile). To get RiscOS to boot off hard disc, type the 
following commands at the command prompt :

*dir adfs::4.$
*opt 4,2
*configure drive 4


HostFS :
~~~~~~~~

HostFS always reads from the hostfs directory. Filetypes are represented as 3 digit
hex numbers after a comma, or a pair of load/exec addresses.

I am not aware of any bugs with HostFS, however if you come across any let me know.

One problem is that as the HostFS module is software loaded, it is impossible to boot
from HostFS. Therefore, a disc image or hardfile must always be present.


Other things :
~~~~~~~~~~~~~~

When switching between ARM610/ARM710 and ARM7500, you may need to reconfigure
the mouse type (depending on what OS you are running). Hit F12 and type

*configure mousetype 0

for ARM610/ARM710 and

*configure mousetype 3

for ARM7500.


RPCemu requires your desktop to be in either 16 or 32 bit colour. I don't think this
is unreasonable - I had to go back to 1999 to find a graphics card that actually 
supported 24-bit colour, and I suspect very few people will run in this depth anyway.

Obviously if your desktop is in 16 bit colour there is very little point in putting
RISC OS into 32 bit colour.


Todo list :
~~~~~~~~~~~

Optimise more
Make sound work
Add/finished StrongARM emulation (removed from this release due to being incomplete)


Programs tested :
~~~~~~~~~~~~~~~~~

Programs that worked :

Blocks
Meteors
Minehunt
Patience
Syndicate (demo)
Wizard Apprentice (demo)
Chaos Engine (demo)
Lemmings 2 (lacks palette splitting though - use Arculator instead!)
Sidewinder
Artworks Viewer
VKiller
Extend virus
FreeDoom
Dune II
Bubble Impact
ScummVM
AMPlayer

Programs that didn't :

ArcQuake (hangs)
OpenTTD (hangs)


Thanks to :
~~~~~~~~~~~

Graeme Barnes for a lot of help when I first started.
Peter Naulls for the Linux port and the SVN.
The Arcem team for the HostFS code.
Jan Rinze for some optimisations and for working on a PocketPC port.
Dave Moore for the site design, hosting (also Netnorth) and feedback.
Allegro team for Allegro.
Anyone else I forgot.


Tom Walker
tommowalker@yahoo.co.uk
b-em@bbcmicro.com