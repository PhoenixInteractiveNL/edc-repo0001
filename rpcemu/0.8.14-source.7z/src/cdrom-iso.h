#ifndef CDROM_ISO_H
#define CDROM_ISO_H

extern int iso_open(const char *fn);

void iso_init(void);

#endif

