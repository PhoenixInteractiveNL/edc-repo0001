RPCemu v0.7
~~~~~~~~~~~

RPCemu is an Acorn RiscPC emulator, currently available for for Win32, Linux and 
DOS.

RPCemu is licensed under the GPL, see COPYING for more details.


Features :
~~~~~~~~~~

- Emulates ARM610, ARM710, ARM7500 and StrongARM processors
- Interpretive CPU emulation runs at >= ARM610 speeds on modern x86 PCs
- Dynamic recompiler runs at around StrongARM speeds on modern x86 PCs
- Up to 128mb RAM
- Up to 2mb VRAM
- Full video emulation, supporting all video modes
- 16-bit sound emulation
- Emulates two floppy drives
- Emulates two IDE hard disc drives
- Can emulate an IDE CD-ROM drive
- HostFS allows access to native file system from RISC OS


Changes from v0.51 :
~~~~~~~~~~~~~~~~~~~

- New dynamic recompiler CPU core - between 2 and 4 times the speed of the
  interpreter, depending on machine, applications etc.
- RISC OS 4 now works properly with lazy task swapping on recompiler.
- CD-ROM support. .ISO images on all platforms, direct drive access on Windows
  and Linux.
- Now supports hard disc images above 2gb - the new limit is 32gb.
- New DOS port.
- Now compiles and (mostly) works on big-endian machines (eg PowerPC Macintosh).
- Source code improved a bit.


Which version to run :
~~~~~~~~~~~~~~~~~~~~~~

Two builds of RPCemu are included. RPCemu interpreter.exe is the older interpreter,
while RPCemu recompiler.exe is the new dynamic recompiler. It is generally advised to
use the dynamic recompiler, unless you wish to use RISC OS 3.5 or 3.6, or run an
application which does not work on the recompiler. RISC OS 4 does not run very well
on the interpreter, so you are advised to use the recompiler for that.


ROMs :
~~~~~~

RPCemu requires a ROM dump of RISC OS in order to work. As RISC OS is a commercial 
product, ROM images are not provided. However, they can be obtained from a real 
RiscPC/A7000 with the following commands :

*save ic24 3800000+100000
*save ic25 3800000+100000
*save ic26 3800000+100000
*save ic27 3800000+100000

or alternatively

*save rom  3800000+400000

The ROM files need to be placed in the roms directory.

RISC OS versions 3.6, 3.7, 4.02, 4.39 and 6.02 have all been confirmed as working.
RISC OS 3.6 does not work on the recompiler, as it is not StrongARM compatible.
RISC OS 4+ does not work properly on the interpreter in StrongARM mode.


Menu options :
~~~~~~~~~~~~~~

On the Linux and DOS versions, you must press CTRL + END to enter the menu.


File->Reset - Hard-resets the RiscPC. You will loose all unsaved work. Don't use during an
    IDE hard disc operation, or your disc image will be corrupted! ('Bad Directory' errors
    and the like).

File->Exit  - Exits back to Windows/Linux/DOS/OS X/RISC OS/whatever

Disc->Load Disc :0 - Loads a .ADF disc image into drive :0

Disc->Load Disc :1 - Loads a .ADF disc image into drive :1

Settings->Configure - Opens the configuration window. The options here are :

 - CPU type
   Choice of ARM610, ARM7500, ARM710 and StrongARM. 
   Only StrongARM is supported on the recompiler.

 - RAM size
   Choice from 4mb to 128mb

 - VRAM size
   Choice of none or 2mb. With CPU set to ARM7500 this choice will have no effect.
   Only 2mb is supported on the recompiler.

 - Sound enable

 - Video refresh rate
   Choice from 20 fps to 100 fps. Default is 60. Lower values will speed up the emulator, but
   the video will obviously become more jerky and this may have an impact on games and demos
   that base their timing on this. 
   For many older games it is best to set this to 50 fps.

Settings->Fullscreen mode - Puts Windows RPCemu into fullscreen mode. Press CTRL+END to 
    return to windowed mode. RPCemu will attempt to change video mode as RISC OS does, to 
    attempt to match it as closely as possible.

Settings->Alternative blitting code - Workaround for a bug discovered when using my                                        
    GeForce 256. Enable if there are obvious video problems when eg moving the mouse around 
    the desktop. If you don't need it then leave it off - it can be slower than normal.

Settings->Blitting optimisation - Allow RPCemu to avoid processing the video when there are
    obviously no changes. Gives a speedup, but has major usability problems on some Windows 
    systems - the mouse appears to 'stick' and be generally unusable.

Settings->Mouse hack - Linux RPCemu uses a hack to make the RISC OS mouse pointer follow
    the native pointer. In many games this does not work, so disable this to turn it off.

Settings->CD-ROM - various options for the CD-ROM emulation. Disabled disables all CD-ROM
    functions, and must be selected if you want to use two hard disc images.

Speed :
~~~~~~~

Most PCs made in the last 5 years should be able to deliver performance similar to an A7000 or
RiscPC 600. The recompiler puts these machines into StrongARM territory.

RPCemu reports how many millions of instructions are executed per second (MIPS). This figure
has been widely misinterpreted in the past, partly due to Acorn giving their machines very
optimistic performance figures, and partly due to confusion with the DMIPS figure reported by
the Dhrystone benchmark.

It is better to compare RPCemu and real Acorn hardware running actual applications or benchmarks,
such as Dhrystone (though that itself is not entirely reliable), instead of comparing RPCemu's 
MIPS count with what an ARM6 or ARM7 is theoretically capable of.


I have tested RPCemu v0.7 and v0.6 on several machines :

Athlon X2 4200+ (2.2ghz), 1gb DDR400 RAM, GeForce 6600GT, Windows XP + SP2, Linux (64-bit)
Interpreter - ~34 MIPS, 83k Dhrystones/sec - around double ARM610 performance
Recompiler  - ~100 MIPS, 310k Dhrystones/sec - around StrongARM performance
I have seen the recompiler max out at 230 MIPS on this machine.
Linux speeds were slightly slower overall

Athlon XP 2400+ (2ghz), 512mb DDR266 RAM, Radeon 7000, Windows XP
Interpreter - ~26 MIPS, 59k Dhrystones/sec - ARM710 performance

Pentium M 1.7ghz, 512mb DDR266 RAM, onboard graphics, Windows XP + SP2
Interpreter - ~26 MIPS, 58k Dhrystones/sec - ARM710 performance

Athlon XP 2000+ (1.6ghz), 256mb PC133 RAM, GeForce 3, Windows XP + SP2
Interpreter - ~21 MIPS, 44k Dhrystones/sec - ARM610 performance

Athlon 1.4ghz, 256mb DDR266 RAM, Radeon 7000, Windows XP
Interpreter - ~20 MIPS, 42k Dhrystones/sec - ARM610 performance


I have not been able to try RPCemu on a Pentium 4 machine for a while, but the last time I tried
a Pentium 4 2.8ghz machine ran RPCemu at similar speeds to the two slower Athlons.

Video speeds are dependent on graphics card speeds. The two slower machines gave poor video speeds.
The Pentium M machine was very quick with video, most likely due to the shared memory video system.
The Athlon X2 was also very quick, partly due to a faster graphics card + AGP bus, partly due to
the video overhead being 'hidden' by the second core.
The Athlon XP 2400+ was very fast as well, for unknown reasons.


Hard disc emulation :
~~~~~~~~~~~~~~~~~~~~~

You will need to format the hardfile to make use of it. !HForm will do the
job. There are a couple of things to note when formatting :

- The hard disc must always have 63 sectors and 16 heads
- The number of cylinders can vary. The default gives the maximum 32gb hard
  disc size. When formatting, this figure should generally be double the
  desired size in megabytes.
- Never run a long soak test on the hard disc - this does not work!

Once formatted you can copy the boot sequence from floppy (or just download
the preprepared hardfile). To get RiscOS to boot off hard disc, type the 
following commands at the command prompt :

*dir adfs::4.$
*opt 4,2
*configure drive 4


HostFS :
~~~~~~~~

HostFS always reads from the hostfs directory. Filetypes are represented as 3 digit
hex numbers after a comma, or a pair of load/exec addresses.

I am not aware of any bugs with HostFS, however if you come across any let me know.

One problem is that as the HostFS module is software loaded, it is impossible to boot
from HostFS. Therefore, a disc image or hardfile must always be present.


Sound :
~~~~~~~

RPCemu emulates the 16-bit sound system. This should mostly work okay now. If the emulator
suddenly slows down to below about 3 MIPS (as might happen on lesser machines with lots of
high resolution video updates) then the sound will probably break up quite badly. If the
emulator speeds back up again the sound should be able to recover.

There is the odd glitch when the RiscPC's sound playback frequency is changed, when a sound
player starts up for the first time.


Other things :
~~~~~~~~~~~~~~


When switching between ARM610/ARM710/StrongARM and ARM7500, you may need to reconfigure
the mouse type (depending on what OS you are running). Hit F12 and type

*configure mousetype 0

for ARM610/ARM710 and

*configure mousetype 3

for ARM7500.


RPCemu requires your desktop to be in either 16 or 32 bit colour. I don't think this
is unreasonable - I had to go back to 1999 to find a graphics card that actually 
supported 24-bit colour, and I suspect very few people will run in this depth anyway.

Obviously if your desktop is in 16 bit colour there is very little point in putting
RISC OS into 32 bit colour.

Fullscreen mode inherits whatever colour depth your desktop is in.


Todo list :
~~~~~~~~~~~

Add support for an IDE podule, so you can have more than two hard drives / one hard drive
+ one cd drive. The RiscPC was released in 1994, so I don't know why they couldn't have put
a better IDE controller on the motherboard.

Add network support. I don't really understand this.

Fix up sound support (+ add it to Linux build).

Fix remaining bugs.


Programs tested :
~~~~~~~~~~~~~~~~~

Programs that worked :

Games :

Alone In The Dark (demo) - glitches on recompiler
Ankh (demo)
ArcQuake/Quake Resurrection (latter keeps complaining about timer 1)
Blocks
Bubble Impact
Chaos Engine (demo)
Dune II
FreeDoom
High Risc Racing
Lemmings 2 (lacks palette splitting though - use Arculator instead! Also not in RISC OS 3.7+)
Meteors
Minehunt
OpenTTD
Patience
Puzznix
ScummVM
Sidewinder
Spheres of Chaos 2
Syndicate (demo)
Wizard Apprentice (demo)
XylonII


Demos :

BASS - Jan3D
DFI - Fishtank2
DFI - July
DFI - K2
Kulture - Freestyle
Quantum - Icon
Reactive - Reactivity
TXP - Blu
TXP - Era
Zarquon - Metamorph


Other :

Artworks Viewer
VKiller
Extend virus
AMPlayer
LongFiles
!CPC
SnesEmu
MAME


Stuff that _doesn't_ work :

!A310emu - RISC OS doesn't start up correctly
Debian Linux - aborts when running BusyBox
NetBSD - newer bootloader plain doesn't work, BASIC bootloader works but hangs later on.


Tom Walker
tommowalker@yahoo.co.uk
b-em@bbcmicro.com