#include "rpcemu.h"

#ifndef DYNAREC
void initcodeblocks()
{
}

void resetcodeblocks()
{
}

void cacheclearpage(uint32_t a)
{
}
#endif
