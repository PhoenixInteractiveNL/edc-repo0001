#ifndef GUI_H
#define GUI_H

void entergui(void);

#endif
