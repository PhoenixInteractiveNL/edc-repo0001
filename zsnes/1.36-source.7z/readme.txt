If you need help to compile ZSNES, read install.txt, or if you want a directory
to the sources, read srcinfo.txt. The offical website is at http://www.zsnes.com
and the sourceforge mirror is at http://zsnes.sourceforge.net/. The general
discussion irc channel is #zsnes on EFNet, and the development chat is on
#zsnes on irc.openprojects.net.
