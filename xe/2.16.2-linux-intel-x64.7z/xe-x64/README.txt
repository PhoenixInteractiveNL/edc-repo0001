*Requirements*

GTK+2.10 or above is required. Since GTK+ could be configured differently on
different systems, you will need to link Xe manually. 

------------------------------------------------------------------------

*Simple Install*

Install to system directory:

   1. login as root
   2. 'make' to link the software
   3. 'make install' will install it to the system directory 

*Manual Install*

Install to system directory:

   1. login as root
   2. 'make' to link the software
   3. 'mkdir /usr/local/lib/xe' to create system directory
   4. 'mv xe rc modules manual.html /usr/local/lib/xe' to move files to
      system directory
   5. 'ln -sf /usr/local/lib/xe/xe /usr/local/bin/xe' to link binary into
      system path 

Install to user directory:

   1. 'make' to link the software
   2. 'mkdir ~/.xe' to create local directory
   3. 'mv xe rc modules manual.html ~/.xe' to move file to local directory
   4. link or move ~/.xe/xe' to your local bin directory 

------------------------------------------------------------------------

For more information please read the user's manual at:

http://www.xe-emulator.com/
