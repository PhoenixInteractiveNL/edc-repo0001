#!/bin/sh

BINDIR=/usr/local/bin
SYSDIR=/usr/local/lib/xe
BIODIR=${SYSDIR}/bios

if [ `whoami` == root ]; then		# must be logged as root

  for i in $SYSDIR $BIODIR; do
    if [ ! -d $i ]; then		# if dir does not exist, create
      mkdir $i >& /dev/null
      if [ $? != 0 ]; then
        echo unable to create $i   
        exit
      fi
    fi
  done

  cp -rf xe modules rc manual.html $SYSDIR >& /dev/null	# Copy files
  if [ $? != 0 ]; then
    echo unable copy files to $SYSDIR
    exit
  fi

  ln -sf $SYSDIR/xe $BINDIR/xe		# link binary to bin path
  if [ $? != 0 ]; then
    echo unable to link $BINDIR/xe
    exit
  fi

  echo xe successfully installed	# done

else

  echo Must be logged on as root.

fi
