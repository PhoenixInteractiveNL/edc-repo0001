After Burner II Force Feedback driver v1.00
==============================================
			Compatible with Gens32 Surreal v1.28 LDU+ or heigher


How to use:
Copy this driver to Gens32's folder.Rename it to your rom's name(not the zip folder's name) if necessary.


You can use MODE key to On/Off Force Feedback.


