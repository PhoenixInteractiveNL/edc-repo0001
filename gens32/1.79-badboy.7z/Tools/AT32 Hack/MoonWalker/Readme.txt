This patch,is released by KenTse.

To use this patch,you also need 5 music tracks.Buy the CD to convert them into mp3,or remix new one yourself.

The target rom is:
Michael Jackson's Moonwalker (JUE) (REV 00) [!].bin

Mini version of Gens32 Surreal required:
Gens32 Surreal v1.66 fancy

How to use it:

required music:
1) Smooth criminal

2) Beat It

3) Another Part Of Me

4) BillyJean

5) BAD

copy the music to patched rom's folder,then rename as follows,the rom name is Michael Jackson's Moonwalker (JUE) (REV 00) [!].bin:


Smooth criminal  -> Michael Jackson's Moonwalker (JUE) (REV 00) [!]_1.mp3

Beat It -> Michael Jackson's Moonwalker (JUE) (REV 00) [!]_2.mp3

Another Part Of Me -> Michael Jackson's Moonwalker (JUE) (REV 00) [!]_3.mp3

BillyJean -> Michael Jackson's Moonwalker (JUE) (REV 00) [!]_4.mp3

BAD -> Michael Jackson's Moonwalker (JUE) (REV 00) [!]_5.mp3

Ok,then just load the Rom and enjoy! You can adjust the volume of music by adjust CDDA volume. 
