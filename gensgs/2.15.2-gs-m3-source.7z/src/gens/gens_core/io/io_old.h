#ifndef GENS_IO_OLD_H
#define GENS_IO_OLD_H

#ifdef __cplusplus
extern "C" {
#endif

unsigned char RD_Controller_1_TP(void);
unsigned char RD_Controller_2_TP(void);
void Make_IO_Table(void);

#ifdef __cplusplus
}
#endif

#endif
