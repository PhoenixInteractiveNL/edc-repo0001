#ifndef SCRSHOT_H
#define SCRSHOT_H

#include "g_main.h"

extern char ScrShot_Dir[GENS_PATH_MAX];

int Save_Shot(void);

#endif
