#ifndef GENS_INPUT_NET_H
#define GENS_INPUT_NET_H

#ifdef __cplusplus
extern "C" {
#endif

void Scan_Player_Net(int Player);
void Update_Controllers_Net(int num_player);

#ifdef __cplusplus
}
#endif

#endif

#endif
