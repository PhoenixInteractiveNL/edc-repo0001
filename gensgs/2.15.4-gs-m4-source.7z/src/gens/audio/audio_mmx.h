/**
 * Gens: Audio output functions, MMX-optimized.
 */

#ifndef GENS_AUDIO_MMX_H
#define GENS_AUDIO_MMX_H

#ifdef __cplusplus
extern "C" {
#endif

void writeSoundMono_MMX(int *left, int *right, short *dest, int length);
void writeSoundStereo_MMX(int *left, int *right, short *dest, int length);

#ifdef __cplusplus
}
#endif

#endif /* GENS_AUDIO_MMX_H */
