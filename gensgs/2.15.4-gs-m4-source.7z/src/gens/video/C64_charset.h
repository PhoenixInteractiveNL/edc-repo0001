/***************************************************************************
 * Gens: Commodore 64 Character Set.                                       *
 *                                                                         *
 * Copyright (c) 1982 Commodore International                              *
 ***************************************************************************/

#ifndef GENS_C64_CHARSET_H
#define GENS_C64_CHARSET_H

#ifdef __cplusplus
extern "C" {
#endif

extern const unsigned char C64_charset[256][8];

#ifdef __cplusplus
}
#endif

#endif /* GENS_C64_CHARSET_H */
