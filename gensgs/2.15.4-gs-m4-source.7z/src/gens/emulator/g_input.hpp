/**
 * GENS: Input handler.
 */

#ifndef GENS_G_INPUT_HPP
#define GENS_G_INPUT_HPP

#ifdef __cplusplus
extern "C" {
#endif

void Input_KeyDown(int key);
void Input_KeyUp(int key);

#ifdef __cplusplus
}
#endif

#endif
