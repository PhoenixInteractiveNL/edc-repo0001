#ifndef _SH2D_H_
#define _SH2D_H_

void SH2Disasm(char *c, unsigned v_addr, unsigned short op_norm, int mode);

#endif
