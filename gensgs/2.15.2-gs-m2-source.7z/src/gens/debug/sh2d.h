#ifndef _SH2D_H_
#define _SH2D_H_

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifdef GENS_DEBUG

void SH2Disasm(char *c, unsigned v_addr, unsigned short op_norm, int mode);

#endif /* GENS_DEBUG */

#endif /* _SH2D_H_ */
