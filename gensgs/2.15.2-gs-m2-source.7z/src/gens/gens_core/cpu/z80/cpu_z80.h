#ifndef _CPU_Z80_H
#define _CPU_Z80_H

int Z80_Init(void);
void Z80_Reset(void);

#endif
