/**
 * GENS: Sega 32X VDP - 32-bit color functions.
 * Provided by Upth, ported from Gens Rerecording
 */


#ifndef GENS_32X_32BIT_H
#define GENS_32X_32BIT_H

#ifdef __cplusplus
extern "C" {
#endif

void Post_Line_32X(void);

#ifdef __cplusplus
}
#endif

#endif
