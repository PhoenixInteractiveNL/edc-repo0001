/**
 * GENS: Main loop. (Win32 specific code)
 */

#include "gens.h"
#include "g_main.h"
#include "g_input.h"

/**
 * Get_Save_Path(): Create the default save path.
 * @param *buf Buffer to store the default save path in.
 */
void Get_Save_Path(char *buf, size_t n)
{
	// TODO
	//strncpy(buf, getenv ("HOME"), n);
	//strcat(buf, "/.gens/");
	strcpy(buf, "C:\\");
}

/**
 * Create_Save_Directory(): Create the default save directory.
 * @param *dir Directory name.
 */
void Create_Save_Directory(const char *dir)
{
	// TODO
	//mkdir(dir, 0700);
}
