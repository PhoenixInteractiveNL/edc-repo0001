/**
 * GENS: Main loop. (Win32-specific code)
 */

#ifndef G_MAIN_WIN32_H
#define G_MAIN_WIN32_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef DATADIR
#undef DATADIR
#endif

#include <windows.h>

void Get_Save_Path(char *buf, size_t n);
void Create_Save_Directory(const char *dir);
int Init_OS_Graphics(void);
void End_OS_Graphics(void);

#ifdef __cplusplus
}
#endif

#endif
