
---------------------------------------------------------------------------
Kega Fusion v0.1b BETA (C) Steve Snake 2004
---------------------------------------------------------------------------


Whats New ?
-----------

ForceCompatibleGFX=1
CompatibleGFXOpt=0
EnhancedGFXOpt=1
DebugFlags=0,0,1,1

Quick update:

* Fixed the problem whereby you couldn't define the space bar as a key.

* Modified Graphics Code. Should now work by default on more systems.

* Moved the INI file settings to the top of the file for easier access.

* Added Render Plugin Support

The Graphics stuff and INI file editing:

There are now 4 different modes you can try - by default it uses a more
compatible, but possibly slower mode. If everything works fine you can
try setting EnhancedGFXOpt to 1 to see if that also works - this is usually
the fastest mode. If neither enhanced mode 0 or 1 work, you can set
ForceCompatibleGFX to 1, and then try CompatibleGFXOpt at 0 or 1 to see
which is the fastest. Also, on some older cards the enhanced mode may be
quite slow - if this is the case you should use Compatible mode.

I hope that this now works on a much wider range of graphics cards - let
me know :)

Snake.

---------------------------------------------------------------------------
Kega Fusion v0.1 BETA (C) Steve Snake 2004
---------------------------------------------------------------------------


What is Fusion ?
----------------

Fusion is the logical successor to my previous emulator, Kega.

Please note that there are features which I had planned to implement, but
due to time restraints these are not yet present (see bottom of this file)
Also please note that this is BETA code - I haven't had the time to test
it thorougly at all yet - and much of it is new code. There may be some
glaring problem that I have missed - please tell me about it. I decided
that you've waited long enough and it was time to let you play with it.

That said, at this moment in time, and to the best of my knowledge, Fusion:

* Emulates the Sega SG-1000, SC-3000, Master System, and GameGear with a
  high degree of accuracy.

* Emulates the Sega MegaDrive/Genesis more accurately than any other
  emulator.

* Emulates the Sega MegaCD/SegaCD more accurately than any other emulator.

* Emulates the Sega 32X more accurately than any other emulator. 

* Has many other interesting new features.

By popular request I have kept the user interface, look and feel of Fusion
as close to Kega as possible - although the vast majority of the underlying
code has been completely rewritten from scratch - hence it is the fusion of
old and new. But as it is a different emulator it can't really be compared
(compatibility/bug wise) to any previous emulator.

The similarity of UI, however, means that users of Kega should be right at
home with Fusion.

Be sure to check out the Technical and Special Features sections of this
file for some information you may not otherwise know about, and some
differences between Fusion and Kega. Also note that although I am fairly
confident of the current functionality of Fusion, it has yet to receive
any serious testing, and is hence considered BETA. Bug reports are very
welcome :-)

---------------------------------------------------------------------------
Using Fusion - the basics
---------------------------------------------------------------------------

The basic operation of Fusion should be fairly self-explanatory, so until a
proper manual exists, here is some basic information on using it.

Some more detail, and some "special features" are explained at the end of
this file.


FILE menu
---------

Load MasterSystem ROM - Load a MasterSystem/SG-1000/SC-3000 ROM

Load GameGear ROM     - Load a GameGear ROM

Load Genesis/32X ROM  - Load a Genesis or 32X ROM

Load SegaCD Image     - Load a SegaCD ISO,BIN,CUE or SCD Image

Boot SegaCD           - Boot SegaCD from a real CD in your drive

Soft Reset            - Soft Reset the current console

Power Off             - Power off the current console

Power On/Hard Reset   - Power On or Hard Reset current console

Game Genie            - Enter / Edit / Toggle Game Genie codes

Load State As         - Load a specified State File

Save State As         - Save to a specified State File

Load State/Save State - Load or Save to one of 10 State Slots

Change State Slot     - Select State Slot for Load/Save

Load RAM Cart         - Load a SegaCD RAM Cartridge

Create New RAM Cart   - Create and Load a new SegaCD RAM Cartridge

Exit                  - Exits Fusion


COUNTRY menu
------------

Select USA/JAP/EUR modes, or Auto Detect. Auto Detect may not work for all
games because of incorrect data in the ROM header. You can also select the
preferred order of country detection, for games that work in more than one
region.


VIDEO menu
----------

From here you can select (seperately) the Window size (for Windowed Mode)
and the Resolution (for FullScreen Mode). The options available will depend
on your system. The Window is limited to sizes that match the aspect ratio
of a standard TV (4:3) - whereas the Resolutions are not - in order to
accomodate TFT displays with non 4:3 aspects, such as 1280x1024. There is
an option "Force Aspect" which will cause Fusion to fit the display as best
as possible to the Resolution while still keeping the correct 4:3 Aspect
Ratio.

Also here you can toggle FullScreen or Windowed mode, enable or disable
VSync, and select the render mode between Normal, one of 4 Scanlines modes,
and TV Mode.


SOUND menu
----------

From here you can enable/disable sound emulation, and choose your desired
samplerate.

It is recommended that, if your PC is fast enough, you select "SuperHQ"
mode. The soundchips in each console are emulated much more accurately in
this mode, and sound very close to the real thing. The samplerate will also
be fixed to 44100Hz when you select this mode.

The OVERDRIVE option doubles the volume of sound output, making it sound
closer in volume to most other emulators using the MAME sound core. However
doing this means that the YM2612, and possibly other chips, are slightly
distorted by clipping. If you turn this option off, and your speakers up,
you will get a slightly cleaner sound. But no doubt most users will prefer
OVERDRIVE mode, since the difference in quality may be very subtle.

You can log sound output to either a WAV file, or a VGM file. Select either
of these options, choose a filename to log to, and the logging will begin.
To stop logging at any time, simply select the option again.


DRIVE menu
----------

Your CD-ROM drive(s) should appear here, if available. Select the one you
wish to boot from.


OPTIONS menu
------------

SET CONFIG - See CONFIG

PERFECT SYNC - Some SegaCD/MegaCD games will only run correctly if the two
MC68000 processors inside the console are perfectly syncronised. This
option enables this feature. It requires slightly more processor power to
use this feature, so you may want to disable it for games that do not need
it. Although it should be safe to leave it enabled all the time, if you
notice any problems with certain Mega/SegaCD games, you may wish to try it
both ways.

You can choose to enable or disable display of a frames per second counter,
and the SegaCD LEDs.

USE ALTERNATE TIMING - Normally the sound card will be used for timing
purposes - this ensures a clean, pop/gap free sound stream. However, some
sound cards/drivers do not provide accurate timing information. If you
notice any speedup / slowdown or inconsistent speed problems, you can try
enabling alternate timing instead. Note though that you may get some
problems with sound if you do so. This option will be forced ON if you
have no sound card in your machine, or you disable sound.


CONFIG
------


SMS/GG:
-------

You can specify where to find the USA/JAP/EUR BIOS files for the Sega
Master System, and the GG BIOS file for the GameGear. None of these files
are required for operation, but you can use them if you wish.

SxM Files - these are the emulated battery-backed RAM files used in some
cartridges. Select the folder where you want these files to be saved.

State Files - See LOAD/SAVE STATE. Select the folder where you want these
files to be saved.

You can also disable some things that are enabled by default:

* Sprite Limiter - a real SMS/GG can only display a small number of
  sprites on any one line of the display, and after that, the rest will not
  be shown. Some games use this fact to make sprites disappear under other
  objects. However you can disable this effect and let all sprites be
  drawn - for some games this will remove a lot of flickering.

* BIOS Use - allows you to ignore the BIOS files without having to manually
  edit them all out. SG-1000/SC-3000 games, for example, probably won't run
  if the BIOS files are enabled, because they lack data that the BIOS files
  look for.

* SMS Border - some people didn't like the fact that the area outside the
  SMS display is filled with a "border colour". This is how a real SMS
  does things, but by request, this option removes the "border colour".

* YM2413FM - an extra soundchip present only in some Japanese systems. This
  should not be accessed by any software that doesn't make use of it, but
  you can disable it here should any weird sounds be heard.


Genesis:
--------

SRM Files - these are the emulated battery-backed RAM files used in some
cartridges. Select the folder where you want these files to be saved.

State Files - See LOAD/SAVE STATE. Select the folder where you want these
files to be saved.

Patch Files - these are Game Genie code files. Select the folder where you
want these files to be saved.

BIOS File - you can specify where to find the Genesis BIOS file. This file
is not required for operation, but you can use it if you wish.

AutoFix Checksums - Fixes Checksums on ROMs with bad checksums. Some ROMs
are *supposed* to have a bad chacksum, and fixing it will stop the game
from running. In either case, if your game locks up (often with a red
screen) try altering this option and reloading the ROM.

Disable SRAM - Some games have a kind of protection whereby they will try
to write to SRAM. The cartridge itself didn't actually *have* any SRAM -
so if the write is successful, the game will not work correctly. Pugsy is
one such game, there may be others.


Sega CD:
--------

USA/JAP/EUR BIOS - locate the BIOS files required for SegaCD emulation.

BRM Files - Select the folder where you wish SegaCD Save Games to be saved.

ReadAhead - Select amount of ReadAhead the CD drive does while running
SegaCD games. Which works best really depends on the speed of your PC and
CD-ROM drive. Experiment !

Internal RAM - Per Game will create and save a new RAM file for each game
loaded. Single will use just one internal RAM file, similar to the original
SegaCD.

CD+G - Specify how CD+G codes are treated. This is dependant on your CD
drive, and is only useful if you are playing an audio CD containing CD+G
codes from within the SegaCD BIOS. Most of the time you should leave this
OFF (it has no use at all while playing games or normal audio CDs, and may
affect performance) but if you have a CD+G disc, you can try either RAW or
COOKED mode. Which works best is dependant on your CD drive - a lot of CD
drives don't work at all, but most CD-RW drives should support at least one
or the other format.

Please note that CD+G itself is fairly unreliable - the CD+G data is not
protected by checksums/correction data like the rest of the data on a CD.
So if you see some corruption while watching a CD+G disk, don't be too
surprised by it ;-) There is not much that can be done about this, its a
problem with the CD+G format, and is quite common.


32X:
----

M68K/Master/Slave BIOS - locate the BIOS files required for 32X emulation.

Disable 32X - Unlike most other emulators that treat the 32X as an entirely
seperate console, in this emulator the 32X is connected to the Genesis at
all times - much like a real system, Genesis and SegaCD games work as
normal, and only when a game attempts to initialise the 32X, it springs to
life. This makes for a nicer user experience - the user does not need to
know beforehand if the 32X is required or not. However, although it should
not happen, it is possible that some programs MAY accidentally trigger the
32X, which will do nothing much except affect performance. If this is the
case it can be disabled (effectively, unplugged) here. Another reason why
you may wish to disable the 32X is that some SegaCD/32X games will work
with or without the 32X - this will allow you to see both versions.


Controllers:
------------

Here you can select which type of controller is connected to each of the
control ports. You can also select whether each of these controllers uses
Keyboard, Joystick, or in some cases, Mouse control. Clicking the DEFINE
button allows you to set keys or Joystick buttons.

Standard controllers supported are: 3 Button Pad, 6 Button Pad, Sega Mouse,
and Sega Menacer. The PC Mouse can be used to control the Sega Mouse or
Menacer only.

Also supported is the Sega TeamPlayer (in port 1, port 2, or both), the EA
4-Way-Play (which takes up both ports), and the J-Cart (used for some
Codemasters games) - these devices all allow more than 2 controllers to be
connected. Note that none of these devices should be enabled unless the
game you are playing supports them, otherwise controller input may not
work correctly.

Finally, you can invert the Sega Mouse (some games require this) and enable
a cursor for the LightGun (NOT YET IMPLEMENTED), if you wish.


---------------------------------------------------------------------------
Special Features
---------------------------------------------------------------------------

* You can play multiple CD games. When it comes time to change discs, you
  should see a flashing CD tray icon in the bottom left of the display.
  This means the emulated CD tray is OPEN. You can safely change discs at
  this point - alternatively you can load a new SegaCD Image file.

* You can play with the SMS BIOS by hitting "Power On" while the emulator
  is in a "Power Off" state. The SMS will boot without a cartridge, thus
  letting you play with games etc. stored in the BIOS.

* You can play with the MegaCD Cartridge "Flux" by first loading it as a
  Genesis cartridge. When it reports that you need a MegaCD to use it, you
  can then put an audio CD in your CD-ROM drive and hit "Boot CD". Flux
  will now run, and will stay active until you hit "Power Off".


---------------------------------------------------------------------------
Technical
---------------------------------------------------------------------------

Fusion is written mainly in x86 ASM, with small parts (Windows interface,
DirectX interface, File Handling) written in C. All code is written by me
- Steve Snake.

Fusion requires DirectX 7.0 or above to operate, and your desktop must be
set to either 16-Bit (HI-COLOR) or 32-Bit (TRUE-COLOR). A modern graphics
card is recommended, however a fallback compatibility mode is included if
you have an older card, or experience speed issues or other problems. This
will kick in automatically if needed, but can be forced by editing the INI
file value for "ForceCompatibleGFX" (at the end of the file) to 1 should
your performance suffer. You could also try settings of either 0 or 1 for
"CompatibleGFXOpt" to see which works fastest on your hardware. Note
however that this mode is no longer supported, is somewhat slower, has less
features, and requires the desktop to be in 16-Bit (HI-COLOR) Mode.

Under Win9x/WinME, it requires an ASPI manager in order to access CD-ROM
drives. Under Win2k/WinXP it will attempt to use IOCTL instead, but should
you encounter problems with this you can edit the INI file value for
"ForceASPI" to 1, and install ASPI anyway.


---------------------------------------------------------------------------
New Stuff
---------------------------------------------------------------------------

For this release this section will mention major changes between Fusion and
Kega.

There have been major rewrites to a lot of code, but here I shall list the
benefits of these rewrites rather than bore you with the details...

* Much improved Video system
* Now runs in 32-Bit colour as well as 16-Bit colour
* Selectable resolutions etc
* Multiple Scanline Modes (by request)
* Video Filtering
* New YM2612, including LFO, Hardware Bugs, and other features
* Perfect Sync now almost as fast as Non-Perfect Sync
* SegaCD PCM Chip should now be hardware accurate
* All SegaCD Timings should now be, or be very close to, hardware accurate
* Sound Disable option (by request)
* Works without a sound card ;)
* Support for Sega TeamPlayer
* Support for EA 4-Way-Play
* Support for J-Cart
* Support for Sega Mouse
* Support for Sega Menacer
* Support for CD+G (SegaCD)
* Uses IOCTL for CD-ROM access under Win2K/WinXP
* Support for the MegaCD Cartridge "Flux"
* Support for Genesis+32X
* Support for SegaCD+32X

SG-1000/SC-3000/Master System/GameGear emulation has slight improvements
over earlier versions, and is pretty accurate - but I cannot comment on how
it compares to other emulators - there are far too many of them ;-) There
are also certain peripherals that are not supported as yet, meaning that
a few games will probably not be playable.

Genesis emulation was already pretty accurate, but with the rewriting of
certain parts, and the rewriting and major reverse engineering effort
(again) of the YM2612, all remaining problems I know of should now be gone.
That makes a total of 7 years worth of R&D devoted to the YM2612 now, along
with 5 core from-scratch-rewrites ;) I may choose to rewrite the core yet
again, because I'm convinced I can speed it up greatly (it is much slower
than my previous core currently) - but accuracy was the main focus this
time around.

SegaCD emulation was the major focus of this release, it has been rewritten
and tweaked almost entirely, and again, a lot of deep reverse engineering
was involved, on almost every part of the system, on both PAL and NTSC
systems. It is now so much more accurate to real hardware than it ever was,
which meant I could finally start adding something that I HAD planned to
add in Kega 0.5 TWO YEARS ago... 32X.

32X emulation is VERY preliminary in this release - but is already highly
accurate and should run most games fine. The only games I know of that have
problems are Pitfall (which appears to be actually bugged, and its problems
are not related to emulation) and Shadow Squadron (which does some very
weird stuff, and causes problems with all emulators - I have yet to track
down what weirdness causes these problems - maybe they even occur on real
hardware...) Whatever, it runs every other cartridge game just fine as far
as I am aware, and should also run most CD/32X games, although I dont have
these for testing...


---------------------------------------------------------------------------
What is currently missing?
---------------------------------------------------------------------------

* 32X Save States
* 32X BIOS Faking
* SegaCD Save States
* Command Line Control
* Brightness/Contrast Control ?
* Lightgun Cursor
* Justifier Lightgun Support
* Master System specific stuff
* Other stuff that I've forgotten ;)

---------------------------------------------------------------------------

Thats all for now - have fun :-)

Snake
