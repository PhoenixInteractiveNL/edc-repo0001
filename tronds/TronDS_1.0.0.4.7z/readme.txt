Technical documentation
-----------------------
Product name        : TronDS
Current Version     : 1.0.0.4

Supported platforms : Windows 95/98/Me/XP/Vista + OpenGL + DirectX 7.0 or higher
                      Windows NT4/2000 (not tested but should work...)


Language	    : English.

Author              : jocopoco
Website             : http://trondsemu.byethost15.com/

E-mail              : jocopoco1000@gmail.com 


*** please do not send any questions on how to use or play games. ***


Emulation status
----------------
- ARM946E-S 	: 32-bit ARM CPU support (99%)
              	  16-bit THUMB CPU support (100%) 
- ARM11 MPCore 	: 32-bit ARM CPU support (99%)
              	  16-bit THUMB CPU support (100%) 

- Real sync emulation for HBlanks and VBlanks 
- 3D Mode

Special features
----------------

Acknowledgements (in no particular order)
-----------------------------------------

Keys
-----------------------------------------
D-Up		Up arrow
D-Down		Down arrow
D-Left		Left arrow
D-Right		Right arrow
B		Z
A		X
Start		Return
Select		Shift
L		A
R		S
X		Q
Y		W



